import {Component, EventEmitter, OnChanges, OnInit, Output, Input, ViewChild} from '@angular/core';
import {AALAutoCompleteMultipleComponent} from '../auto-complete-multiple/auto-complete-multiple.component';
import {HistoryService} from '@asml-angular/common';
import {MatAutocompleteTrigger} from '@angular/material/autocomplete';

@Component({
  selector: 'aal-auto-complete-free-text-multiple',
  templateUrl: './auto-complete-free-text-multiple.component.html',
  styleUrls: ['./auto-complete-free-text-multiple.component.scss']
})
export class AutoCompleteFreeTextMultipleComponent extends AALAutoCompleteMultipleComponent implements OnInit, OnChanges {
  @Input()
  set resetList(value: boolean) {
    if (value) {
      this.inputControl.setValue('');
    }
  }
  @Output()
  onFocus = new EventEmitter<any>();
  @Output()
  chipAdded: EventEmitter<void> = new EventEmitter<void>();
  @ViewChild(MatAutocompleteTrigger)
  public trigger: MatAutocompleteTrigger;
  constructor(historyService: HistoryService) {
    super(historyService);
  }

  ngOnInit() {
    super.ngOnInit();
    if (this.dataSource && this.showOptionsOnFocus) {
      this.dataSource().subscribe((data) => {
        if (data && data.length) {
          this.optionsList = data;
        }
      });
    }
  }
  addChip(event: any, input?: HTMLInputElement): void {
    this.inputControl.setValue('');
    this.chipAdded.emit(event);
    super.addChip(event, input);
    this.optionsList = this.removeControlValues(this.optionsList);
    setTimeout(() => {
      if (this.trigger) {
        this.trigger.openPanel();
      }
    }, 1);
  }

  onKeyUp(event: KeyboardEvent) {
    if (event.key === 'Enter') {
      if (this.inputControl && this.inputControl.value) {
        this.currentValue = this.control.value || [];
        this.currentValue.push(this.inputControl.value);
        this.control.setValue(this.currentValue);
        this.chipAdded.emit(this.inputControl.value);
        this.resetInputControl();
      }
      this.triggerAcceptChanges();
    } else if (event.key === 'Escape') {
      this.triggerRejectChanges();
    } else if (event.key === ' ' && this.autoTrigger && this.autoTrigger.activeOption) {
      this.addChip(this.autoTrigger.activeOption, this.autoCompleteInput.nativeElement);
    }
  }

  removeChip(item: any, inputField: HTMLElement): void {
    this.resetInputControl();
    super.removeChip(item, inputField);
    this.optionsList.push(item);
    setTimeout(() => {
      this.trigger.openPanel();
    }, 1);
  }

  acceptFreeTextChanges() {
    if (this.inputControl.value !== '') {
      this.currentValue = this.control.value || [];
      this.currentValue.push(this.inputControl.value);
      this.chipAdded.emit(this.inputControl.value);
      this.control.setValue(this.currentValue);
      this.resetInputControl();
    }
    super.triggerAcceptChanges();
  }

  resetInputControl() {
    this.inputControl.setValue('');
  }

  onInputFocus(): void {
    this.onFocus.emit();
  }
}
