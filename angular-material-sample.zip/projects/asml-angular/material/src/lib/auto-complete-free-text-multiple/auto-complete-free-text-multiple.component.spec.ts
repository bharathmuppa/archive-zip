import {waitForAsync, ComponentFixture, TestBed} from '@angular/core/testing';
import {CommonModule} from '@angular/common';
import {UntypedFormControl} from '@angular/forms';
import {MatAutocompleteTrigger} from '@angular/material/autocomplete';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {AALCommonComponentsModule} from '@asml-angular/common';

import {AutoCompleteFreeTextMultipleComponent} from './auto-complete-free-text-multiple.component';
import {SharedMaterialModule} from '../shared/shared-material.module';
import {SharedFormModule} from '../shared/shared-form.module';
import {SharedModule} from '../shared/shared.module';
import {SharedFlexLayoutModule} from '../shared/shared-flex-layout.module';
import {AALOverlayCardHelpModule} from '../overlay-card-help/overlay-card-help.module';
import {AALOverlayCardErrorModule} from '../overlay-card-alert/overlay-card-alert.module';
import {AALChipModule} from '../chip/chip.module';
import {AALToolbarConfirmModule} from '../toolbar-confirm/toolbar-confirm.module';
import {BehaviorSubject} from 'rxjs';
import {MatOption} from '@angular/material/core';

describe('AutoCompleteFreeTextMultipleComponent', () => {
  let component: AutoCompleteFreeTextMultipleComponent;
  let fixture: ComponentFixture<AutoCompleteFreeTextMultipleComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [AutoCompleteFreeTextMultipleComponent, MatAutocompleteTrigger],
      imports: [CommonModule,
        SharedMaterialModule,
        SharedFormModule,
        SharedModule,
        SharedFlexLayoutModule,
        AALCommonComponentsModule,
        AALOverlayCardHelpModule,
        AALOverlayCardErrorModule,
        AALChipModule,
        AALToolbarConfirmModule,
        BrowserAnimationsModule]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AutoCompleteFreeTextMultipleComponent);
    component = fixture.componentInstance;
    component.control = new UntypedFormControl([]);
    component.itemDisplayField = 'name';
    component.dataSource = () => {
      return new BehaviorSubject([{value: 'YES', label: 'Yes'}, {value: 'NO', label: 'No'}]);
    };
    component.showOptionsOnFocus = true;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should reject value on escape event', () => {
    spyOn(component, 'triggerRejectChanges');
    const event = new KeyboardEvent('keyup', {
      key: 'Escape'
    });
    component.onKeyUp(event);
    expect(component.triggerRejectChanges).toHaveBeenCalled();
  });

  it('should emit value on enter key event', () => {
    component.inputControl = new UntypedFormControl('Sample');
    spyOn(component.chipAdded, 'emit');
    const event = new KeyboardEvent('keyup', {
      key: 'Enter'
    });
    component.onKeyUp(event);
    expect(component.chipAdded.emit).toHaveBeenCalled();
  });

  it('should call addChip, when onKeyUp is triggered after SPACE key is pressed', () => {
    spyOn(component, 'addChip');
    component.autoTrigger = {
      get activeOption(): MatOption | null {
        return {} as MatOption;
      }
    } as MatAutocompleteTrigger;
    component.autoCompleteInput = {
      nativeElement: {}
    };
    const event = new KeyboardEvent('keyup', {
      key: ' '
    });
    component.onKeyUp(event);
    expect(component.addChip).toHaveBeenCalled();
  });

  it('should set value to control', () => {
    const res = {
      option: {
        abbreviation: 'Q04T',
        departmentName: '',
        email: 'q04test@asml.qas',
        fullName: 'Q 04test',
        photoURL: 'https://people.asml.com:443/User Photos/Profile Pictures/q04test_MThumb.jpg',
        roles: ['changeSpecialist1'],
        userID: 'q04test',
        value: 'test Value'
      }
    };
    const inputElem = document.createElement('input');
    component.trigger = {
      openPanel(): void {
      }
    } as MatAutocompleteTrigger;
    inputElem.placeholder = 'Select a person';
    component.addChip(res, inputElem);
    expect(component.control.value).toEqual(['test Value']);
  });

  it('should filter the Chip values', () => {
    const value = ['abc', '123', 'xyz'];
    component.optionsList = [];
    component.trigger = {
      openPanel(): void {
      }
    } as MatAutocompleteTrigger;
    const inputField = document.createElement('input');
    component.control.setValue(value);
    component.removeChip('123', inputField);
    expect(component.control.value).toEqual(['abc', 'xyz']);
  });

  it('should acceptFreeTextChanges', () => {
    const value = ['abc', '123', 'xyz'];
    component.inputControl = new UntypedFormControl('Sample');
    component.control.setValue(value);
    component.acceptFreeTextChanges();
    expect(component.control.value).toEqual(['abc', '123', 'xyz', 'Sample']);
  });

  it('should emit onFocus, when onInputFocus is triggered', () => {
    const spy = spyOn(component.onFocus, 'emit');
    component.onInputFocus();
    expect(spy).toHaveBeenCalled();
  });

  it('should clear inputControl value, when resetList is triggered', () => {
    component.resetList = true;
    expect(component.inputControl.value).toEqual('');
  });
});
