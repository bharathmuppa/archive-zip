import {Component} from '@angular/core';
import {AALInputTextAreaComponent} from '../input-text-area/input-text-area.component';

@Component({
  selector: 'aal-editable-div-text-area',
  templateUrl: './editable-div-text-area.component.html',
  styleUrls: ['./editable-div-text-area.component.scss']
})
export class AALEditableDivTextAreaComponent extends AALInputTextAreaComponent {

  setFocusInInput() {
    this.onClick();
    setTimeout(() => {
    document.execCommand('selectAll', false, null);
    // collapse selection to the end
    if (document.getSelection()) {
      document.getSelection().collapseToEnd();
    }
    }, 1);
  }
}
