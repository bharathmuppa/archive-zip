import {Component, DebugElement, OnInit, Renderer2} from '@angular/core';
import {UntypedFormBuilder, UntypedFormControl, FormsModule, ReactiveFormsModule} from '@angular/forms';
import {ErrorStateMatcher} from '@angular/material/core';
import {ComponentFixture, TestBed} from '@angular/core/testing';
import {By} from '@angular/platform-browser';
import {MatContenteditableDirective} from './mat-contenteditable.directive';

@Component({
  template: `
    <div #inputField contenteditable matInput (blur)="onBlur()" (focus)="onFocus()" (input)="onInput()"
         [formControl]="control" [required]="hasRequiredValidator()" [errorStateMatcher]="errorStateMatcher"
         [placeholder]="placeholder || ''" [propValueAccessor]="'innerText'"
         type="text" class="mat-subtitle-2 editable-div"></div>`
})
class TestComponent implements OnInit {
  control: UntypedFormControl;
  placeholder: string;
  errorStateMatcher: ErrorStateMatcher;

  constructor(private formBuilder: UntypedFormBuilder) {
  }

  ngOnInit() {
    this.control = this.formBuilder.control(' test value ');
  }

  hasRequiredValidator() {
    return false;
  }

  onBlur() {
  }

  onFocus() {
  }

  onInput() {
  }
}

describe('MatContenteditableDirective', () => {
  let directive: MatContenteditableDirective;
  let component: TestComponent;
  let fixture: ComponentFixture<TestComponent>;
  let debugElement: DebugElement;
  const ele = {
    nativeElement: {
      innerText: 'Foo',
      focus: () => {
      }
    }
  };
  const func = function() {
    return true;
  };
  const renderer = {
    setProperty: () => {
    },
    setAttribute: () => {
    },
    listen: (ref, event, callback: (evt) => void) => {
      // We care calling the callback method to cover the private method listenerDisabledState
      callback({
        preventDefault: () => {
        }
      } as KeyboardEvent);
      return func;
    },
    removeAttribute: () => {
    }
  } as unknown as Renderer2;
  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [
        TestComponent,
        MatContenteditableDirective
      ],
      imports: [
        FormsModule,
        ReactiveFormsModule
      ]
    }).compileComponents().then(() => {
      directive = new MatContenteditableDirective(ele, renderer, null, null, null, null);
    });
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TestComponent);
    component = fixture.componentInstance;
    debugElement = fixture.debugElement.query(By.directive(MatContenteditableDirective));
    jasmine.clock().uninstall();
    fixture.detectChanges();
  });

  it('should create component', () => {
    directive = new MatContenteditableDirective(ele, renderer, null, null, null, null);
    expect(directive).toBeTruthy();
  });

  it('should set appropriate describedBy, when setDescribedByIds is triggered', () => {
    directive = new MatContenteditableDirective(ele, renderer, null, null, null, null);
    directive.setDescribedByIds(['a', 'b']);
    expect(directive.describedBy).toEqual('a b');
  });

  it('should set value, when the setter is called', () => {
    directive = new MatContenteditableDirective(ele, renderer, null, null, null, null);
    const spy = spyOn(directive.stateChanges, 'next');
    directive.value = 'Bar';
    const placeholder = directive.placeholder;
    const empty = directive.empty;
    const labelFloat = directive.shouldLabelFloat;
    const required = directive.required;
    expect(spy).toHaveBeenCalled();
  });

  it('should set disabled, when the setter is called', () => {
    directive = new MatContenteditableDirective(ele, renderer, null, null, null, null);
    const spy = spyOn(directive.stateChanges, 'next');
    directive.disabled = true;
    const disabled = directive.disabled;
    expect(spy).toHaveBeenCalled();
  });

  it('should call component onFocus method, when focus event is triggered', () => {
    directive = new MatContenteditableDirective(ele, renderer, null, null, null, null);
    const spy = spyOn(component, 'onFocus');
    debugElement.nativeElement.dispatchEvent(new FocusEvent('focus', {}));
    expect(spy).toHaveBeenCalled();
  });

  it('should call component onBlur method, when blur event is triggered', () => {
    directive = new MatContenteditableDirective(ele, renderer, null, null, null, null);
    const spy = spyOn(component, 'onBlur');
    debugElement.nativeElement.dispatchEvent(new FocusEvent('blur', {}));
    expect(spy).toHaveBeenCalled();
  });

  it('should call component onInput method, when input event is triggered', () => {
    directive = new MatContenteditableDirective(ele, renderer, null, null, null, null);
    const spy = spyOn(component, 'onInput');
    debugElement.nativeElement.dispatchEvent(new InputEvent('input', {}));
    expect(spy).toHaveBeenCalled();
  });

  it('should call focus method, when onContainerClick is triggered', () => {
    directive = new MatContenteditableDirective(ele, renderer, null, null, null, null);
    const spy = spyOn(ele.nativeElement, 'focus');
    directive.onContainerClick();
    expect(spy).toHaveBeenCalled();
  });

  it('should call setAttribute method, when setDisabledState is triggered & isDisabled is true', () => {
    directive = new MatContenteditableDirective(ele, renderer, null, null, null, null);
    const spy = spyOn(renderer, 'setAttribute');
    directive.setDisabledState(true);
    expect(spy).toHaveBeenCalled();
  });

  it('should call removeAttribute method, when setDisabledState is triggered & isDisabled is true', () => {
    directive = new MatContenteditableDirective(ele, renderer, null, null, null, null);
    const spy = spyOn(renderer, 'removeAttribute');
    directive.setDisabledState(true);
    directive.setDisabledState(false);
    expect(spy).toHaveBeenCalled();
  });
});
