import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import {CommonModule} from '@angular/common';
import {AALCommonComponentsModule} from '@asml-angular/common';

import {SharedMaterialModule} from '../shared/shared-material.module';
import {SharedFormModule} from '../shared/shared-form.module';
import {AALOverlayCardHelpModule} from '../overlay-card-help/overlay-card-help.module';
import {AALOverlayCardErrorModule} from '../overlay-card-alert/overlay-card-alert.module';
import {AALToolbarConfirmModule} from '../toolbar-confirm/toolbar-confirm.module';
import {SharedFlexLayoutModule} from '../shared/shared-flex-layout.module';
import {AALEditableDivTextAreaComponent} from './editable-div-text-area.component';

describe('AAAEditableDivTextAreaComponent', () => {
  let component: AALEditableDivTextAreaComponent;
  let fixture: ComponentFixture<AALEditableDivTextAreaComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [AALEditableDivTextAreaComponent],
      imports: [
        CommonModule,
        SharedMaterialModule,
        SharedFormModule,
        AALCommonComponentsModule,
        AALOverlayCardHelpModule,
        AALOverlayCardErrorModule,
        AALToolbarConfirmModule,
        SharedFlexLayoutModule
      ]
    }).compileComponents().then(() => {
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALEditableDivTextAreaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call onClick, when setFocusInInput is triggered', () => {
    const spy = spyOn(component, 'onClick');
    component.setFocusInInput();
    expect(spy).toHaveBeenCalled();
  });

});

