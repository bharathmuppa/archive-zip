import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {AALCommonComponentsModule, AALCommonModule} from '@asml-angular/common';

import {AALEditableDivTextAreaComponent} from './editable-div-text-area.component';
import {AALOverlayCardHelpModule} from '../overlay-card-help/overlay-card-help.module';
import {AALOverlayCardErrorModule} from '../overlay-card-alert/overlay-card-alert.module';
import {AALToolbarConfirmModule} from '../toolbar-confirm/toolbar-confirm.module';
import {MatContenteditableDirective} from './mat-contenteditable.directive';
import {FlexLayoutModule} from '@angular/flex-layout';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import {MatInputModule} from '@angular/material/input';
import {MatTooltipModule} from '@angular/material/tooltip';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';

@NgModule({
  declarations: [AALEditableDivTextAreaComponent, MatContenteditableDirective],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    AALCommonModule,
    AALCommonComponentsModule,
    AALOverlayCardHelpModule,
    AALOverlayCardErrorModule,
    AALToolbarConfirmModule,
    MatInputModule,
    MatProgressSpinnerModule,
    MatTooltipModule,
    FlexLayoutModule
  ],
  exports: [
    AALEditableDivTextAreaComponent
  ]
})
export class AALEditableDivTextAreaModule {
}
