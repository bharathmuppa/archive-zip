import {Component, Input, OnInit} from '@angular/core';
import {AALInputTextComponent} from '../input-text/input-text.component';
import {HistoryService} from '@asml-angular/common';

@Component({
  selector: 'aal-input-text-suffix',
  templateUrl: './input-text-suffix.component.html',
  styleUrls: ['./input-text-suffix.component.scss']
})
export class AALInputTextSuffixComponent extends AALInputTextComponent implements OnInit {
  @Input()
  textStyle: string; // bold, Italic
  @Input()
  suffix: string;
  @Input()
  separator: string; // interpunct, brackets, hyphen
  constructor(historyService: HistoryService) {
    super(historyService);
  }

  ngOnInit() {
  }

}
