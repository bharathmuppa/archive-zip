import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import {AALCommonComponentsModule} from '@asml-angular/common';
import {CommonModule} from '@angular/common';

import {SharedMaterialModule} from '../shared/shared-material.module';
import {SharedFormModule} from '../shared/shared-form.module';
import {SharedFlexLayoutModule} from '../shared/shared-flex-layout.module';
import { AALInputTextSuffixComponent } from './input-text-suffix.component';
import {AALOverlayCardHelpModule} from '../overlay-card-help/overlay-card-help.module';
import {AALOverlayCardErrorModule} from '../overlay-card-alert/overlay-card-alert.module';
import {AALToolbarConfirmModule} from '../toolbar-confirm/toolbar-confirm.module';


describe('AALInputTextSuffixComponent', () => {
  let component: AALInputTextSuffixComponent;
  let fixture: ComponentFixture<AALInputTextSuffixComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ AALInputTextSuffixComponent ],
      imports: [CommonModule,
        SharedMaterialModule,
        SharedFormModule,
        AALCommonComponentsModule,
        AALOverlayCardHelpModule,
        AALOverlayCardErrorModule,
        AALToolbarConfirmModule,
        SharedFlexLayoutModule]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALInputTextSuffixComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
