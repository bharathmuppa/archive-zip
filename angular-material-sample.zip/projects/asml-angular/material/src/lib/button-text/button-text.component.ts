import {Component} from '@angular/core';
import {AALCommonButtonComponent} from '@asml-angular/common';

@Component({
  selector: 'aal-button-text',
  templateUrl: './button-text.component.html',
  styleUrls: ['./button-text.component.scss']
})
export class AALButtonTextComponent extends AALCommonButtonComponent {

}
