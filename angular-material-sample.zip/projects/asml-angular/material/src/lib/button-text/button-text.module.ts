import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AALButtonTextComponent } from './button-text.component';
import {AALCommonComponentsModule} from '@asml-angular/common';
import {MatTooltipModule} from '@angular/material/tooltip';
import {MatButtonModule} from '@angular/material/button';

@NgModule({
  declarations: [AALButtonTextComponent],
  imports: [
    CommonModule,
    AALCommonComponentsModule,
    MatButtonModule,
    MatTooltipModule
  ],
  exports: [AALButtonTextComponent]
})
export class AALButtonTextModule { }
