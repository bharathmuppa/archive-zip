import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { CommonModule } from '@angular/common';
import {Info} from '@asml-angular/common';
import { SharedMaterialModule } from '../shared/shared-material.module';
import { SharedFormModule } from '../shared/shared-form.module';
import { SharedFlexLayoutModule } from '../shared/shared-flex-layout.module';
import { AALListItemModule } from '../list-item/list-item.module';
import { SharedModule } from '../shared/shared.module';
import { AALEmptyStateModule } from '../empty-state/empty-state.module';
import { AALExpansionPanelListComponent } from './expansion-panel-list.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {ActionEventData} from '../list-item/list-item.component';
import {ActionButtonConfiguration, ExpansionPanelItemConfiguration} from './expansion-panel-list.model';

describe('AALExpansionPanelListComponent', () => {
  let component: AALExpansionPanelListComponent;
  let fixture: ComponentFixture<AALExpansionPanelListComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [AALExpansionPanelListComponent],
      imports: [
        SharedMaterialModule,
        SharedFormModule,
        SharedModule,
        SharedFlexLayoutModule,
        AALListItemModule,
        AALEmptyStateModule,
        BrowserAnimationsModule
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALExpansionPanelListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should set initial values on component initiation', () => {
    component.help = 'help text';
    const value = new Info('Sample Title', 'Sample Help Message', '', '', null);
    component.expansionPanelItemConfigurationList = [
      ({
        ID: 'ID1',
        title: 'title1',
        mainDescription: 'item main description1',
        line1: 'item sub description1',
        icon: 'group',
        isClickable: true,
        isBusy: true,
        help: new Info('some item level help'),
        showActionButtonOnFocus: true,
        actionButtonConfiguration: ({
          actionButtonIcon: 'delete',
          actionButtonText: 'buttonText1',
          actionButtonType: 'icon',
          actionButtonTooltip: 'action button tooltip1',
          showActionButton: true,
          action: 'delete'
        }) as ActionButtonConfiguration
      }) as ExpansionPanelItemConfiguration
    ];
    component.ngOnInit();
    expect(typeof component.help).toBe(typeof value);
    component.hasAnyItemHelp = component.hasAnyItemHelpText();
    expect(component.hasAnyItemHelp).toBeTruthy();

  });
  it('should emit on click of button', () => {
    spyOn(component.actionSubmit, 'emit');
    const actionEventData: ActionEventData = {ID : '', action: ''};
    component.onActionSubmit(actionEventData);
    fixture.detectChanges();
    expect(component.actionSubmit.emit).toHaveBeenCalled();
  });
  it('should emit on click of add item', () => {
    spyOn(component.addItem, 'emit');
    const event = new MouseEvent('click');
    component.addItemClick(event);
    fixture.detectChanges();
    expect(component.addItem.emit).toHaveBeenCalled();
  });
  it('should emit on click of specific item', () => {
    spyOn(component.itemClick, 'emit');
    const event = new MouseEvent('click');
    component.onItemClick('');
    fixture.detectChanges();
    expect(component.itemClick.emit).toHaveBeenCalled();
  });

  it('should match object error info onInIt', () => {
    component.error = 'test error string';
    component.ngOnInit();
    expect(component.error).toEqual(jasmine.objectContaining({
      message: 'test error string'
    }));
  });
});
