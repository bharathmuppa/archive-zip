import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {AALExpansionPanelListComponent} from './expansion-panel-list.component';
import {AALListItemModule} from '../list-item/list-item.module';
import {AALEmptyStateModule} from '../empty-state/empty-state.module';
import {FlexLayoutModule} from '@angular/flex-layout';
import {MatExpansionModule} from '@angular/material/expansion';
import {AALOverlayCardHelpModule} from '../overlay-card-help/overlay-card-help.module';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import {AALOverlayCardErrorModule} from '../overlay-card-alert/overlay-card-alert.module';
import {MatTooltipModule} from '@angular/material/tooltip';
import {MatIconModule} from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';

@NgModule({
  declarations: [AALExpansionPanelListComponent],
  imports: [
    CommonModule,
    AALListItemModule,
    AALEmptyStateModule,
    AALOverlayCardHelpModule,
    AALOverlayCardErrorModule,
    MatButtonModule,
    MatExpansionModule,
    MatIconModule,
    MatProgressSpinnerModule,
    MatTooltipModule,
    FlexLayoutModule
  ],
  exports: [AALExpansionPanelListComponent]
})
export class AALExpansionPanelListModule {
}
