/*
 * Public API Surface of material
 */

export * from './auto-complete-multiple.component';
export * from './auto-complete-multiple.module';
