import {AfterViewInit, Component, ElementRef, Input, OnChanges, OnInit, ViewChild} from '@angular/core';
import {CommonMaterialComponentErrorStateMatcher} from '../shared/common-material-component.error-state-matcher';
import {AALAutoCompleteFormControlComponent, HistoryService} from '@asml-angular/common';
import {MatAutocomplete, MatAutocompleteTrigger} from '@angular/material/autocomplete';

@Component({
  selector: 'aal-auto-complete-multiple',
  templateUrl: './auto-complete-multiple.component.html',
  styleUrls: ['./auto-complete-multiple.component.scss']
})
export class AALAutoCompleteMultipleComponent extends AALAutoCompleteFormControlComponent implements OnInit, OnChanges, AfterViewInit {
  isControlDisabledInitially: boolean;
  @ViewChild('resultAutoComplete', {static: false}) matAutoComplete: MatAutocomplete;
  @ViewChild('inputField', {read: MatAutocompleteTrigger}) autoTrigger: MatAutocompleteTrigger;
  @ViewChild('inputField') autoCompleteInput: ElementRef;
  @Input()
  chipsRemovable: boolean;
  @Input()
  chipsDisabled: boolean;
  @Input()
  autoActiveFirstOption: boolean;
  @Input()
  highlightOption: boolean;
  errorStateMatcher = new CommonMaterialComponentErrorStateMatcher();
  currentValue: any;
  @Input() enableRemoveChipFromList: boolean;
  chipIndex: number;
  removeChipActivated: boolean;
  pointerOnChip: boolean;

  constructor(historyService: HistoryService) {
    super(historyService);
  }


  ngOnInit() {
    super.ngOnInit();
  }

  ngOnChanges() {
    if (this.inputControl && this.control && this.control.disabled) {
      this.isControlDisabledInitially = true;
      this.inputControl.disable();
    }
  }

  emptyControl() {
    this.control.setValue([]);
  }

  onInputBlur(event) {
    if (event.relatedTarget && this.matAutoComplete.isOpen) {
      event.relatedTarget.click();
    } else if (event.relatedTarget && (event.relatedTarget.id === this.hyphenatedID + '_close')) {
      event.preventDefault();
    } else if (event.relatedTarget && (!event.relatedTarget.id ||
      (event.relatedTarget.id && event.relatedTarget.id.includes(this.hyphenatedID)))) {
      this.triggerAcceptChanges();
      return;
    } else {
      this.triggerAcceptChanges();
    }
  }

  addChip(event: any, input?: HTMLInputElement): void {
    const value = event.value || event.option.value;
    if (value) {
      this.currentValue = this.control.value || [];
      this.currentValue.push(value);
      this.control.setValue(this.currentValue);
    }
    if (input) {
      input.value = '';
    }
  }

  removeChip(item: any, inputField: HTMLElement): void {
    const remainingItems = this.control.value.filter(option => option !== item);
    this.control.setValue(remainingItems);
    inputField.focus();
  }

  onKeyUp(event: KeyboardEvent) {
    if (event.key === 'Escape') {
      this.triggerRejectChanges();
    } else if (event.key === 'Enter' && this.autoTrigger && this.inputControl.value !== '') {
      this.inputControl.setValue('');
      this.triggerAcceptChanges();
    } else if (event.key === ' ' && this.autoTrigger && this.autoTrigger.activeOption) {
      this.addChip(this.autoTrigger.activeOption, this.autoCompleteInput.nativeElement);
    }
  }

  removeChipFromList (index) {
    if (index > -1) {
      this.currentValue = this.control.value || [];
      this.currentValue.splice(index, 1);
      this.control.setValue(this.currentValue);
      let inputElement = this.autoCompleteInput.nativeElement as HTMLElement;
      inputElement.focus();
    }
    this.chipIndex = undefined;
    this.removeChipActivated = undefined;
  }

  onBlur (event) {
    if (!this.pointerOnChip) {
      if (!this.chipIndex && !this.removeChipActivated) {
        this.blurEventHanlder(event);
      }
      else if (this.chipIndex > -1 && this.removeChipActivated) {
        this.removeChipFromList(this.chipIndex);
      }
    }
    else if (this.pointerOnChip) {
      if (this.chipIndex > -1 && this.removeChipActivated) {
        this.removeChipFromList(this.chipIndex);
      } else {
        let inputElement = this.autoCompleteInput.nativeElement as HTMLElement;
        inputElement.focus();
      }
    }
  }

  blurEventHanlder(event){
    if (event?.relatedTarget && this.matAutoComplete.isOpen) {
      event.relatedTarget.click();
    }
    else if (event?.relatedTarget && (event.relatedTarget.id === this.hyphenatedID + '_close')) {
      event.preventDefault();
    }
    else if (event?.relatedTarget && (!event.relatedTarget?.id ||
      (event.relatedTarget.id && event.relatedTarget.id.includes(this.hyphenatedID)))) {
      this.triggerAcceptChanges();
      return;
    }
    else {
      this.triggerAcceptChanges();
    }
  }

  activateRemoveChip (event) {
    this.chipIndex = event.chipIndex;
    this.removeChipActivated = event.removeChipActivated;
    this.pointerOnChip = false;
  }

  matChipClicked (event) {
    if (event) {
      this.pointerOnChip = event;
      let inputElement = this.autoCompleteInput.nativeElement as HTMLElement;
      inputElement.focus();
    }
    else {
      this.pointerOnChip = false;
    }
  }
}
