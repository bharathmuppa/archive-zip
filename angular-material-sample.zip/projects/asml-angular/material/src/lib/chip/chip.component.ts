import {Component, EventEmitter, Input, OnInit, Output, TemplateRef} from '@angular/core';

@Component({
  selector: 'aal-chip',
  templateUrl: './chip.component.html',
  styleUrls: ['./chip.component.scss']
})
export class AALChipComponent implements OnInit {
  @Input() data: string;
  @Input() imageURL: string;
  @Input() icon: string;
  @Input() chipIconImageRef: TemplateRef<any>;
  @Input() removable: boolean;
  @Input() disabled: boolean;
  @Input() noCursor: boolean;
  @Input()
  hideTooltip: boolean;
  @Input()
  svgIcon: string;
  @Input()
  chipStyleClassName: string;
  @Output() readonly deleteChip: EventEmitter<void> = new EventEmitter<void>();
  @Output() readonly chipPress: EventEmitter<void> = new EventEmitter<void>();
  @Output() readonly removeChipEvent: EventEmitter<void> = new EventEmitter<void>();
  @Input() chipIndex: number;
  @Input() enableRemoveChipFromList: boolean;
  @Output() readonly activateRemoveChip: EventEmitter<any> = new EventEmitter();
  @Output() readonly matChipClicked: EventEmitter<boolean> = new EventEmitter();
  mouseOnChip: boolean;

  constructor() {
  }

  ngOnInit() {
  }

  onRemove($event) {
    if (this.deleteChip) {
      this.deleteChip.emit($event);
    }
  }

  onChipClick($event) {
    if (this.chipPress) {
      this.chipPress.emit($event);
    }
  }

  removeChip(chipIndex) {
    if(chipIndex){
      this.removeChipEvent.emit(chipIndex);
    }
  }

  matChipClick() {
    if (this.mouseOnChip) {
      this.matChipClicked.emit(true);
    }
  }

  mouseOverChipData(event) {
    if (event) {
      this.mouseOnChip = true;
      this.matChipClicked.emit(true);
    }
    else {
      this.mouseOnChip = false;
      this.matChipClicked.emit(false);
    }
  }

  mouseOverRemoveChip(event) {
    if (event > -1) {
      let data = {
        chipIndex: event,
        removeChipActivated: true
      }
      this.activateRemoveChip.emit(data);
      this.matChipClicked.emit(true);
    }
    else {
      this.activateRemoveChip.emit(false);
    }
  }
}
