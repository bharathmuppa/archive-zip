import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {AALCommonComponentsModule} from '@asml-angular/common';
import {AALOverlayCardHelpModule} from '../overlay-card-help/overlay-card-help.module';
import {AALOverlayCardErrorModule} from '../overlay-card-alert/overlay-card-alert.module';
import {AALToolbarConfirmModule} from '../toolbar-confirm/toolbar-confirm.module';
import {AALChipComponent} from './chip.component';
import {MatIconModule} from '@angular/material/icon';
import {MatChipsModule} from '@angular/material/chips';
import {MatTooltipModule} from '@angular/material/tooltip';

@NgModule({
  declarations: [AALChipComponent],
  imports: [
    CommonModule,
    AALCommonComponentsModule,
    AALOverlayCardHelpModule,
    AALOverlayCardErrorModule,
    AALToolbarConfirmModule,
    MatChipsModule,
    MatIconModule,
    MatTooltipModule
  ],
  exports: [
    AALChipComponent
  ]
})
export class AALChipModule {
}
