import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {A11yModule} from '@angular/cdk/a11y';
import {AALButtonToggleComponent} from './button-toggle.component';
import {AALToolbarConfirmModule} from '../toolbar-confirm/toolbar-confirm.module';
import {AALOverlayCardHelpModule} from '../overlay-card-help/overlay-card-help.module';
import {AALOverlayCardErrorModule} from '../overlay-card-alert/overlay-card-alert.module';
import {AALButtonIconModule} from '../button-icon/button-icon.module';
import {MatTooltipModule} from '@angular/material/tooltip';
import {MatButtonToggleModule} from '@angular/material/button-toggle';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {AALCommonModule} from '@asml-angular/common';
import {FlexLayoutModule} from '@angular/flex-layout';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import {MatIconModule} from '@angular/material/icon';

@NgModule({
  declarations: [AALButtonToggleComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    FlexLayoutModule,
    AALCommonModule,
    AALToolbarConfirmModule,
    AALOverlayCardHelpModule,
    AALOverlayCardErrorModule,
    AALButtonIconModule,
    A11yModule,
    MatButtonToggleModule,
    MatIconModule,
    MatProgressSpinnerModule,
    MatTooltipModule
  ],
  exports: [
    AALButtonToggleComponent
  ]
})
export class AALButtonToggleModule {
}
