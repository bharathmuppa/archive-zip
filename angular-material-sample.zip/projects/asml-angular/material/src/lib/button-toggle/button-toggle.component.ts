import {Component, Input, OnInit, ViewChild} from '@angular/core';
import {AALFixedInputFormControlComponent, Modes} from '@asml-angular/common';


@Component({
  selector: 'aal-button-toggle',
  templateUrl: './button-toggle.component.html',
  styleUrls: ['./button-toggle.component.scss']
})
export class AALButtonToggleComponent extends AALFixedInputFormControlComponent implements OnInit {
  @Input()
  layout: string;
  @Input()
  isOptionIcon: string;
  @Input()
  align: string;
  @ViewChild('toggle') buttonToggle;

  ngOnInit() {
    this.setLayout();
    super.ngOnInit();
  }

  setLayout() {
    if (!this.layout && this.options) {
      this.layout = this.options.length > 3 ? 'column' : 'row';
    }
  }

  onButtonToggleBlur(event) {
    if (event && event.relatedTarget && event.relatedTarget.id && event.relatedTarget.id.includes(this.hyphenatedID)) {
      // If relatedTarget of focusOut event is the next/previous option, do nothing
      return;
    } else if (event && (!event.relatedTarget || (event.relatedTarget && !event.relatedTarget.id) ||
      (event.relatedTarget && event.relatedTarget.id && !event.relatedTarget.id.includes(this.hyphenatedID)))) {
      // when navigating to an unrelated element, set back the default mode
      this.mode = this.lockMode ? this.lockMode : Modes.READ;
      this.triggerAcceptChanges();
    }
  }

  onKeyUp(event) {
    const regex = new RegExp('^([A-Z])$');
    const children = Array.from(event.currentTarget.children) as any[];
    const key = event.key.toUpperCase();
    if (event.key === 'Escape') {
      // If Esc key is pressed and lockMode is not set, set the mode to READ
      this.mode = this.lockMode ? this.lockMode : Modes.READ;
    } else if (event.key === 'ArrowRight') {
      this.navigateOptions(children, 'RIGHT');
    } else if (event.key === 'ArrowLeft') {
      this.navigateOptions(children, 'LEFT');
    } else if (regex.test(key)) {
      if (key === 'C' && this.control.value) {
        // If the key pressed is <c> or <C> and teh control has a value it is cleared
        this.resetControl();
      } else {
        // Below code is to select an option based on the key typed by the user Ex: If the user presses 'A' the below code selects and saves the first option which starts with either <a> or <A>
        for (const child of children) {
          const firstChar = child.innerText.substring(0, 1).toUpperCase();
          if (firstChar === key) {
            child.children[0].click();
            break;
          }
        }
      }
    }
  }

  navigateOptions(children, direction) {
    // When arrow left/right key is pressed need to focus the previous/next button, a.k.a button to the left/right of the currently focused button
    let currentIndex = 0;
    let nextIndex = 0;
    for (const child of children) {
      if (child.classList.contains('cdk-focused')) {
        currentIndex = children.indexOf(child);
        nextIndex = (currentIndex === 0 && direction === 'LEFT') ? children.length - 1 :
          (currentIndex === children.length - 1 && direction === 'RIGHT') ? 0 :
            (direction === 'LEFT') ? currentIndex - 1 : currentIndex + 1;
      }
    }
    // Using focusmonitor service to manually set the focus to the previous button and apply appropriate CSS
    children[nextIndex].tabIndex = 0;
    children[nextIndex].focus();
    children[nextIndex].classList.add('cdk-focused');
    children[nextIndex].classList.add('cdk-keyboard-focused');
  }

  resetMode(event) {
    if (event && (!event.relatedTarget || !(event.relatedTarget.id && event.relatedTarget.id.includes(this.hyphenatedID)))) {
      // Set the mode to the default mode, when focus is lost from the 'Clear Selection' button and related target is not the button toggle options
      this.mode = this.lockMode ? this.lockMode : Modes.READ;
      this.triggerAcceptChanges();
    }
  }

  onClick() {
    super.onClick();
    setTimeout(() => {
      if (this.buttonToggle) {
        this.buttonToggle.focus();
      }
    }, 200);
  }
}
