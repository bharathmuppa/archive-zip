/*
 * Public API Surface of material
 */

export * from './overlay-card-help.component';
export * from './overlay-card-help.module';
