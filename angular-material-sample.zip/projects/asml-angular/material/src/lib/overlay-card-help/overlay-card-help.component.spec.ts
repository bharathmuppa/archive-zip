import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import {Info, InfoLevels} from '@asml-angular/common';
import {CommonModule} from '@angular/common';

import {SharedMaterialModule} from '../shared/shared-material.module';
import {SharedFlexLayoutModule} from '../shared/shared-flex-layout.module';
import {AALOverlayCardHelpComponent} from './overlay-card-help.component';

describe('AALOverlayCardHelpComponent', () => {
  let component: AALOverlayCardHelpComponent;
  let fixture: ComponentFixture<AALOverlayCardHelpComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [AALOverlayCardHelpComponent],
      imports: [
        CommonModule,
        SharedMaterialModule,
        SharedFlexLayoutModule
      ]
    }).compileComponents().then(() => {
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALOverlayCardHelpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize the component (ngOnInit)', () => {
    component.sanitize = true;
    component.ngOnInit();
    expect(component).toBeTruthy();
  });

  it('should initialize the component (ngOnInit) without sanitize', () => {
    component.sanitize = false;
    component.ngOnInit();
    expect(component).toBeTruthy();
  });

  it('should sanitize Html content (sanitizeURL)', () => {
    const sanitizedHtml = component.sanitizeHTML('<script></script><h1>header</h1>');
    expect(sanitizedHtml).toEqual('<h1>header</h1>');
  });

  it('should sanitize URL (sanitizeURL)', () => {
    const sanitizedUrl = component.sanitizeURL('<a href=\'http://sample.com\'>Sample</a>');
    expect(sanitizedUrl).toEqual('unsafe:<a href=\'http://sample.com\'>Sample</a>');
  });

  it('should menu be closed (onKeyUp)', () => {
    component.menuTrigger = {
      closeMenu(): void {
      },
      openMenu(): void {
      }
    };
    const keyBoardEvent = {
      key: 'Escape',
      stopPropagation(): void {
      }
    } as KeyboardEvent;
    const menuCloseSpy = spyOn(component.menuTrigger, 'closeMenu').and.returnValue(null);
    component.onKeyUp(keyBoardEvent);
    expect(component.highlightIcon).toBeFalsy();
    expect(menuCloseSpy).toHaveBeenCalled();
  });
  it('should menu be opened (onClick)', () => {
    component.menuTrigger = {
      closeMenu(): void {
      },
      openMenu(): void {
      }
    };
    const menuCloseSpy = spyOn(component.menuTrigger, 'openMenu').and.returnValue(null);
    component.onClick();
    expect(component.highlightIcon).toBeTruthy();
    expect(menuCloseSpy).toHaveBeenCalled();
  });
  it('should animation flag be toggled (onToggleAnimation)', () => {
    const event = {
      stopPropagation(): void {
      }
    } as Event;
    component.showAnimation = false;
    component.onToggleAnimation(event);
    expect(component.showAnimation).toBeTruthy();
  });
  it('should call for open Menu', () => {
    spyOn(component, 'openMenu').and.callThrough();
    component.menuTrigger = {
      closeMenu(): void {
      },
      openMenu(): void {
      }
    };
    component.openMenu();
    expect(component.openMenu).toHaveBeenCalled();
  });
  it('should call for close Menu', () => {
    spyOn(component, 'closeMenu').and.callThrough();
    component.menuTrigger = {
      closeMenu(): void {
      },
      openMenu(): void {
      }
    };
    component.closeMenu();
    expect(component.closeMenu).toHaveBeenCalled();
  });

  it('should setErrorValues', () => {
    component.helpInput  = new Info('sample message','sample title', 'sample animation','icon-thumb',InfoLevels.WARN);
    component.sethelpInput();
    expect(component.title).toBe('sample title');

    component.help  = {
      title: 'sample title',
      message: 'sample message',
      animation: 'sample animation',
      thumbnail: 'icon-thumb',
      level: InfoLevels.WARN
    };
    component.sanitize = true;
    component.sethelpInput();
    expect(component.thumbnail).toBe('icon-thumb');
  });
});

