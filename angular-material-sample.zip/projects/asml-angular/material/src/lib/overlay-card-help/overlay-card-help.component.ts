import {Component, Input, OnInit, SecurityContext, ViewChild, ViewEncapsulation} from '@angular/core';
import {DomSanitizer, SafeValue} from '@angular/platform-browser';
import {Info} from '@asml-angular/common';

@Component({
  selector: 'aal-overlay-card-help',
  templateUrl: './overlay-card-help.component.html',
  styleUrls: ['./overlay-card-help.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class AALOverlayCardHelpComponent implements OnInit {
  title: string;
  message: string;
  animation: string;
  thumbnail: string;
  showAnimation: boolean;
  helpInput: Info | string;
  @Input()
  titleColor: string;
  @Input()
  sanitize: boolean;
  @ViewChild('trigger', {static: false}) menuTrigger;
  highlightIcon: boolean;

  constructor(private readonly sanitizer: DomSanitizer) {
  }

  @Input()
  set help(helpData: Info | string) {
    if (helpData) {
      this.helpInput = helpData;
      this.sethelpInput();
    }
  }

  openMenu() {
    this.highlightIcon = true;
    this.menuTrigger.openMenu();
  }

  closeMenu() {
    this.highlightIcon = false;
    this.menuTrigger.closeMenu();
  }

  ngOnInit() {

  }

  sethelpInput() {
    if (typeof this.helpInput === "string") {
      this.helpInput = new Info(this.helpInput, '', '', '', '');
    }
    const localTitle = this.helpInput?.title ?? '';
    const localMessage = this.helpInput?.message ?? '';
    const localAnimation = this.helpInput?.animation ?? '';
    const localThumbnail = this.helpInput?.thumbnail ?? '';

    this.sanitize = this.sanitize || false;

    if (this.sanitize) {
      this.title = this.sanitizeHTML(localTitle);
      this.message = this.sanitizeHTML(localMessage);
      this.animation = this.sanitizeURL(localAnimation);
      this.thumbnail = this.sanitizeURL(localThumbnail);
    } else {
      this.title = localTitle;
      this.message = localMessage;
      this.animation = localAnimation;
      this.thumbnail = localThumbnail;
    }
    this.showAnimation = false;
  }

  sanitizeHTML(content: SafeValue) {
    return this.sanitizer.sanitize(SecurityContext.HTML, content);
  }

  sanitizeURL(content: SafeValue) {
    return this.sanitizer.sanitize(SecurityContext.URL, content);
  }

  onKeyUp($event: KeyboardEvent) {
    if ($event.key === 'Escape') {
      this.closeMenu();
    }
    $event.stopPropagation();
  }

  onClick() {
    this.openMenu();
  }

  onToggleAnimation($event: Event) {
    this.showAnimation = !this.showAnimation;
    $event.stopPropagation();
  }
}
