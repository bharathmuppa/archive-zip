import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {AALToolbarConfirmComponent} from './toolbar-confirm.component';
import {FlexLayoutModule} from '@angular/flex-layout';
import {MatIconModule} from '@angular/material/icon';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatButtonModule} from '@angular/material/button';

@NgModule({
  declarations: [AALToolbarConfirmComponent],
  imports: [
    CommonModule,
    MatIconModule,
    MatToolbarModule,
    MatButtonModule,
    FlexLayoutModule
  ],
  exports: [
    AALToolbarConfirmComponent
  ]
})
export class AALToolbarConfirmModule {
}
