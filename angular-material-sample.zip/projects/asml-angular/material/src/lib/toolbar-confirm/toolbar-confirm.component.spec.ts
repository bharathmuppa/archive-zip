import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import {CommonModule} from '@angular/common';

import {SharedMaterialModule} from '../shared/shared-material.module';
import {AALToolbarConfirmComponent} from './toolbar-confirm.component';

describe('AALToolbarConfirmComponent', () => {
  let component: AALToolbarConfirmComponent;
  let fixture: ComponentFixture<AALToolbarConfirmComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [AALToolbarConfirmComponent],
      imports: [
        CommonModule,
        SharedMaterialModule
      ]
    }).compileComponents().then(() => {
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALToolbarConfirmComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should accept changes', () => {
    spyOn(component.pressAcceptEvent, 'emit');
    component.onAccept();
    expect(component.pressAcceptEvent.emit).toHaveBeenCalled();
  });

  it('should reject changes', () => {
    spyOn(component.pressRejectEvent, 'emit');
    component.onReject();
    expect(component.pressRejectEvent.emit).toHaveBeenCalled();
  });

  it('should emit focusLost, when onFocusOut is triggered', () => {
    component.ID = 'test';
    const spy = spyOn(component.focusLost, 'emit');
    component.onFocusOut({relatedTarget: {id: 'a_close'}} as unknown as FocusEvent);
    expect(spy).toHaveBeenCalled();
  });

});
