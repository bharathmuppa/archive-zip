/*
 * Public API Surface of material
 */

export * from './toolbar-confirm.component';
export * from './toolbar-confirm.module';
