import {Component, EventEmitter, Input, Output} from '@angular/core';
import {AALCommonFormControlComponent} from '@asml-angular/common';

@Component({
  selector: 'aal-toolbar-confirm',
  templateUrl: './toolbar-confirm.component.html',
  styleUrls: ['./toolbar-confirm.component.scss']
})
export class AALToolbarConfirmComponent extends AALCommonFormControlComponent {
  @Output() pressAcceptEvent: EventEmitter<void> = new EventEmitter();
  @Output() pressRejectEvent: EventEmitter<void> = new EventEmitter();
  @Output() focusLost: EventEmitter<void> = new EventEmitter();
  @Input() ignoreValidations: boolean;

  onAccept() {
    this.pressAcceptEvent.emit();
  }

  onReject() {
    this.pressRejectEvent.emit();
  }

  onFocusOut(event: FocusEvent) {
    if (event && event.relatedTarget && !event.relatedTarget['id'].includes(this.hyphenatedID)) {
      this.focusLost.emit();
    }
  }
}
