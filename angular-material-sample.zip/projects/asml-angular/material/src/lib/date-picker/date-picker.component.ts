import {Component, ElementRef, Input, Output, OnChanges, OnInit, Renderer2, ViewChild, EventEmitter} from '@angular/core';
import {AALUtil, HistoryService, Statuses} from '@asml-angular/common';
import {MatDatepicker} from '@angular/material/datepicker';
import {CommonMaterialComponentErrorStateMatcher} from '../shared/common-material-component.error-state-matcher';
import {AALDatePickerWeekComponent} from '../date-picker-week/date-picker-week.component';

@Component({
  selector: 'aal-date-picker',
  templateUrl: './date-picker.component.html',
  styleUrls: ['./date-picker.component.scss']
})
export class AALDatePickerComponent extends AALDatePickerWeekComponent implements OnInit, OnChanges {
  @Input()
  minDate: Date;
  @Output()
  onDatePickerClosed: EventEmitter<void> = new EventEmitter();
  @ViewChild('picker', {static: false}) datepicker: MatDatepicker<any>;
  initialDate: Date;
  errorStateMatcher = new CommonMaterialComponentErrorStateMatcher();
  @ViewChild('inputFieldNoMinDate', {static: false}) inputFieldNoMinDate: ElementRef;
  @ViewChild('inputFieldMinDate', {static: false}) inputFieldMinDate: ElementRef;


  constructor(renderer: Renderer2, historyService: HistoryService) {
    super(renderer, historyService);
  }

  ngOnInit() {
    super.setDefaultValue();
    if (this.minDate) {
      this.minDate.setHours(0, 0, 0, 0);
    }
  }

  ngOnChanges() {
    if (this.control && this.control.value) {
      this.initialDate = AALUtil.setDateDefaultTime(this.control.value);
    }
  }

  onClick(): void {
    super.setModeToEdit();
    setTimeout(() => {
      this.datepicker.open();
    }, 100);
  }

  dateChange(): void {
    this.control.setValue(AALUtil.getDateInISOFormat(this.control.value));
    super.triggerAcceptChanges();
  }

  clearDate(): void {
    this.control.setValue('');
    if (this.control.valid) {
      this.triggerAcceptChanges();
    }
  }

  minDateFilter = (d: Date): boolean => {
    if (d) {
      d.setHours(0, 0, 0, 0);
      if (this.initialDate) {
        return (d.getTime() === this.initialDate.getTime() ||
          d.getTime() >= this.minDate.getTime());
      } else {
        return (d.getTime() >= this.minDate.getTime());
      }
    }
  }

  onKeyUp(event: KeyboardEvent) {
    if (event.key === 'Enter') {
      this.triggerAcceptChanges();
    } else if (event.key === 'Escape') {
      this.triggerRejectChanges();
    }
  }

  datePickerClosed() {
    if (this.minDate) {
      this.inputFieldMinDate.nativeElement.focus();
    } else {
      this.inputFieldNoMinDate.nativeElement.focus();
    }
    this.onDatePickerClosed.emit();
  }

  onBlur(event) {
    if (event && event.relatedTarget && event.relatedTarget.parentElement &&
      event.relatedTarget.parentElement.id && event.relatedTarget.parentElement.id.includes(this.hyphenatedID)) {
      return;
    } else if (this.status === Statuses.DRAFT) {
      this.triggerAcceptChanges();
    }
  }

}

