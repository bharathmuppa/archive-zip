/*
 * Public API Surface of material
 */

export * from './date-picker.component';
export * from './date-picker.module';
