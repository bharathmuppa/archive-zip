import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {AALDatePickerComponent} from './date-picker.component';
import {MatDatepickerModule} from '@angular/material/datepicker';
import {MatNativeDateModule} from '@angular/material/core';
import {AALCommonComponentsModule, AALCommonModule} from '@asml-angular/common';
import {AALDatePickerWeekModule} from '../date-picker-week/date-picker-week.module';
import {FlexLayoutModule} from '@angular/flex-layout';
import {MatInputModule} from '@angular/material/input';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import {MatTooltipModule} from '@angular/material/tooltip';
import {AALOverlayCardErrorModule} from '../overlay-card-alert/overlay-card-alert.module';
import {AALOverlayCardHelpModule} from '../overlay-card-help/overlay-card-help.module';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';

@NgModule({
  declarations: [AALDatePickerComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    AALCommonModule,
    AALCommonComponentsModule,
    AALOverlayCardErrorModule,
    AALOverlayCardHelpModule,
    MatDatepickerModule,
    MatNativeDateModule,
    AALDatePickerWeekModule,
    MatInputModule,
    MatIconModule,
    MatProgressSpinnerModule,
    MatTooltipModule,
    FlexLayoutModule
  ],
  exports: [
    AALDatePickerComponent
  ]
})
export class AALDatePickerModule {
}
