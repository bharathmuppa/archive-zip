import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import {CommonModule} from '@angular/common';
import {AALCommonComponentsModule, Statuses} from '@asml-angular/common';
import {MatDatepickerModule} from '@angular/material/datepicker';
import {MatNativeDateModule} from '@angular/material/core';
import {UntypedFormControl, Validators} from '@angular/forms';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';

import {AALDatePickerComponent} from './date-picker.component';
import {AALDatePickerWeekComponent} from '../date-picker-week/date-picker-week.component';
import {SharedMaterialModule} from '../shared/shared-material.module';
import {SharedFormModule} from '../shared/shared-form.module';
import {SharedModule} from '../shared/shared.module';

import createSpyObj = jasmine.createSpyObj;

describe('AALDatePickerComponent', () => {
  let component: AALDatePickerComponent;
  let fixture: ComponentFixture<AALDatePickerComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [AALDatePickerComponent],
      imports: [
        CommonModule,
        SharedMaterialModule,
        SharedFormModule,
        SharedModule,
        AALCommonComponentsModule,
        MatDatepickerModule,
        MatNativeDateModule,
        BrowserAnimationsModule]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALDatePickerComponent);
    component = fixture.componentInstance;
    component.control = new UntypedFormControl(new Date(), Validators.compose([
      Validators.required
    ]));
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should clear control value', () => {
    component.control.setValue(new Date());
    component.ignoreValidations = true;
    spyOnProperty(component.control, 'valid').and.returnValue(true);
    fixture.detectChanges();
    component.clearDate();
    expect(component.control.value).toBe('');
  });

  it('should update the initial value field with control value', () => {
    component.control.setValue(new Date());
    component.ngOnChanges();
    fixture.detectChanges();
    expect(component.initialDate.getDate()).toBe(new Date().getDate());
  });

  it('should make changes on min date on init', () => {
    component.minDate = new Date();
    component.ngOnInit();
    expect(component.minDate.getHours()).toBe(0);
  });

  it('should compare for min date and return', () => {
    const dateValue = new Date();
    component.initialDate = dateValue;
    component.minDate = dateValue;
    const isMindate = component.minDateFilter(dateValue);
    expect(isMindate).toBe(true);
  });

  it('should compare for min date and return without initialdate', () => {
    const dateValue = new Date();
    component.minDate = dateValue;
    const isMindate = component.minDateFilter(dateValue);
    expect(isMindate).toBe(true);
  });

  it('should call dateChange function', () => {
    component.control.setValue(new Date());
    fixture.detectChanges();
    component.dateChange();
    expect(new Date(component.control.value).getDate()).toBe(new Date().getDate());
  });

  it('should emit keyboard event when escape', () => {
    spyOn(component, 'triggerRejectChanges');
    const event = new KeyboardEvent('keydown', {
      key: 'Escape'
    });
    document.dispatchEvent(event);
    component.onKeyUp(event);
    expect(component.triggerRejectChanges).toHaveBeenCalled();
  });

  it('should emit keyboard event when enter', () => {
    spyOn(component, 'triggerAcceptChanges');
    const event = new KeyboardEvent('keydown', {
      key: 'Enter'
    });
    document.dispatchEvent(event);
    component.onKeyUp(event);
    expect(component.triggerAcceptChanges).toHaveBeenCalled();
  });

  it('should call focus event when datepickerClosed is trigger', () => {
    component.inputFieldNoMinDate  = {
      nativeElement: {
        focus: () => {
        }
      }
    };
    spyOn(component.inputFieldNoMinDate.nativeElement, 'focus');
    component.datePickerClosed();
    expect(component.inputFieldNoMinDate.nativeElement.focus).toHaveBeenCalled();
  });

  it('should call focus event when datepickerClosed is trigger and minDate is set', () => {
    component.inputFieldMinDate  = {
      nativeElement: {
        focus: () => {
        }
      }
    };
    component.minDate = new Date();
    spyOn(component.inputFieldMinDate.nativeElement, 'focus');
    component.datePickerClosed();
    expect(component.inputFieldMinDate.nativeElement.focus).toHaveBeenCalled();
  });

  it('should call onBlur when focus event', () => {
    spyOn(component, 'triggerAcceptChanges');
    component.control.setValue(new Date());
    component.status = Statuses.DRAFT;
    component.onBlur(new Event('blur'));
    expect(component.triggerAcceptChanges).toHaveBeenCalled();
  });

  it('should call super method setModeToEdit when onClick is trigger', () => {
    spyOn(AALDatePickerWeekComponent.prototype, 'setModeToEdit');
    component.control.setValue(new Date());
    component.datepicker = createSpyObj('open', ['open']);
    component.onClick();
    expect(AALDatePickerWeekComponent.prototype.setModeToEdit).toHaveBeenCalled();
  });

  it('should return, when onBlur is triggered and relatedTarget is the confirm-toolbar', () => {
    component.ID = 'test';
    const parent = document.createElement('div');
    parent.id = 'test_close';
    const elem = document.createElement('div');
    parent.appendChild(elem);
    const event = new FocusEvent('focus', {relatedTarget: elem});
    const ret = component.onBlur(event);
    expect(ret).toEqual(undefined);
  });
});
