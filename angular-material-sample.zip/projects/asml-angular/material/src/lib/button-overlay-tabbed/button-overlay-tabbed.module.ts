import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AALCommonComponentsModule } from '@asml-angular/common';
import { AALButtonOverlayTabbedComponent } from './button-overlay-tabbed.component';
import {MatBadgeModule} from '@angular/material/badge';
import {AALEmptyStateModule} from '../empty-state/empty-state.module';
import {MatMenuModule} from '@angular/material/menu';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatIconModule} from '@angular/material/icon';
import {MatTabsModule} from '@angular/material/tabs';
import {MatTooltipModule} from '@angular/material/tooltip';
import {MatProgressBarModule} from '@angular/material/progress-bar';
import {MatDividerModule} from '@angular/material/divider';
import {FlexLayoutModule} from '@angular/flex-layout';
import {MatButtonModule} from '@angular/material/button';

@NgModule({
  declarations: [AALButtonOverlayTabbedComponent],
  imports: [
    CommonModule,
    AALCommonComponentsModule,
    MatBadgeModule,
    MatButtonModule,
    MatDividerModule,
    MatIconModule,
    MatMenuModule,
    MatProgressBarModule,
    MatTabsModule,
    MatToolbarModule,
    MatTooltipModule,
    AALEmptyStateModule,
    FlexLayoutModule
  ],
  exports: [AALButtonOverlayTabbedComponent]
})
export class AALButtonOverlayTabbedModule { }
