/*
 * Public API Surface of material
 */

export * from './button-overlay-tabbed.component';
export * from './button-overlay-tabbed.module';
