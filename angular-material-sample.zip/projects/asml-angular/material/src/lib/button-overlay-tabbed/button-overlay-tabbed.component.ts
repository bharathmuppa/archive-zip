import {Component, EventEmitter, Input, Output, TemplateRef, ViewChild} from '@angular/core';
import {AALCommonButtonComponent} from '@asml-angular/common';
import {MatMenuTrigger} from '@angular/material/menu';
import {ButtonType} from '@asml-angular/common/lib/models/enumeration.model';
import {MatTabGroup} from '@angular/material/tabs';

@Component({
  selector: 'aal-button-overlay-tabbed',
  templateUrl: './button-overlay-tabbed.component.html',
  styleUrls: ['./button-overlay-tabbed.component.scss']
})
export class AALButtonOverlayTabbedComponent extends AALCommonButtonComponent {
  @ViewChild(MatMenuTrigger) trigger: MatMenuTrigger;
  @ViewChild('overLayMenuTabbed', {static: false}) overLayMenuTabbed;
  @Input()
  closeOnItemClick: boolean;
  @Input()
  set panelCloseOnItemClick(val: boolean) {
    if (val) {
      this.overLayMenuTabbed.close.emit();
    }
  }
  @Input()
  disableClick: boolean;
  @Input()
  headerIcon: string;
  @Input()
  headerTitle: string;
  @Input()
  buttonLabel: string;
  @Input()
  overlayData: any;
  @Input()
  buttonIcon: string;
  @Input()
  buttonType: ButtonType;
  @Input()
  buttonTooltip: string;
  @Input()
  defaultItemImageURL: string;
  @Input()
  defaultSvgIcon: string;
  @Input()
  titleTemplateRef: TemplateRef<any>;
  @Input()
  mainDescriptionTemplateRef: TemplateRef<any>;
  @Input()
  subDescriptionTemplateRef: TemplateRef<any>;
  @Output()
  submitClick: EventEmitter<string> = new EventEmitter<string>();
  @Output()
  overlayTabbedPanelOpen: EventEmitter<string> = new EventEmitter<string>();
  @Input()
  overlayMenuXPosition: string;
  @Input()
  overlayMenuYPosition: string;
  @Input()
  itemTemplateRef: TemplateRef<any>;
  @Input()
  menuSortTemplateRef: TemplateRef<any>;
  @Input()
  largeAmountsTemplateRef: TemplateRef<any>;
  @Input()
  emptyStateTemplateRef: TemplateRef<any>;
  @Output()
  overLayTabbedListItemClick: EventEmitter<string> = new EventEmitter<string>();
  @Output()
  showAllItems: EventEmitter<void> = new EventEmitter<void>();
  @Output()
  selectedTab: EventEmitter<string> = new EventEmitter<string>();
  @Input()
  categoryName: string;
  @Input()
  categoryKey: string;
  @Input()
  subCategoryKey: string;
  @Input()
  itemKey: string;
  @Input()
  categoryItemsCount: string;
  @Input()
  subCategoryItemsCount: string;
  @Input()
  categoryItemName: string;
  @Input()
  subCategoryItemName: string;
  @Input()
  progressBar: boolean;
  @Input()
  selectedIndex: number;
  @Input()
  showAllForTabs: any[];
  @Input()
  sortMenuForTabs: any[];
  @Input()
  largeAmountsForTabs: any[];
  @Input()
  largeAmountsLength: number;
  @Input()
  defaultIconTempRef: TemplateRef<any>;
  @Input()
  isIconBorder: boolean;
  selectedTabIndex: any = 0;
  @ViewChild(MatTabGroup) tabGroup: MatTabGroup;
  overlayTabbedPanel($event) {
    this.tabGroup.realignInkBar();
    this.overlayTabbedPanelOpen.emit($event);
  }

  overLayTabbedListItem($event, tab?) {
    $event.tabData = tab ? tab : '';
    this.overLayTabbedListItemClick.emit($event);
    if (this.closeOnItemClick) {
      this.overLayMenuTabbed.close.emit();
    }
  }

  openSelectedTab($event) {
    this.selectedTabIndex = $event.index;
    this.selectedTab.emit($event);
  }

  showAll() {
    this.trigger.closeMenu();
    this.showAllItems.emit();
  }

}
