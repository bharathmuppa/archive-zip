import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import {MatMenuTrigger} from '@angular/material/menu';
import {MatBadgeModule} from '@angular/material/badge';
import {CommonModule} from '@angular/common';
import {AALCommonComponentsModule} from '@asml-angular/common';

import {SharedMaterialModule} from '../shared/shared-material.module';
import {SharedFormModule} from '../shared/shared-form.module';
import {SharedModule} from '../shared/shared.module';
import {SharedFlexLayoutModule} from '../shared/shared-flex-layout.module';
import {AALEmptyStateModule} from '../empty-state/empty-state.module';
import { AALButtonOverlayTabbedComponent } from './button-overlay-tabbed.component';

describe('ButtonOverlayTabbedComponent', () => {
  let component: AALButtonOverlayTabbedComponent;
  let fixture: ComponentFixture<AALButtonOverlayTabbedComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ AALButtonOverlayTabbedComponent ],
      imports: [
        CommonModule,
        SharedMaterialModule,
        SharedFormModule,
        AALCommonComponentsModule,
        SharedModule,
        SharedFlexLayoutModule,
        MatBadgeModule,
        AALEmptyStateModule
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALButtonOverlayTabbedComponent);
    component = fixture.componentInstance;
    component.overlayMenuXPosition = 'before';
    component.overlayMenuYPosition = 'above';
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call overlayTabbedPanel', () => {
    spyOn(component.overlayTabbedPanelOpen, 'emit');
    const $event = {value: 'sample data test'};
    component.overlayTabbedPanel($event);
    expect(component.overlayTabbedPanelOpen.emit).toHaveBeenCalled();
  });

  it('should call overLayTabbedListItem', () => {
    spyOn(component.overLayTabbedListItemClick, 'emit');
    const $event = {value: 'sample data test'};
    component.closeOnItemClick = true;
    component.overLayTabbedListItem($event);
    expect(component.overLayTabbedListItemClick.emit).toHaveBeenCalled();
  });

  it('should call openSelectedTab', () => {
    spyOn(component.selectedTab, 'emit');
    const $event = {value: 'sample data test'};
    component.openSelectedTab($event);
    expect(component.selectedTab.emit).toHaveBeenCalled();
  });

  it('should showAll', async () => {
    spyOn(component.showAllItems, 'emit');
    component.trigger = {
      closeMenu: _ => {
      }
    } as never as MatMenuTrigger;
    component.showAll();
    expect(component.showAllItems.emit).toHaveBeenCalled();
  });

  it('should close the menu, when panelCloseOnItemClick is set ', async () => {
    const spy = spyOn(component.overLayMenuTabbed.close, 'emit');
    component.trigger = {
      closeMenu: _ => {
      }
    } as never as MatMenuTrigger;
    component.panelCloseOnItemClick = true;
    expect(spy).toHaveBeenCalled();
  });

});
