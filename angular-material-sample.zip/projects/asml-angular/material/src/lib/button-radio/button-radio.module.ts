import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {AALButtonRadioComponent} from './button-radio.component';
import {AALCommonComponentsModule, AALCommonModule} from '@asml-angular/common';
import {AALOverlayCardHelpModule} from '../overlay-card-help/overlay-card-help.module';
import {AALOverlayCardErrorModule} from '../overlay-card-alert/overlay-card-alert.module';
import {AALToolbarConfirmModule} from '../toolbar-confirm/toolbar-confirm.module';
import {AALButtonTextModule} from '../button-text/button-text.module';
import {MatTooltipModule} from '@angular/material/tooltip';
import {MatRadioModule} from '@angular/material/radio';
import {FlexLayoutModule} from '@angular/flex-layout';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {MatInputModule} from '@angular/material/input';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';

@NgModule({
  declarations: [AALButtonRadioComponent],
  imports: [
    CommonModule,
    AALCommonModule,
    AALCommonComponentsModule,
    AALOverlayCardHelpModule,
    AALOverlayCardErrorModule,
    FormsModule,
    ReactiveFormsModule,
    MatInputModule,
    MatRadioModule,
    MatProgressSpinnerModule,
    AALToolbarConfirmModule,
    MatTooltipModule,
    AALButtonTextModule,
    FlexLayoutModule
  ],
  exports: [
    AALButtonRadioComponent
  ]
})
export class AALButtonRadioModule {
}
