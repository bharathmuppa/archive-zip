import {Component, Input, OnInit, TemplateRef, ViewChild} from '@angular/core';
import {AALFixedInputFormControlComponent, Modes} from '@asml-angular/common';

@Component({
  selector: 'aal-button-radio',
  templateUrl: './button-radio.component.html',
  styleUrls: ['./button-radio.component.scss']
})
export class AALButtonRadioComponent extends AALFixedInputFormControlComponent implements OnInit {
  @Input()
  layout: string;
  @Input()
  showResetIcon: boolean;
  @Input()
  alignOptionsHorizontally: boolean;
  @Input() optionLine1Field: string;
  @Input() hideClearSelection: boolean;
  @Input() optionIdField: string;
  @Input()
  optionTemplateRef: TemplateRef<any>;
  @ViewChild('radioButton') buttonRadio;

  ngOnInit() {
    this.setLayout();
    super.ngOnInit();
  }

  setLayout() {
    if (!this.layout && this.options) {
      this.layout = this.options.length > 3 ? 'column' : 'row';
    }
  }

  getLine1ByOption(option: any): string {
    return option ? option[this.optionLine1Field] : '';
  }

  resetMode(event) {
    if (event && (!event.relatedTarget || !(event.relatedTarget.classList && event.relatedTarget.id && event.relatedTarget.id.includes(this.hyphenatedID)))) {
      // Set the mode to the default mode, when focus is lost from the 'Clear Selection' button and related target is not the secondaryControl or the button toggle options
      this.mode = this.lockMode ? this.lockMode : Modes.READ;
      this.triggerAcceptChanges();
    }
  }

  onButtonRadioBlur(event) {
    if (event && event.relatedTarget && (event.relatedTarget.id && event.relatedTarget.id.includes(this.hyphenatedID) ||
      event.relatedTarget.classList && event.relatedTarget.classList.contains('mat-radio-group'))) {
      // If relatedTarget of focusOut event is the next/previous option, do nothing
      return;
    } else if (event && (!event.relatedTarget || (event.relatedTarget && !event.relatedTarget.id) ||
      (event.relatedTarget && event.relatedTarget.id && !event.relatedTarget.id.includes(this.hyphenatedID)))) {
      // when navigating to an unrelated element, set back the default mode
      this.mode = this.lockMode ? this.lockMode : Modes.READ;
      this.triggerAcceptChanges();
    }
  }

  onKeyUp(event) {
    const regex = new RegExp('^([A-Z])$');
    const children = Array.from(event.currentTarget.children) as any[];
    const key = event.key.toUpperCase();
    if (event.key === 'Escape') {
      // If Esc key is pressed and lockMode is not set, set the mode to READ
      this.mode = this.lockMode ? this.lockMode : Modes.READ;
    } else if (event.key === 'ArrowRight' || event.key === 'ArrowLeft') {
      this.mode = Modes.EDIT;
    } else if (event.key === 'Enter' && event.target) {
      event.target.click();
    } else if (regex.test(key)) {
      if (key === 'C' && this.control.value) {
        // If the key pressed is <c> or <C> and the control has a value it is cleared
        this.resetControl();
      } else {
        // Below code is to select an option based on the key typed by the user Ex: If the user presses 'A' the below code selects and saves the first option which starts with either <a> or <A>
        for (const child of children) {
          const firstChar = child.innerText.substring(0, 1).toUpperCase();
          if (firstChar === key) {
            child.children[0].click();
            break;
          }
        }
      }
    }
  }

  onClick() {
    super.onClick();
    setTimeout(() => {
      if (this.buttonRadio) {
        this.buttonRadio.focus();
      }
    }, 200);
  }
}
