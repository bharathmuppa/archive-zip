import {Component} from '@angular/core';
import {AALCommonButtonComponent} from '@asml-angular/common';

@Component({
  selector: 'aal-button-outlined',
  templateUrl: './button-outlined.component.html',
  styleUrls: ['./button-outlined.component.scss']
})
export class AALButtonOutlinedComponent extends AALCommonButtonComponent {

}
