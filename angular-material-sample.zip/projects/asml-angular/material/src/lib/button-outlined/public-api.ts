/*
 * Public API Surface of material
 */

export * from './button-outlined.component';
export * from './button-outlined.module';
