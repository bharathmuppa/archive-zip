import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { AALButtonOutlinedComponent } from './button-outlined.component';
import {CommonModule} from '@angular/common';
import {SharedMaterialModule} from '../shared/shared-material.module';
import {SharedFormModule} from '../shared/shared-form.module';
import {AALCommonComponentsModule} from '@asml-angular/common';
import {SharedModule} from '../shared/shared.module';
import {SharedFlexLayoutModule} from '../shared/shared-flex-layout.module';
import {MatBadgeModule} from '@angular/material/badge';

describe('ButtonOutlinedComponent', () => {
  let component: AALButtonOutlinedComponent;
  let fixture: ComponentFixture<AALButtonOutlinedComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ AALButtonOutlinedComponent ],
      imports: [
        CommonModule,
        SharedMaterialModule,
        SharedFormModule,
        AALCommonComponentsModule,
        SharedModule,
        SharedFlexLayoutModule,
        MatBadgeModule
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALButtonOutlinedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
