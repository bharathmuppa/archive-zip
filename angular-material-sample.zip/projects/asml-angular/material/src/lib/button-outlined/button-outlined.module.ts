import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AALButtonOutlinedComponent } from './button-outlined.component';
import {AALCommonComponentsModule} from '@asml-angular/common';
import {MatTooltipModule} from '@angular/material/tooltip';
import {MatBadgeModule} from '@angular/material/badge';
import {MatButtonModule} from '@angular/material/button';

@NgModule({
  declarations: [AALButtonOutlinedComponent],
  imports: [
    CommonModule,
    AALCommonComponentsModule,
    MatButtonModule,
    MatTooltipModule,
    MatBadgeModule
  ],
  exports: [AALButtonOutlinedComponent]
})
export class AALButtonOutlinedModule { }
