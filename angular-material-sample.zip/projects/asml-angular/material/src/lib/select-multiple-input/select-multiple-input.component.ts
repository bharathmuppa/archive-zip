import {Component} from '@angular/core';
import {AALFixedInputCompositeFormControlComponent} from '../shared/fixed-input-composite-form-control.component';

@Component({
  selector: 'aal-select-multiple-input',
  templateUrl: './select-multiple-input.component.html',
  styleUrls: ['./select-multiple-input.component.scss']
})
export class AALSelectMultipleInputComponent extends AALFixedInputCompositeFormControlComponent {
  onChange($event?: Event): void {
    if (!$event) {
      super.onChange($event);
    }
  }

  onClick(): void {
    super.onClick();
    if (this.isSecondaryControlApplicableForSelectedValue()) {
      return;
    } else {
      setTimeout(() => {
        if (this.selectField && this.selectField.trigger) {
          this.selectField.trigger.nativeElement.click();
        }
      }, 200);
    }
  }

  onKeyUp(event) {
    if (event.key === 'Enter' && this.selectField && this.selectField.panel) {
      super.triggerAcceptChanges();
    }
  }

  onBlur(event) {
    if (event && event.relatedTarget && event.relatedTarget.classList &&
      ((event.relatedTarget.id && event.relatedTarget.id.includes(this.hyphenatedID)) || event.relatedTarget.classList.contains('cdk-textarea-autosize'))) {
      // If relatedTarget of focusOut event is the secondaryControl, do nothing
      return;
    } else if (event && !event.relatedTarget) {
      this.selectField.close();
    } else {
      super.controlTabbedOut();
    }
  }
}
