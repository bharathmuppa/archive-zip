/*
 * Public API Surface of material
 */

export * from './select-multiple-input.component';
export * from './select-multiple-input.module';
