import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {CommonModule} from '@angular/common';
import {UntypedFormControl, Validators} from '@angular/forms';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {AALFixedInputFormControlComponent} from '@asml-angular/common';

import {SharedMaterialModule} from '../shared/shared-material.module';
import {SharedFormModule} from '../shared/shared-form.module';
import {SharedFlexLayoutModule} from '../shared/shared-flex-layout.module';
import {SharedModule} from '../shared/shared.module';
import {AALSelectMultipleInputComponent} from './select-multiple-input.component';
import {AALFixedInputCompositeFormControlComponent} from '../shared/fixed-input-composite-form-control.component';

describe('AALSelectMultipleInputComponent', () => {
  let component: AALSelectMultipleInputComponent;
  let fixture: ComponentFixture<AALSelectMultipleInputComponent>;
  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [AALSelectMultipleInputComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      imports: [CommonModule,
        SharedMaterialModule,
        SharedFormModule,
        SharedModule,
        SharedFlexLayoutModule,
        BrowserAnimationsModule],
    }).compileComponents().then(() => {
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALSelectMultipleInputComponent);
    component = fixture.componentInstance;
    component.control = new UntypedFormControl(['test1', 'test2', 'test3'], Validators.compose([]));
    jasmine.clock().uninstall();
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call onClick of super Component', () => {
    spyOn(AALFixedInputCompositeFormControlComponent.prototype, 'onClick');
    component.control.setValue(['option1', 'option2', 'option3']);
    component.valuesWhereSecondaryControlIsApplicable = ['option2'];
    component.onClick();
    expect(AALFixedInputCompositeFormControlComponent.prototype.onClick).toHaveBeenCalled();
  });

  it('Should call super component on trigger of onClick after timeout 200 milliSeconds', () => {
    spyOn(AALFixedInputCompositeFormControlComponent.prototype, 'onClick').and.callThrough();
    jasmine.clock().install();
    component.control.setValue('');
    fixture.detectChanges();
    component.onClick();
    // TODO Yet to write condition for else
    jasmine.clock().tick(202);
    expect(AALFixedInputCompositeFormControlComponent.prototype.onClick).toHaveBeenCalled();
    jasmine.clock().uninstall();
  });

  it('should open options list, when onClick is triggered', () => {
    spyOn(AALFixedInputFormControlComponent.prototype, 'onClick').and.callFake(() => {});
    spyOn(component, 'isSecondaryControlApplicableForSelectedValue').and.returnValue(false);
    component.selectField = {
      trigger: {
        nativeElement: {
          click: () => {}
        }
      }
    };
    const spy = spyOn(component.selectField.trigger.nativeElement, 'click');
    jasmine.clock().install();
    component.onClick();
    fixture.detectChanges();
    jasmine.clock().tick(200);
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
    jasmine.clock().uninstall();
  });

  it('should call onChange of super Component', () => {
    spyOn(AALFixedInputCompositeFormControlComponent.prototype, 'onChange').and.callThrough();
    component.onChange();
    expect(AALFixedInputCompositeFormControlComponent.prototype.onChange).toHaveBeenCalled();
  });

  it('should call triggerAcceptChanges, when onKeyUp is triggered after ENTER key is pressed', () => {
    const spy = spyOn(AALFixedInputFormControlComponent.prototype, 'triggerAcceptChanges');
    component.selectField = {
      panel: {}
    };
    component.onKeyUp({key: 'Enter'});
    expect(spy).toHaveBeenCalled();
  });

  it('should return, when onBlur is triggered and relatedTarget is the secondaryControl', () => {
    const elem = document.createElement('div');
    elem.classList.add('cdk-textarea-autosize');
    const event = new FocusEvent('focus', {relatedTarget: elem});
    const ret = component.onBlur(event);
    expect(ret).toEqual(undefined);
  });

  it('should close the options panel, when onBlur is triggered and an unrelated element is clicked', () => {
    component.selectField = {
      close: () => {}
    };
    const spy = spyOn(component.selectField, 'close');
    const event = new FocusEvent('focus', {relatedTarget: null});
    component.onBlur(event);
    expect(spy).toHaveBeenCalled();
  });

  it('should call parent controlTabbedOut method, when onBlur is triggered and TAB key is pressed', () => {
    const spy = spyOn(AALFixedInputCompositeFormControlComponent.prototype, 'controlTabbedOut');
    const elem = document.createElement('div');
    const event = new FocusEvent('focus', {relatedTarget: elem});
    component.onBlur(event);
    expect(spy).toHaveBeenCalled();
  });
});
