import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {AALSelectMultipleInputComponent} from './select-multiple-input.component';
import {AALOverlayCardHelpModule} from '../overlay-card-help/overlay-card-help.module';
import {AALOverlayCardErrorModule} from '../overlay-card-alert/overlay-card-alert.module';
import {AALToolbarConfirmModule} from '../toolbar-confirm/toolbar-confirm.module';
import {AALInputTextAreaModule} from '../input-text-area/input-text-area.module';
import {AALRichTextAreaModule} from '../rich-text-area/rich-text-area.module';
import {FlexLayoutModule} from '@angular/flex-layout';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import {MatInputModule} from '@angular/material/input';
import {MatSelectModule} from '@angular/material/select';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {MatTooltipModule} from '@angular/material/tooltip';
import {AALCommonModule} from '@asml-angular/common';

@NgModule({
  declarations: [AALSelectMultipleInputComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    AALCommonModule,
    AALToolbarConfirmModule,
    AALOverlayCardHelpModule,
    AALOverlayCardErrorModule,
    AALInputTextAreaModule,
    AALRichTextAreaModule,
    MatInputModule,
    MatProgressSpinnerModule,
    MatSelectModule,
    MatTooltipModule,
    FlexLayoutModule
  ],
  exports: [
    AALSelectMultipleInputComponent
  ]
})
export class AALSelectMultipleInputModule {
}
