import {Info} from '@asml-angular/common';

export class AssessmentQuestion {
  constructor(
    public explanation: Info,
    public ID: string,
    public question: string,
    public sequence: number,
    public answerEnumeration: AnswerEnumeration[],
    public answerPlaceholder: string,
    public answerDetailPlaceholder: string,
    public answerDetailMaxLength: number,
    public valuesWhereAnswerDetailIsApplicable: string[],
    public detailID: string,
    public isEditable: boolean,
    public disableAssessmentQuestionsFor?: string[]
    ) {}
}

export class AnswerEnumeration {
  constructor(
    public label: string,
    public value: string,
    public sequence: number
  ) {}
}

export class AssessmentAnswer {
  constructor(
    public ID: string,
    public answer: string,
    public detailID: string,
    public answerDetail: string,
    public question: string,
  ) {}
}

export class AssessmentResult {
  constructor(
    public result: string,
    public applicabilityCheck: AssessmentAnswer,
    public assessmentAnswers: AssessmentAnswer[],
    public complete: boolean
  ) {}
}
