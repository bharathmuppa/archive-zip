import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AALWizardAssessmentComponent } from './wizard-assessment.component';
import {AALOverlayCardHelpModule} from '../overlay-card-help/overlay-card-help.module';
import {AALButtonToggleInputModule} from '../button-toggle-input/button-toggle-input.module';
import {MatIconModule} from '@angular/material/icon';
import {FlexLayoutModule} from '@angular/flex-layout';

@NgModule({
  declarations: [AALWizardAssessmentComponent],
  imports: [
    CommonModule,
    AALButtonToggleInputModule,
    AALOverlayCardHelpModule,
    MatIconModule,
    FlexLayoutModule
  ],
  exports: [
    AALWizardAssessmentComponent
  ]
})
export class AALWizardAssessmentModule { }
