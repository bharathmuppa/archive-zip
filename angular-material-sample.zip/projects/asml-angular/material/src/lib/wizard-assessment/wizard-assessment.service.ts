import {AssessmentResult} from './wizard-assessment.model';
import {AcceptedChange} from '@asml-angular/common';
import {UntypedFormGroup} from '@angular/forms';

export class AALWizardAssessmentService {

  assessAnswers(assessmentResult: AssessmentResult, acceptedChange: AcceptedChange): AssessmentResult {
    return assessmentResult;
  }
  setFormCompleted(assessmentResult: AssessmentResult, assessmentWizardFormGroup: UntypedFormGroup): boolean {
    const defaultResponse = false;
    return defaultResponse ;
  }
}
