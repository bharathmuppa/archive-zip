import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {AssessmentAnswer, AssessmentQuestion, AssessmentResult} from './wizard-assessment.model';
import {AALWizardAssessmentService} from './wizard-assessment.service';
import {AcceptedChange} from '@asml-angular/common';
import {UntypedFormBuilder, UntypedFormControl, UntypedFormGroup} from '@angular/forms';

@Component({
  selector: 'aal-wizard-assessment',
  templateUrl: './wizard-assessment.component.html',
  styleUrls: ['./wizard-assessment.component.scss']
})
export class AALWizardAssessmentComponent implements OnInit {
  @Input()
  aalWizardAssessmentService: AALWizardAssessmentService;
  @Input()
  title: string;
  @Input()
  isSubmitButtonApplicable: boolean;
  @Input()
  applicabilityCheck: AssessmentQuestion;
  @Input()
  assessmentCriteria: AssessmentQuestion[];
  @Input()
  assessmentWizardFormGroup: UntypedFormGroup;
  @Input()
  fontSize: string;
  @Input()
  assessmentResultFilled: string;
  @Input()
  hideHelp: boolean;
  @Output()
  answerAcceptChanges: EventEmitter<AcceptedChange> = new EventEmitter();
  @Output()
  answerDetailAcceptChanges: EventEmitter<AcceptedChange> = new EventEmitter();
  @Output()
  assessmentSubmitted: EventEmitter<AssessmentResult> = new EventEmitter();
  @Output()
  assessmentSubmittable: EventEmitter<AssessmentResult> = new EventEmitter();
  assessmentResult: AssessmentResult;
  formCompleted: boolean;
  isAssessmentCriteriaEditable: boolean;

  constructor(private readonly formBuilder: UntypedFormBuilder) {
  }

  ngOnInit(): void {
    if (this.aalWizardAssessmentService === null || this.aalWizardAssessmentService === undefined) {
      this.aalWizardAssessmentService = new AALWizardAssessmentService();
    }
    this.isSubmitButtonApplicable = (this.isSubmitButtonApplicable === null ||
      this.isSubmitButtonApplicable === undefined) ? false : this.isSubmitButtonApplicable;
    const assessmentAnswer: AssessmentAnswer[] = this.assessmentCriteria.map(
      (assessmentCriteria: AssessmentQuestion) => {
        return new AssessmentAnswer(
          assessmentCriteria.ID,
          this.assessmentWizardFormGroup ? this.assessmentWizardFormGroup.get(assessmentCriteria.ID).value : null,
          assessmentCriteria.detailID,
          this.assessmentWizardFormGroup ? this.assessmentWizardFormGroup.get(assessmentCriteria.detailID).value : null,
          assessmentCriteria.question);
      });

    if (this.applicabilityCheck) {
      this.assessmentResult = new AssessmentResult(this.assessmentResultFilled, new AssessmentAnswer(
        this.getID(this.applicabilityCheck, 'ID'),
        this.assessmentWizardFormGroup ? this.assessmentWizardFormGroup.get(this.getID(this.applicabilityCheck, 'ID')).value : null,
        this.getID(this.applicabilityCheck, 'detailID'),
        this.assessmentWizardFormGroup ? this.assessmentWizardFormGroup.get(this.getID(this.applicabilityCheck, 'detailID')).value : null,
        this.applicabilityCheck.question), assessmentAnswer, false);
      this.assessmentResult = this.aalWizardAssessmentService.assessAnswers(this.assessmentResult, {ID: '', oldValue: '', value: ''});
      this.isAssessmentCriteriaEditable = !(this.applicabilityCheck.disableAssessmentQuestionsFor &&
        this.applicabilityCheck.disableAssessmentQuestionsFor.length > 0 &&
        this.applicabilityCheck.disableAssessmentQuestionsFor.includes(this.assessmentWizardFormGroup ?
          this.assessmentWizardFormGroup.get(this.getID(this.applicabilityCheck, 'ID')).value : ''));
    } else {
      this.assessmentResult = new AssessmentResult(this.assessmentResultFilled, null, assessmentAnswer, false);
      this.assessmentResult = this.aalWizardAssessmentService.assessAnswers(this.assessmentResult, {ID: '', oldValue: '', value: ''});
      this.isAssessmentCriteriaEditable = true;
    }


    if (!this.assessmentWizardFormGroup) {
      this.assessmentWizardFormGroup = this.formBuilder.group({});
      if (this.applicabilityCheck) {
        this.assessmentWizardFormGroup.addControl(this.getID(this.applicabilityCheck, 'ID'),
          new UntypedFormControl(''));
        this.assessmentWizardFormGroup.addControl(this.getID(this.applicabilityCheck, 'detailID'),
          new UntypedFormControl(''));
      }
      this.assessmentCriteria.forEach((assessmentCriteria: AssessmentQuestion) => {
        if (assessmentCriteria) {
          this.assessmentWizardFormGroup.addControl(this.getID(assessmentCriteria, 'ID'),
            new UntypedFormControl(''));
          this.assessmentWizardFormGroup.addControl(this.getID(assessmentCriteria, 'detailID'),
            new UntypedFormControl(''));
        }
      });
    }
    this.setStatusAndEmit();
  }

  onAnswerAcceptChanges($event: AcceptedChange) {
    this.answerAcceptChanges.emit($event);
    if (this.assessmentResult && this.assessmentResult.applicabilityCheck &&
      this.assessmentResult.applicabilityCheck.ID === $event.ID) {
      this.assessmentResult.applicabilityCheck.answer = $event.value;
      this.isAssessmentCriteriaEditable = !(this.applicabilityCheck.disableAssessmentQuestionsFor &&
        this.applicabilityCheck.disableAssessmentQuestionsFor.length > 0 &&
        this.applicabilityCheck.disableAssessmentQuestionsFor.includes($event.value));
    } else {
      const tempAssessmentAnswer: AssessmentAnswer = this.assessmentResult.assessmentAnswers.find(
        assessmentAnswer => assessmentAnswer.ID === $event.ID);
      if (tempAssessmentAnswer) {
        tempAssessmentAnswer.answer = $event.value;
      }
    }
    this.assessmentResult = this.aalWizardAssessmentService.assessAnswers(this.assessmentResult, $event);
    this.setStatusAndEmit();
  }

  onAnswerDetailAcceptChanges($event: AcceptedChange) {
    this.answerDetailAcceptChanges.emit($event);
    if (this.assessmentResult && this.assessmentResult.applicabilityCheck &&
      this.assessmentResult.applicabilityCheck.detailID === $event.ID) {
      this.assessmentResult.applicabilityCheck.answerDetail = $event.value;
    } else {
      const tempAssessmentAnswer: AssessmentAnswer = this.assessmentResult.assessmentAnswers.find(
        assessmentAnswer => assessmentAnswer.detailID === $event.ID);
      if (tempAssessmentAnswer) {
        tempAssessmentAnswer.answerDetail = $event.value;
      }
    }

    this.assessmentResult = this.aalWizardAssessmentService.assessAnswers(this.assessmentResult, $event);
    this.setStatusAndEmit();
  }

  onRevertedChanges(event) {

  }
  onSubmitAssessment() {
    this.assessmentSubmitted.emit(this.assessmentResult);
  }

  getID(assessmentQuestion: AssessmentQuestion, type: string, index?: number): any {
    if (!assessmentQuestion) {
      return;
    }
    const ID = (type === 'ID' ? assessmentQuestion.ID : assessmentQuestion.detailID);
    return (ID) ? ID :
      (assessmentQuestion.sequence) ? type + '-' + assessmentQuestion.sequence :
        (index) ? type + '-' + index : type + '-' + 'applicabilityCheck';
  }

  getControl(assessmentQuestion: AssessmentQuestion, type: string, index?: number) {
    return this.assessmentWizardFormGroup.get(this.getID(assessmentQuestion, type, index));
  }

  setStatusAndEmit() {
    this.formCompleted = this.aalWizardAssessmentService.setFormCompleted(this.assessmentResult,
      this.assessmentWizardFormGroup);
    this.assessmentResult.complete = this.formCompleted;
    this.assessmentSubmittable.emit(this.assessmentResult);
  }
}
