import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import {MatBadgeModule} from '@angular/material/badge';
import {AALCommonComponentsModule, Info} from '@asml-angular/common';
import {CommonModule} from '@angular/common';

import {SharedMaterialModule} from '../shared/shared-material.module';
import {SharedFormModule} from '../shared/shared-form.module';
import {SharedModule} from '../shared/shared.module';
import {SharedFlexLayoutModule} from '../shared/shared-flex-layout.module';
import {AALButtonToggleInputModule} from '../button-toggle-input/button-toggle-input.module';
import {AnswerEnumeration, AssessmentAnswer, AssessmentQuestion, AssessmentResult} from './wizard-assessment.model';
import {AALWizardAssessmentComponent} from './wizard-assessment.component';

describe('AALWizardAssessmentComponent', () => {
  let component: AALWizardAssessmentComponent;
  let fixture: ComponentFixture<AALWizardAssessmentComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [AALWizardAssessmentComponent],
      imports: [
        CommonModule,
        SharedMaterialModule,
        SharedFormModule,
        AALCommonComponentsModule,
        SharedModule,
        SharedFlexLayoutModule,
        MatBadgeModule,
        AALButtonToggleInputModule
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALWizardAssessmentComponent);
    component = fixture.componentInstance;
    component.assessmentCriteria = [{ID: '1', detailID: 'DID1234', question: 'Test Ques1'} as AssessmentQuestion, {ID: '2', detailID: 'DID124', question: 'Test Ques2'} as AssessmentQuestion];
    component.applicabilityCheck = {
      explanation: new Info('Sample Data', ''),
      ID: 'applicabilityCheck0',
      question: 'Sample Question',
      sequence: 0,
      answerEnumeration: [],
      answerPlaceholder: 'Sample Place holder',
      answerDetailPlaceholder: 'Sample details placeholder',
      answerDetailMaxLength: 0,
      valuesWhereAnswerDetailIsApplicable: [],
      detailID: '',
      isEditable: true,
      disableAssessmentQuestionsFor: []
    };
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have applicability check', () => {
    expect(component.isAssessmentCriteriaEditable).toBeTruthy();
  });
  it('should gets initialized if it does not have applicability check too', () => {
    component.applicabilityCheck = undefined;
    component.ngOnInit();
    expect(component.isAssessmentCriteriaEditable).toBeTruthy();
  });
  it('should return me a unique ID', () => {
    const getID = component.getID(component.applicabilityCheck, 'ID');
    expect(getID).toEqual('applicabilityCheck0');
  });
  it('should getID as nothing when Question is not passed', () => {
    component.applicabilityCheck = undefined;
    const getID = component.getID(component.applicabilityCheck, 'ID');
    expect(getID).toEqual(undefined);
  });
  it('should return form control when called getControl function', () => {
    const getID = component.getControl(component.applicabilityCheck, 'ID');
    expect(getID.value).toEqual('');
  });
  it('should call onSubmitAssessment function', () => {
    const assessmentResult = new AssessmentResult(undefined, new AssessmentAnswer(
      'applicabilityCheck0',
      null,
      'detailID-applicabilityCheck',
      null,
      'Sample Question'), [{ID: '1', detailID: 'DID1234', question: 'Test Ques1'} as AssessmentAnswer, {ID: '2', detailID: 'DID124', question: 'Test Ques2'} as AssessmentAnswer], false);
    spyOn(component.assessmentSubmitted, 'emit');
    component.onSubmitAssessment();
    expect(component.assessmentSubmitted.emit).toHaveBeenCalled();
  });
  it('should call onAcceptChanges when changes are confirmed', () => {
    spyOn(component.answerAcceptChanges, 'emit');
    component.onAnswerAcceptChanges({ID: 'assessmentCriteria1', value: 'YES', oldValue: ''});
    expect(component.answerAcceptChanges.emit).toHaveBeenCalledWith({
      ID: 'assessmentCriteria1',
      value: 'YES',
      oldValue: ''
    });
  });

  it('should call onAcceptChanges and whe ID matches', () => {
    spyOn(component.answerAcceptChanges, 'emit');
    component.onAnswerAcceptChanges({ID: 'applicabilityCheck0', value: 'YES', oldValue: ''});
    expect(component.answerAcceptChanges.emit).toHaveBeenCalledWith({
      ID: 'applicabilityCheck0',
      value: 'YES',
      oldValue: ''
    });
  });

  it('should call onAnswerDetailAcceptChanges', () => {
    spyOn(component.answerDetailAcceptChanges, 'emit');
    component.onAnswerDetailAcceptChanges({ID: 'assessmentCriteria1', value: 'YES', oldValue: ''});
    expect(component.answerDetailAcceptChanges.emit).toHaveBeenCalledWith({
      ID: 'assessmentCriteria1',
      value: 'YES',
      oldValue: ''
    });
  });

  it('should call onAnswerDetailAcceptChanges and whe ID matches', () => {
    spyOn(component.answerDetailAcceptChanges, 'emit');
    component.onAnswerDetailAcceptChanges({ID: 'applicabilityCheck0', value: 'YES', oldValue: ''});
    expect(component.answerDetailAcceptChanges.emit).toHaveBeenCalledWith({
      ID: 'applicabilityCheck0',
      value: 'YES',
      oldValue: ''
    });
  });

  /*xit('should gets initialized if it does not have applicability check too', () => {
    component.assessmentCriteria = [
      new AssessmentQuestion(
        new Info('explanation about assessmentCriteria A'),
        'Q1',
        'assessmentCriteria A question ?',
        1,
        [new AnswerEnumeration('Yes', 'YES', 1),
          new AnswerEnumeration('No', 'NO', 2),
          new AnswerEnumeration('Not Applicable', 'NA', 3)],
        'assessmentCriteria A answer place holder',
        'assessmentCriteria A answer detail place holder',
        256,
        ['YES', 'NO', 'NA'],
        'Q1Detail',
        true) ];
    // TODO Form group is not getting created
    component.ngOnInit();
    expect(component.isAssessmentCriteriaEditable).toBeTruthy();
  });*/

  it('should accept onRevertedChanges', () => {
    component.onRevertedChanges(new Event(''));
    expect(component.onRevertedChanges).toBeTruthy();
  });

  it('should accept changes when id of event match with applicability check', () => {
    component.assessmentResult.applicabilityCheck.detailID = 'applicabilityCheck0';
    component.onAnswerDetailAcceptChanges({ID: 'applicabilityCheck0', value: 'YES', oldValue: ''});
    expect(component.assessmentResult.applicabilityCheck.answerDetail).toBe('YES');
  });

  it('should accept changes when id of event match with applicability check', () => {
    component.applicabilityCheck.disableAssessmentQuestionsFor = ['YES', 'NO'];
    component.assessmentResult.assessmentAnswers = [
      {ID: 'Q1', answer: 'NO', detailID: 'applicabilityCheck0', answerDetail: 'dfsfds', question: 'assessmentCriteria A question ?'},
      {ID: 'Q2', answer: 'NO', detailID: 'Q2Detail', answerDetail: null, question: 'assessmentCriteria B question ?'},
      {ID: 'Q3', answer: null, detailID: 'Q3Detail', answerDetail: null, question: 'assessmentCriteria C question ?'},
      {ID: 'Q4', answer: null, detailID: 'Q4Detail', answerDetail: null, question: 'assessmentCriteria D question ?'}];
    component.onAnswerDetailAcceptChanges({ID: 'applicabilityCheck0', value: 'YES', oldValue: ''});
    expect(component.isAssessmentCriteriaEditable).toBe(true);
  });

  it('should accept changes for onAnswerAcceptChanges', () => {
    component.applicabilityCheck.disableAssessmentQuestionsFor = ['YES', 'NO'];
    component.assessmentResult.applicabilityCheck.ID = 'assessmentCriteria1';
    component.onAnswerAcceptChanges({ID: 'assessmentCriteria1', value: 'YES', oldValue: ''});
    expect(component.isAssessmentCriteriaEditable).toBe(  false);
  });

  it('should accept changes for onAnswerAcceptChanges', () => {
    spyOn(component, 'setStatusAndEmit');
    component.assessmentResult.assessmentAnswers = [
      {ID: 'Q1', answer: 'NO', detailID: 'applicabilityCheck0', answerDetail: 'dfsfds', question: 'assessmentCriteria A question ?'},
      {ID: 'Q2', answer: 'NO', detailID: 'Q2Detail', answerDetail: null, question: 'assessmentCriteria B question ?'},
      {ID: 'Q3', answer: null, detailID: 'Q3Detail', answerDetail: null, question: 'assessmentCriteria C question ?'},
      {ID: 'Q4', answer: null, detailID: 'Q4Detail', answerDetail: null, question: 'assessmentCriteria D question ?'}];
    component.onAnswerAcceptChanges({ID: 'Q1', value: 'YES', oldValue: ''});
    component.ngOnInit();
    expect(component.setStatusAndEmit).toHaveBeenCalled();
  });
});
