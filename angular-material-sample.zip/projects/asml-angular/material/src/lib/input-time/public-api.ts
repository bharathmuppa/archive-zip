/*
 * Public API Surface of material
 */

export * from './input-time.component';
export * from './input-time.module';
