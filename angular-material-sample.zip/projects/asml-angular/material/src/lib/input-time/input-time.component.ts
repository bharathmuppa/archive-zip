import {Component, Input, OnInit} from '@angular/core';
import {AALInputFormControlComponent, HistoryService, Info, Modes} from '@asml-angular/common';
import {CommonMaterialComponentErrorStateMatcher} from '../shared/common-material-component.error-state-matcher';

@Component({
  selector: 'aal-input-time',
  templateUrl: './input-time.component.html',
  styleUrls: ['./input-time.component.scss']
})
export class AALInputTimeComponent extends AALInputFormControlComponent implements OnInit {
  timeToRevert: string;
  pattern: RegExp;
  errorStateMatcher = new CommonMaterialComponentErrorStateMatcher();

  @Input()
  set alert(error: Info) {
    this.error = error;
    if (error) {
      this.revertChanges();
    }
  }

  constructor(historyService: HistoryService) {
    super(historyService);
    this.pattern =
      /^([01]?[0-9]|2[0-3])$|\s*^([01]?[0-9]|2[0-3])\s*[,.:]\s*(([0-5]\s*[0-9]?)|[0-9])?\s*([aApP]\s*[mM]?)?\s*/;
  }

  ngOnInit() {
    if (this.control && !this.control.value) {
      this.control.setValue('00:00');
      this.newValue = this.hmToISOFormat(this.control.value);
      this.oldValue = this.hmToISOFormat(this.control.value);
    }
    super.ngOnInit();
  }

  onBlur($event: Event) {
    /* For composite controls, when any value is selected, the focus shits to the input element. Here we are writing conditions for the scenarios when the blur event of the input control must not be called. Add the class 'skip-input-blur-event' to achieve this */
    if ($event instanceof FocusEvent && $event.relatedTarget
      && ($event.relatedTarget['classList'].contains('mat-select') || $event.relatedTarget['id'].includes(this.hyphenatedID) ||
        $event.relatedTarget['parentElement'].classList.contains('skip-input-blur-event'))) {
      // do nothing
      return;
    }
    if (this.control.valid) {
      this.sanitizeControlValue();
      this.newValue = this.hmToISOFormat(this.control.value);
      super.onBlur($event);
    }
  }

  // Overwriting the default validation messages
  getValidatorMessage(validatorKey: string): string {
    if (validatorKey.toUpperCase() === 'PATTERN') {
      return 'Use Format: 15:00 Or 3:10 PM';
    } else {
      return super.getValidatorMessage(validatorKey);
    }
  }

  triggerAcceptChanges() {
    if (this.control.valid) {
      this.sanitizeControlValue();
      this.newValue = this.hmToISOFormat(this.control.value);
      super.triggerAcceptChanges();
    }
  }

  triggerRejectChanges() {
    this.sanitizeControlValue();
    this.newValue = this.hmToISOFormat(this.control.value);
    super.triggerRejectChanges();
    this.control.setValue(this.isoToHMFormat(this.oldValue));
  }

  revertChanges() {
    this.showConfirmationToolbar = false;
    this.control.setValue(this.isoToHMFormat(this.timeToRevert));
    this.oldValue = this.timeToRevert;
    this.setMode(Modes.READ);
  }

  private sanitizeControlValue() {
// Remove spaces, Split with delimiters and filter unwanted format
    const temp = (this.control && this.control.value) ? this.control.value : '00:00';
    const splitData = temp
      .replace(/\s/g, '')
      .split(/[,:.]|(\d+)/)
      .filter(item => item !== '' && item !== undefined && item !== null);
    let hours = splitData[0] || '00';
    let minutes = splitData[1] || '00';
    let meridiem = splitData[2] || '';
// if user enters time for ex: 9pm
    if (splitData.length < 3 && isNaN(parseInt(splitData[1], 10))) {
      minutes = '00';
      meridiem = splitData[1] || '';
    }
// if user entered input has PM, Then increment hours by 12
    if (meridiem && meridiem !== '' && (meridiem.toLowerCase() === 'pm' && parseInt(hours, 10) < 12)) {
      hours = parseInt(hours, 10) + 12;
    }

// set control value, that is being displayed
    this.control.setValue(`${this.addPadding(hours)}:${this.addPadding(minutes)}`);
  }


  private isoToHMFormat(isoString: string) {
    const date = new Date(isoString);
    return `${this.addPadding(date.getHours())}:${this.addPadding(date.getMinutes())}`;
  }


  private hmToISOFormat(hmString: string) {
    const matches = hmString.match(/(\d*)[:](\d*)/);
    if (matches && matches.length === 3) {
      const hours = matches[1];
      const minutes = matches[2];

      const dateTime = new Date();
      dateTime.setHours(parseInt(hours, 10), parseInt(minutes, 10), 0, 0);
      return dateTime.toISOString();
    }
    return '';
  }

  private addPadding(pad) {
    return (parseInt(pad, 10) < 10 ? '0' : '') + parseInt(pad, 10);
  }
}
