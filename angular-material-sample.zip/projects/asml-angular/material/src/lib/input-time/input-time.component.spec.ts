import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import {AALInputFormControlComponent, Info} from '@asml-angular/common';
import {CommonModule} from '@angular/common';
import {UntypedFormControl, Validators} from '@angular/forms';

import {SharedMaterialModule} from '../shared/shared-material.module';
import {SharedFormModule} from '../shared/shared-form.module';
import {SharedFlexLayoutModule} from '../shared/shared-flex-layout.module';
import {SharedModule} from '../shared/shared.module';
import {AALInputTimeComponent} from './input-time.component';

describe('AALInputTimeComponent', () => {
  let component: AALInputTimeComponent;
  let fixture: ComponentFixture<AALInputTimeComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [AALInputTimeComponent],
      imports: [
        CommonModule,
        SharedMaterialModule,
        SharedFormModule,
        SharedModule,
        SharedFlexLayoutModule
      ]
    }).compileComponents().then(() => {
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALInputTimeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    component.control = new UntypedFormControl('actualVal', Validators.compose([]));
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should be able to get pattern validation messages', () => {
    const validatorMessage = component.getValidatorMessage('PATTERN');
    expect(validatorMessage).toBe('Use Format: 15:00 Or 3:10 PM');
  });

  it('should be able to get default validation messages', () => {
    spyOn(AALInputFormControlComponent.prototype, 'getValidatorMessage').and.returnValue('Sample');
    const validatorMessage = component.getValidatorMessage('');
    expect(validatorMessage).toContain('Sample');
  });

  it('should convert time from 12 hours format to 24 hours format when triggerAcceptChanges function is trigger', () => {
      component.control.setValue('10pm');
      component.control.setErrors(null);
      component.triggerAcceptChanges();
      expect(component.control.value).toBe('22:00');
  });

  it('should call triggerAcceptChanges function with input commas', () => {
    component.control.setValue('10,2');
    component.control.setErrors(null);
    component.triggerAcceptChanges();
    expect(component.control.value).toBe('10:02');
  });

  it('should call focus event on blur', () => {
    component.control.setValue('10:00');
    const event = new MouseEvent('focus');
    spyOn(event, 'preventDefault');
    component.onBlur(event);
  });

  it('it should accept the changes for default time', () => {
    spyOn(component, 'revertChanges');
    component.timeToRevert = '00:00';
    component.alert = new Info('Sample Title', 'Sample Help Message', '', '', null);
    fixture.detectChanges();
    expect(component.revertChanges).toHaveBeenCalled();
  });

  it('should accept the changes for revertChanges', () => {
    component.timeToRevert  = '10:00';
    component.revertChanges();
    expect(component.oldValue).toBe('10:00');
  });

  it('should call super method of triggerRejectChanges on triggerRejectChanges', () => {
    spyOn(AALInputFormControlComponent.prototype, 'triggerRejectChanges');
    component.control.setValue('10:10');
    component.oldValue = '09:00';
    component.triggerRejectChanges();
    expect(AALInputFormControlComponent.prototype.triggerRejectChanges).toHaveBeenCalled();
  });

  it('should initialize all the values when component loads', () => {
    component.control.setValue('');
    component.ngOnInit();
    expect(new Date(component.newValue).getHours()).toBe(0);
    expect(new Date(component.oldValue).getMinutes()).toBe(0);
  });

  it('should return nothing when value is set from history ', () => {
    component.control = new UntypedFormControl('10:20', Validators.required);
    const matOption = document.createElement('mat-option');
    matOption.classList.add('mat-select');
    const event = new FocusEvent('focus', {relatedTarget: matOption});
    const returnValue = component.onBlur(event);
    expect(returnValue).toBe(undefined);
  });
});
