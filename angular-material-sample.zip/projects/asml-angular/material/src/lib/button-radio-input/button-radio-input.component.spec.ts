import {ComponentFixture, TestBed, waitForAsync} from '@angular/core/testing';
import {CommonModule} from '@angular/common';
import {UntypedFormControl} from '@angular/forms';
import {AALCommonComponentsModule} from '@asml-angular/common';

import {SharedMaterialModule} from '../shared/shared-material.module';
import {SharedFormModule} from '../shared/shared-form.module';
import {AALOverlayCardHelpModule} from '../overlay-card-help/overlay-card-help.module';
import {AALOverlayCardErrorModule} from '../overlay-card-alert/overlay-card-alert.module';
import {AALToolbarConfirmModule} from '../toolbar-confirm/toolbar-confirm.module';
import {SharedFlexLayoutModule} from '../shared/shared-flex-layout.module';
import {AALButtonRadioInputComponent} from './button-radio-input.component';
import {AALRichTextAreaModule} from '../rich-text-area/rich-text-area.module';
import {AALInputTextAreaModule} from '../input-text-area/input-text-area.module';
import {AALFixedInputCompositeFormControlComponent} from '../shared/fixed-input-composite-form-control.component';

describe('AALButtonRadioInputComponent', () => {
  let component: AALButtonRadioInputComponent;
  let fixture: ComponentFixture<AALButtonRadioInputComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [AALButtonRadioInputComponent],
      imports: [
        CommonModule,
        SharedMaterialModule,
        SharedFormModule,
        AALCommonComponentsModule,
        AALOverlayCardHelpModule,
        AALOverlayCardErrorModule,
        AALToolbarConfirmModule,
        AALInputTextAreaModule,
        AALRichTextAreaModule,
        SharedFlexLayoutModule
      ]
    })
      .compileComponents().then(() => {
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALButtonRadioInputComponent);
    component = fixture.componentInstance;
    component.control = new UntypedFormControl();
    jasmine.clock().uninstall();
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call triggerAcceptChanges, when resetMode is triggered', () => {
    const spy = spyOn(component, 'triggerAcceptChanges');
    component.resetMode({
      relatedTarget: {
        classList: 'editable-div'
      }
    });
    expect(spy).toHaveBeenCalled();
  });

  it('should return line1 description, when getLine1ByOption is triggered', () => {
    component.optionLine1Field = 'line1';
    const optionText = component.getLine1ByOption({line1: 'option text'});
    expect(optionText).toBe('option text');
  });

  it('should return, when onButtonRadioBlur is triggered and related target is one of the button toggle options', () => {
    component.hyphenatedID = 'test';
    const elem = document.createElement('div');
    elem.classList.add('test');
    elem.id = 'test_button_toggle_1';
    const retValue = component.onButtonRadioBlur(new FocusEvent('blur', {relatedTarget: elem}));
    expect(retValue).toEqual(undefined);
  });

  it('should set appropriate mode, when resetMode is triggered and related target is not one of the button toggle options', () => {
    component.resetMode({relatedTarget: null});
    expect(component.mode).toBe('READ');
  });

  it('should set appropriate mode, when onButtonRadioBlur is triggered, no relatedTarget exists or related target is not one of the button toggle options', () => {
    component.onButtonRadioBlur({relatedTarget: null});
    expect(component.mode).toBe('READ');
  });

  it('should set appropriate mode, when onKeyUp is triggered and ESC key is pressed', () => {
    component.onKeyUp({
      key: 'Escape',
      currentTarget: {
        children: []
      }
    });
    expect(component.mode).toBe('READ');
  });

  it('should click the focused radio button, when onKeyUp is triggered and Enter key is pressed', () => {
    const event = {
      key: 'Enter',
      currentTarget: {
        children: []
      },
      target: {
        click: () => {}
      }
    };
    const spy = spyOn(event.target, 'click');
    component.onKeyUp(event);
    expect(component.mode).toBe('READ');
  });

  it('should select the appropriate option, when onKeyUp is triggered and an alphabet key is pressed', () => {
    const event = {
      key: 'R',
      currentTarget: {
        children: [
          {
            innerText: 'Test'
          },
          {
            innerText: 'Radio Option',
            children: [
              {
                click: () => {}
              }
            ]
          }
        ]
      }
    };
    const spy = spyOn(event.currentTarget.children[1].children[0], 'click');
    component.onKeyUp(event);
    expect(spy).toHaveBeenCalled();
  });

  it('should reset the control, when onKeyUp is triggered, the control has a value and C key is pressed', () => {
    const spy = spyOn(component, 'resetControl');
    component.control = new UntypedFormControl('Opt 1');
    component.onKeyUp({
      key: 'C',
      currentTarget: {
        children: [
          {
            innerText: 'Test'
          },
          {
            innerText: 'Radio Option'
          }
        ]
      }
    });
    expect(spy).toHaveBeenCalled();
  });

  it('should focus on the button radio, when onClick is triggered', () => {
    component.buttonRadio = {
      focus: () => {}
    };
    const spy = spyOn(component.buttonRadio, 'focus');
    jasmine.clock().install();
    component.onClick();
    jasmine.clock().tick(300);
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
    jasmine.clock().uninstall();
  });

  it('should call parent controlTabbedOut method, when onBlur is triggered and relatedTarget is an unrelated element', () => {
    const spy = spyOn(AALFixedInputCompositeFormControlComponent.prototype, 'controlTabbedOut');
    const elem = document.createElement('div');
    const event = new FocusEvent('focus', {relatedTarget: elem});
    component.onButtonRadioBlur(event);
    expect(spy).toHaveBeenCalled();
  });
});
