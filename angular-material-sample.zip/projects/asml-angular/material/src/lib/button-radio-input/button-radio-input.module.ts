import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {AALCommonComponentsModule, AALCommonModule} from '@asml-angular/common';
import {AALOverlayCardHelpModule} from '../overlay-card-help/overlay-card-help.module';
import {AALOverlayCardErrorModule} from '../overlay-card-alert/overlay-card-alert.module';
import {AALToolbarConfirmModule} from '../toolbar-confirm/toolbar-confirm.module';
import {AALButtonRadioInputComponent} from './button-radio-input.component';
import {AALInputTextAreaModule} from '../input-text-area/input-text-area.module';
import {AALButtonIconModule} from '../button-icon/button-icon.module';
import {AALButtonTextModule} from '../button-text/button-text.module';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {FlexLayoutModule} from '@angular/flex-layout';
import {MatTooltipModule} from '@angular/material/tooltip';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import {MatRadioModule} from '@angular/material/radio';
import {MatInputModule} from '@angular/material/input';
import {AALRichTextAreaModule} from "../rich-text-area/rich-text-area.module";

@NgModule({
  declarations: [AALButtonRadioInputComponent],
  imports: [
    CommonModule,
    AALCommonModule,
    FormsModule,
    ReactiveFormsModule,
    FlexLayoutModule,
    AALCommonComponentsModule,
    AALOverlayCardHelpModule,
    AALOverlayCardErrorModule,
    AALToolbarConfirmModule,
    AALInputTextAreaModule,
    AALRichTextAreaModule,
    AALButtonIconModule,
    AALButtonTextModule,
    MatInputModule,
    MatProgressSpinnerModule,
    MatRadioModule,
    MatTooltipModule,
  ],
  exports: [
    AALButtonRadioInputComponent
  ]
})
export class AALButtonRadioInputModule {
}
