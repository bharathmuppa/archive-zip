import {Component, Input, ViewChild} from '@angular/core';
import {AALFixedInputCompositeFormControlComponent} from '../shared/fixed-input-composite-form-control.component';
import {Modes} from '@asml-angular/common';

@Component({
  selector: 'aal-button-radio-input',
  templateUrl: './button-radio-input.component.html',
  styleUrls: ['./button-radio-input.component.scss']
})
export class AALButtonRadioInputComponent extends AALFixedInputCompositeFormControlComponent {

  @Input() optionLine1Field: string;
  @Input() hideClearSelection: boolean;
  @Input() optionIdField: string;
  @ViewChild('radioButton') buttonRadio;

  getLine1ByOption(option: any): string {
    return option ? option[this.optionLine1Field] : '';
  }

  resetMode(event) {
    if (event && (!event.relatedTarget || !(event.relatedTarget.classList && event.relatedTarget.id && event.relatedTarget.id.includes(this.hyphenatedID)))) {
      // Set the mode to the default mode, when focus is lost from the 'Clear Selection' button and related target is not the secondaryControl or the button toggle options
      this.mode = this.lockMode ? this.lockMode : Modes.READ;
      this.triggerAcceptChanges();
    }
  }

  onButtonRadioBlur(event) {
    if (event && event.relatedTarget && event.relatedTarget.classList &&
      ((event.relatedTarget.id && event.relatedTarget.id.includes(this.hyphenatedID)) || event.relatedTarget.classList.contains('ck')
        || event.relatedTarget.classList.contains('cdk-textarea-autosize') || event.relatedTarget.classList.contains('mat-radio-group'))) {
      // If relatedTarget of focusOut event is the next/previous option or one of the secondaryControls, do nothing
      return;
    } else if (event && (!event.relatedTarget || (event.relatedTarget.id && !event.relatedTarget.id.includes(this.hyphenatedID)))) {
      // when navigating to an unrelated element, set back the default mode
      this.mode = this.lockMode ? this.lockMode : Modes.READ;
      this.triggerAcceptChanges();
    } else {
      super.controlTabbedOut();
    }
  }

  onKeyUp(event) {
    const regex = new RegExp('^([A-Z])$');
    const children = Array.from(event.currentTarget.children) as any[];
    const key = event.key.toUpperCase();
    if (event.key === 'Escape') {
      // If Esc key is pressed and lockMode is not set, set the mode to READ
      this.mode = this.lockMode ? this.lockMode : Modes.READ;
    } else if (event.key === 'Enter' && event.target) {
      event.target.click();
    } else if (regex.test(key)) {
      if (key === 'C' && this.control.value) {
        // If the key pressed is <c> or <C> and the control has a value it is cleared
        this.resetControl();
      } else {
        // Below code is to select an option based on the key typed by the user Ex: If the user presses 'A' the below code selects and saves the first option which starts with either <a> or <A>
        for (const child of children) {
          const firstChar = child.innerText.substring(0, 1).toUpperCase();
          if (firstChar === key) {
            child.children[0].click();
            break;
          }
        }
      }
    }
  }

  onClick() {
    super.onClick();
    setTimeout(() => {
      if (this.buttonRadio) {
        this.buttonRadio.focus();
      }
    }, 200);
  }

}
