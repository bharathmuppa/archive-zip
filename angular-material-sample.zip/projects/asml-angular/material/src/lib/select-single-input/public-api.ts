/*
 * Public API Surface of material
 */

export * from './select-single-input.module';
export * from './single-select-input.component';
