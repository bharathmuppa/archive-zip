import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import {Info} from '@asml-angular/common';
import {CUSTOM_ELEMENTS_SCHEMA, ElementRef, NO_ERRORS_SCHEMA} from '@angular/core';
import {CommonModule} from '@angular/common';
import {UntypedFormControl, Validators} from '@angular/forms';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';

import {SharedMaterialModule} from '../shared/shared-material.module';
import {SharedFormModule} from '../shared/shared-form.module';
import {AALToolbarConfirmModule} from '../toolbar-confirm/toolbar-confirm.module';
import {AALOverlayCardHelpModule} from '../overlay-card-help/overlay-card-help.module';
import {AALOverlayCardErrorModule} from '../overlay-card-alert/overlay-card-alert.module';
import {AALInputTextModule} from '../input-text/input-text.module';
import {AALSelectSingleInputComponent} from './single-select-input.component';
import {AALFixedInputCompositeFormControlComponent} from '../shared/fixed-input-composite-form-control.component';

describe('AALSelectSingleInputComponent', () => {
  let component: AALSelectSingleInputComponent;
  let fixture: ComponentFixture<AALSelectSingleInputComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [AALSelectSingleInputComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
      imports: [
        CommonModule,
        SharedMaterialModule,
        SharedFormModule,
        AALToolbarConfirmModule,
        AALOverlayCardHelpModule,
        AALOverlayCardErrorModule,
        AALInputTextModule,
        BrowserAnimationsModule
      ]
    }).compileComponents().then(() => {
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALSelectSingleInputComponent);
    component = fixture.componentInstance;
    component.control = new UntypedFormControl('actual val', Validators.compose([
      Validators.required
    ]));
    component.secondaryControl = new UntypedFormControl('actual val', Validators.compose([]));
    component.help = new Info('Sample Title', 'Sample Help Message', '', '', null);
    component.options = [
      {name: 'abc', label: 'Abc', sequence: 1, isDescriptionAvailable: true},
      {name: 'xyz', label: 'Xyz', sequence: 2, isDescriptionAvailable: false}
    ];
    fixture.detectChanges();
    jasmine.clock().uninstall();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call parent onClick method, when onClick is triggered and secondaryControl exists', () => {
    const spy = spyOn(AALFixedInputCompositeFormControlComponent.prototype, 'onClick').and.callFake(() => {});
    component.onClick();
    expect(spy).toHaveBeenCalled();
  });

  it('should open optionsPanel, when onClick is triggered and secondaryControl does not exist', () => {
    spyOn(AALFixedInputCompositeFormControlComponent.prototype, 'onClick').and.callFake(() => {});
    component.selectField = {
      trigger: new ElementRef<any>({
        click: () => {}
      })
    };
    spyOn(component, 'isSecondaryControlApplicableForSelectedValue');
    const spy = spyOn(component.selectField.trigger.nativeElement, 'click').and.callFake(() => {});
    jasmine.clock().install();
    component.onClick();
    jasmine.clock().tick(300);
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
    jasmine.clock().uninstall();
  });

  it('should return, when onBlur is triggered and relatedTarget is the secondaryControl', () => {
    const elem = document.createElement('div');
    elem.classList.add('cdk-textarea-autosize');
    const event = new FocusEvent('focus', {relatedTarget: elem});
    const ret = component.onBlur(event);
    expect(ret).toEqual(undefined);
  });

  it('should call parent controlTabbedOut method, when onBlur is triggered and relatedTarget is an unrelated element', () => {
    const spy = spyOn(AALFixedInputCompositeFormControlComponent.prototype, 'controlTabbedOut');
    const elem = document.createElement('div');
    const event = new FocusEvent('focus', {relatedTarget: elem});
    component.onBlur(event);
    expect(spy).toHaveBeenCalled();
  });
});
