import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {AALSelectSingleInputComponent} from './single-select-input.component';
import {AALToolbarConfirmModule} from '../toolbar-confirm/toolbar-confirm.module';
import {AALOverlayCardHelpModule} from '../overlay-card-help/overlay-card-help.module';
import {AALOverlayCardErrorModule} from '../overlay-card-alert/overlay-card-alert.module';
import {AALInputTextAreaModule} from "../input-text-area/input-text-area.module";
import {FlexLayoutModule} from '@angular/flex-layout';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import {MatInputModule} from '@angular/material/input';
import {MatSelectModule} from '@angular/material/select';
import {MatIconModule} from '@angular/material/icon';
import {MatTooltipModule} from '@angular/material/tooltip';
import {AALCommonModule} from '@asml-angular/common';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';

@NgModule({
  declarations: [AALSelectSingleInputComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    AALCommonModule,
    AALToolbarConfirmModule,
    AALOverlayCardHelpModule,
    AALOverlayCardErrorModule,
    AALInputTextAreaModule,
    MatIconModule,
    MatInputModule,
    MatProgressSpinnerModule,
    MatSelectModule,
    MatTooltipModule,
    FlexLayoutModule
  ],
  exports: [
    AALSelectSingleInputComponent
  ]
})
export class AALSelectSingleInputModule {
}
