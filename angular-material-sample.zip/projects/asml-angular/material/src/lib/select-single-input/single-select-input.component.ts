import {Component} from '@angular/core';
import {AALFixedInputCompositeFormControlComponent} from '../shared/fixed-input-composite-form-control.component';

@Component({
  selector: 'aal-select-single-input',
  templateUrl: './select-single-input.component.html',
  styleUrls: ['./select-single-input.component.scss']
})
export class AALSelectSingleInputComponent extends AALFixedInputCompositeFormControlComponent {

  onClick(): void {
    super.onClick();
    if (this.isSecondaryControlApplicableForSelectedValue()) {
      return;
    } else {
      setTimeout(() => {
        if (this.selectField && this.selectField.trigger) {
          this.selectField.trigger.nativeElement.click();
        }
      }, 200);
    }
  }

  onBlur(event) {
    if (event && event.relatedTarget && event.relatedTarget.classList &&
      ((event.relatedTarget.id && event.relatedTarget.id.includes(this.hyphenatedID)) || event.relatedTarget.classList.contains('cdk-textarea-autosize'))) {
      // If relatedTarget of focusOut event is the secondaryControl, do nothing
      return;
    } else {
      super.controlTabbedOut();
    }
  }
}
