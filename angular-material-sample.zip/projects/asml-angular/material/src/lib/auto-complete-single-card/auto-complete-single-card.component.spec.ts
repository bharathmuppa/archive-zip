import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import {MatOption} from '@angular/material/core';
import {MatAutocompleteTrigger} from '@angular/material/autocomplete';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {CommonModule} from '@angular/common';
import {UntypedFormControl} from '@angular/forms';

import {AALAutoCompleteSingleCardComponent} from './auto-complete-single-card.component';
import {SharedMaterialModule} from '../shared/shared-material.module';
import {SharedFormModule} from '../shared/shared-form.module';
import {SharedFlexLayoutModule} from '../shared/shared-flex-layout.module';
import {SharedModule} from '../shared/shared.module';
import {AALCardSummaryModule} from '../card-summary/card-summary.module';

describe('AALAutoCompleteSingleCardComponent', () => {
  let component: AALAutoCompleteSingleCardComponent;
  let fixture: ComponentFixture<AALAutoCompleteSingleCardComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [AALAutoCompleteSingleCardComponent],
      imports: [CommonModule,
        SharedMaterialModule,
        SharedFormModule,
        SharedModule,
        SharedFlexLayoutModule,
        AALCardSummaryModule,
        BrowserAnimationsModule]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALAutoCompleteSingleCardComponent);
    component = fixture.componentInstance;
    component.control = new UntypedFormControl('');
    component.itemDisplayField = 'name';
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should trigger setInputValue, when control value is set', () => {
    const spy = spyOn(component, 'setInputValue');
    component.control = new UntypedFormControl('Test');
    expect(spy).toHaveBeenCalled();
  });

  it('should set oldValueUpdated, when frmControl value changes for the first time', () => {
    component.control = new UntypedFormControl('Test');
    component.frmControl.setValue({});
    fixture.detectChanges();
    expect(component.oldValueUpdated).toEqual(true);
  });

  it('should call setInputValue, when onClick is triggered', () => {
    const spy = spyOn(component, 'setInputValue');
    component.control = new UntypedFormControl('Test');
    component.onClick();
    expect(spy).toHaveBeenCalled();
  });

  it('should empty the control value', () => {
    const value = {name: 'abc', abbr: 'ab', id: 1};
    component.control.setValue(value);
    component.emptyControl();
    expect(component.control.value).toBe('');
  });

  it('should call accept changes on item select', () => {
    const value = {name: 'abc', abbr: 'ab', id: 1};
    component.control.setValue(value);
    const acceptChangesSpy = spyOn(component, 'triggerAcceptChanges').and.returnValue(null);
    component.onItemSelected({});
    expect(acceptChangesSpy).toHaveBeenCalled();
  });

  it('should return appropriate text, when getDisplayText is called with a string value', () => {
    component.displayFields = [];
    const displaytext = component.getDisplayText('Test');
    expect(displaytext).toEqual('Test');
  });

  it('should return appropriate text, when getDisplayText is triggered and displayFields has 1 item', () => {
    component.displayFields = ['label'];
    const displaytext = component.getDisplayText({label: 'The value is', value: 'Test'});
    expect(displaytext).toEqual('The value is');
  });

  it('should return appropriate text, when getDisplayText is triggered and displayFields has 2 items', () => {
    component.displayFields = ['label', 'value'];
    const displaytext = component.getDisplayText({label: 'The value is', value: 'Test'});
    expect(displaytext).toEqual('The value is (Test)');
  });

  it('should return appropriate text, when getDisplayText is triggered and displayFields has more than 2 items', () => {
    component.displayFields = ['name', 'abbr', 'dept'];
    const displaytext = component.getDisplayText({name: 'Test User', abbr: 'TST', dept: 'Automation'});
    expect(displaytext).toEqual('Test User - TST - Automation');
  });

  it('should return empty string, when getDisplayText is triggered and displayFields does not exist', () => {
    component.displayFields = [];
    const displaytext = component.getDisplayText({name: 'Test User', abbr: 'TST', dept: 'Automation'});
    expect(displaytext).toEqual('');
  });

  it('should return appropriate value, when getImageURL is triggered and control value has a photoURL', () => {
    component.control.setValue({
      photoURL: 'Test'
    });
    const imageURL = component.getImageURL();
    expect(imageURL).toEqual('Test');
  });

  it('should return appropriate value, when getImageURL is triggered and createImageUrlFn exists', () => {
    component.createImageUrlFn = (val) => {
      return 'Test';
    };
    component.control.setValue('Val');
    const imageURL = component.getImageURL();
    expect(imageURL).toEqual('Test');
  });

  it('should return appropriate value, when getImageURL is triggered and itemImageURL exists', () => {
    component.itemImageURL = 'Test';
    component.control.setValue('Val');
    const imageURL = component.getImageURL();
    expect(imageURL).toEqual('Test');
  });

  it('should return appropriate value, when getImageURL is triggered and fallbackImageURL exists', () => {
    component.fallbackImageURL = 'Test';
    component.control.setValue('Val');
    const imageURL = component.getImageURL();
    expect(imageURL).toEqual('Test');
  });

  it('should return appropriate text, when getMainDescription is triggered and displayFields has 2 items', () => {
    component.displayFields = ['label', 'value'];
    const displaytext = component.getMainDescription({label: 'The value is', value: 'Test'});
    expect(displaytext).toEqual('The value is (Test)');
  });

  it('should return appropriate text, when getMainDescription is triggered and displayFields has more than 2 items', () => {
    component.displayFields = ['name', 'abbr', 'dept'];
    const displaytext = component.getMainDescription({name: 'Test User', abbr: 'TST', dept: 'Automation'});
    expect(displaytext).toEqual('Test User - TST - Automation');
  });

  it('should prevent default implementation when, on blur is triggered & relatedTarget is clear button', () => {
    const mockEvent = {
      relatedTarget: {
        id: 'test_close',
        click: () => ''
      },
      preventDefault: () => {}
    };
    const evt = spyOn(mockEvent, 'preventDefault');
    component.ID = 'test';
    component.matAutoComplete = jasmine.createSpyObj('isOpen', ['']);
    component.onInputBlur(mockEvent);
    expect(evt).toHaveBeenCalled();
  });

  it('should call onInputBlur function if onblur is not triggered to display old values', () => {
    component.control.setValue('new value');
    const event = new MouseEvent('blur');
    spyOn(event, 'preventDefault');
    component.onInputBlur(event);
    fixture.detectChanges();
    expect(component.oldValue).toBe('new value');
  });

  it('should call onItemSelected, when onKeyUp is triggered after SPACE key is pressed', () => {
    spyOn(component, 'onItemSelected');
    component.autoTrigger = {
      get activeOption(): MatOption | null {
        return {} as MatOption;
      }
    } as MatAutocompleteTrigger;
    const event = new KeyboardEvent('keyup', {
      key: ' '
    });
    component.onKeyUp(event);
    expect(component.onItemSelected).toHaveBeenCalled();
  });

  it('should click on the element, when onBlur is triggered and related target is the autocomplete options list', () => {
    component.onClick();
    fixture.detectChanges();
    spyOnProperty(component.matAutoComplete, 'isOpen').and.returnValue(true);
    const mockEvent = {
      relatedTarget: {
        id: 'test',
        click: () => ''
      }
    };
    const relatedTargetClick = spyOn(mockEvent.relatedTarget, 'click');
    component.onInputBlur(mockEvent);
    expect(relatedTargetClick).toHaveBeenCalled();
  });
});
