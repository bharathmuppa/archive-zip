import {Component, EventEmitter, Input, OnInit, Output, ViewChild, AfterViewInit} from '@angular/core';
import {MatSort, Sort} from '@angular/material/sort';
import {SortingConfiguration, SortingHeaderConfiguration} from '../shared/list-item-configuration.model';

@Component({
  selector: 'aal-menu-sort',
  templateUrl: './menu-sort.component.html',
  styleUrls: ['./menu-sort.component.scss']
})
export class AALMenuSortComponent implements OnInit, AfterViewInit {

  @Input()
  sortConfiguration: SortingConfiguration;
  @Input()
  initialSort: Sort;
  @Input()
  disableSortClear: boolean;
  @Input()
  sortFromOfItem: boolean;
  @Input()
  listType: string;
  @Input()
  ID: string;

  @ViewChild(MatSort, {static: false}) sort: MatSort;
  @Output()
  readonly sortChange: EventEmitter<Sort> = new EventEmitter<Sort>();
  _showCustomArrow: boolean;
  _firstMenuItemClick: boolean;


  constructor() {
  }

  ngOnInit() {
    this._showCustomArrow = true;
    this._firstMenuItemClick = true;
  }

  ngAfterViewInit() {
    this.setSort(this.initialSort);
  }

  sortData(sort: Sort) {
    console.log(sort);
    this.sortChange.emit(sort);
  }

  menuClose(): void {
    this._showCustomArrow = true;
  }

  menuItemClick($event): void {
    if (this._firstMenuItemClick) {
      this._showCustomArrow = false;
      this._firstMenuItemClick = false;
    }
    $event.stopPropagation();
  }

  listItemClick(header: SortingHeaderConfiguration) {
    console.log({active: header.id, direction: header.direction === 'asc' ? 'asc' : 'desc'});
    this.sortChange.emit({active: header.id, direction: header.direction === 'asc' ? 'asc' : 'desc'});
  }

  showSortArrow(currentDirection: string, currentHeader: string): boolean {
    const returnVal = (this.sort && this.sort.active === currentHeader && this.sort.direction === currentDirection && this._showCustomArrow);
    return returnVal;
  }

  setSort(sort: Sort): void {
    if (sort) {
      this.sort.active = sort.active;
      this.sort.direction = sort.direction;
    }
  }

}

