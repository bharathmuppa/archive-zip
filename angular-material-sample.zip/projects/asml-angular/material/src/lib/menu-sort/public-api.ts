/*
 * Public API Surface of material
 */

export * from './menu-sort.component';
export * from './menu-sort.module';
