import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import {CommonModule} from '@angular/common';
import {AALCommonComponentsModule} from '@asml-angular/common';
import {MatBadgeModule} from '@angular/material/badge';
import {Sort} from '@angular/material/sort';

import {SharedMaterialModule} from '../shared/shared-material.module';
import {SharedFormModule} from '../shared/shared-form.module';
import {SharedModule} from '../shared/shared.module';
import {SharedFlexLayoutModule} from '../shared/shared-flex-layout.module';
import { AALMenuSortComponent } from './menu-sort.component';

describe('AALMenuSortComponent', () => {
  let component: AALMenuSortComponent;
  let fixture: ComponentFixture<AALMenuSortComponent>;
  let sort;
  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ AALMenuSortComponent ],
      imports: [
        CommonModule,
        SharedMaterialModule,
        SharedFormModule,
        AALCommonComponentsModule,
        SharedModule,
        SharedFlexLayoutModule,
        MatBadgeModule
      ]

    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALMenuSortComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call sortData', () => {
    sort = {
      active: 'createdOn',
      direction: 'asc'
    };
    component.sortData(sort);
    expect(component).toBeTruthy();
  });

  it('should call menuClose', () => {
    component._showCustomArrow = false;
    component.menuClose();
    expect(component._showCustomArrow).toBe(true);
  });

  it('should call menuItemClick', () => {
    component._firstMenuItemClick = true;
    const event = new MouseEvent('click');
    component.menuItemClick(event);
    expect(component._showCustomArrow).toBe(false);
    expect(component._firstMenuItemClick).toBe(false);
  });

  it('should call showSortArrow', () => {
    const currentDirection = 'desc';
    const currentHeader = 'action.deadline';
    expect(component.showSortArrow(currentDirection, currentHeader)).toBe(false);
  });

  it('should call setSort', () => {
    const sortObject = {
      active: 'Created Date',
      direction: 'asc'
    } as Sort;
    component.setSort(sortObject);
    expect(component.sort.direction).toBe('asc');
  });

  it('should emit event when listItemClick called', () => {
    // spy on event emitter
    spyOn(component.sortChange, 'emit');
    const header = { label: 'Status of CR ', id: 'status' , sortDesc: '(\'Draft\' first)', direction: 'asc'};
    component.listItemClick(header);
    expect(component.sortChange.emit).toHaveBeenCalledWith({active: 'status', direction: 'asc'});
  });

});
