import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {animate, state, style, transition, trigger} from '@angular/animations';
import {UntypedFormControl} from '@angular/forms';
import {Info, Mode, Modes} from '@asml-angular/common';

@Component({
  selector: 'aal-collapsible-panel',
  templateUrl: './collapsible-panel.component.html',
  styleUrls: ['./collapsible-panel.component.scss'],
  animations: [
    trigger('indicatorRotate', [
      state('collapsed', style({transform: 'rotate(0deg)'})),
      state('expanded', style({transform: 'rotate(180deg)'})),
      transition('expanded <=> collapsed',
        animate('225ms cubic-bezier(0.4,0.0,0.2,1)')
      ),
    ])
  ]
})
export class AALCollapsiblePanelComponent implements OnInit {

  @Input()
  isPanelExpanded = true;
  @Input()
  isTitleEditable: boolean;
  @Input()
  panelTitle: string;

  @Input()
  OutlineShowButton: boolean;
  @Input()
  OutLineButtonName: string;
  @Input()
  OutLinetooltip: string;
  @Input()
  OutlinehasBadge: boolean;
  @Input()
  OutlinebadgeData: string;
  @Input()
  OutlinereferenceBadgeData: string;
  @Input()
  OutlinebadgeType: string;
  @Input()
  OutlineiConName: string;
  @Input()
  ID: string;
  @Input()
  alert: string;
  @Input()
  control: UntypedFormControl;
  @Input()
  help: Info;
  @Input()
  isBusy: boolean;
  @Input()
  isHistoryEnabled: boolean;
  @Input()
  mode: Mode;
  @Input()
  placeholder: string;
  @Input()
  showLengthHint: boolean;

  showSpinner: boolean;
  @Input()
  errorAlert: Info;
  @Input()
  warnAlert: Info;
  modes = Modes;


  @Output()
  readonly collapsibleButton: EventEmitter<void> = new EventEmitter<void>();
  @Output()
  acceptChangesOn: EventEmitter<void> = new EventEmitter();
  @Output()
  rejectChangesOn: EventEmitter<void> = new EventEmitter();

  buttonClick($event): void {
    this.collapsibleButton.emit($event);
  }

  ngOnInit() {
  }

  onAcceptChanges($event) {
    this.acceptChangesOn.emit($event);
  }

  onRejectChanges($event) {
    this.rejectChangesOn.emit($event);
  }
}
