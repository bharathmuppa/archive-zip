/*
 * Public API Surface of material
 */

export * from './collapsible-panel.component';
export * from './collapsible-panel.module';
