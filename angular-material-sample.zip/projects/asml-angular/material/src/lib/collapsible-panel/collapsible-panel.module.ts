import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {AALCollapsiblePanelComponent} from './collapsible-panel.component';
import {AALCommonComponentsModule} from "@asml-angular/common";
import {AALOverlayCardHelpModule} from "../overlay-card-help/overlay-card-help.module";
import {AALOverlayCardErrorModule} from "../overlay-card-alert/overlay-card-alert.module";
import {AALToolbarConfirmModule} from "../toolbar-confirm/toolbar-confirm.module";
import { MatIconModule} from '@angular/material/icon';
import {MatExpansionModule} from '@angular/material/expansion';
import {AALButtonIconOutlinedModule} from '../button-icon-outlined/button-icon-outlined.module';
import { AALInputTextModule  } from '../input-text/input-text.module';
import {FlexLayoutModule} from '@angular/flex-layout';
import {MatDividerModule} from '@angular/material/divider';

@NgModule({
  declarations: [AALCollapsiblePanelComponent],
  imports: [
    CommonModule,
    AALCommonComponentsModule,
    AALOverlayCardHelpModule,
    AALOverlayCardErrorModule,
    AALToolbarConfirmModule,
    MatExpansionModule,
    MatIconModule,
    AALButtonIconOutlinedModule,
    AALInputTextModule,
    MatDividerModule,
    FlexLayoutModule
  ],
  exports: [AALCollapsiblePanelComponent]
})
export class AALCollapsiblePanelModule {
}
