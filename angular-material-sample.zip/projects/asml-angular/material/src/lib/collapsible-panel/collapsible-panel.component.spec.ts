import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import {animate, state, style, transition, trigger} from '@angular/animations';
import {FormBuilder, FormControl, Validators} from '@angular/forms';
import {Info, Mode, Modes} from '@asml-angular/common';
import { AALCollapsiblePanelComponent } from './collapsible-panel.component';
import {CommonModule} from '@angular/common';
import {SharedMaterialModule} from '../shared/shared-material.module';
import {SharedFormModule} from '../shared/shared-form.module';
import {AALCommonComponentsModule} from '@asml-angular/common';
import {SharedModule} from '../shared/shared.module';
import {SharedFlexLayoutModule} from '../shared/shared-flex-layout.module';
import {MatBadgeModule} from '@angular/material/badge';
import {AALInputTextModule} from '../input-text/input-text.module';
import {AALButtonIconOutlinedModule} from '../button-icon-outlined/button-icon-outlined.module';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';

describe('CollapsiblePanelComponent', () => {
  let component: AALCollapsiblePanelComponent;
  let fixture: ComponentFixture<AALCollapsiblePanelComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ AALCollapsiblePanelComponent ],
      imports: [
        CommonModule,
        SharedMaterialModule,
        SharedFormModule,
        AALCommonComponentsModule,
        SharedModule,
        SharedFlexLayoutModule,
        MatBadgeModule,
        AALInputTextModule,
        AALButtonIconOutlinedModule,
        BrowserAnimationsModule
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALCollapsiblePanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should emit collapsibleButton, when buttonClick is triggered', () => {
    const spy = spyOn(component.collapsibleButton, 'emit');
    component.buttonClick({});
    expect(spy).toHaveBeenCalled();
  });

  it('should emit acceptChangesOn, when onAcceptChanges is triggered', () => {
    const spy = spyOn(component.acceptChangesOn, 'emit');
    component.onAcceptChanges({});
    expect(spy).toHaveBeenCalled();
  });

  it('should emit rejectChangesOn, when onRejectChanges is triggered', () => {
    const spy = spyOn(component.rejectChangesOn, 'emit');
    component.onRejectChanges({});
    expect(spy).toHaveBeenCalled();
  });
});
