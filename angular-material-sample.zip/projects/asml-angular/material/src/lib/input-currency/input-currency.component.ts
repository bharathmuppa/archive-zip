import {Component, Input} from '@angular/core';
import {getCurrencySymbol} from '@angular/common';
import {AALInputFormControlComponent, HistoryService} from '@asml-angular/common';
import {CommonMaterialComponentErrorStateMatcher} from '../shared/common-material-component.error-state-matcher';

const DEFAULT_DECIMAL_SEPARATOR = ',';
const DEFAULT_THOUSANDS_SEPARATOR = '.';
const DEFAULT_MIN_INTEGER_DIGITS = 1;
const DEFAULT_MIN_FRACTION_DIGITS = 0;
const DEFAULT_MAX_FRACTION_DIGITS = 0;

@Component({
  selector: 'aal-input-currency',
  templateUrl: './input-currency.component.html',
  styleUrls: ['./input-currency.component.scss']
})
export class AALInputCurrencyComponent extends AALInputFormControlComponent {
  @Input()
  currencyCode: string;
  @Input()
  decimalSeparator: string = DEFAULT_DECIMAL_SEPARATOR;
  @Input()
  thousandsSeparator: string = DEFAULT_THOUSANDS_SEPARATOR;
  @Input()
  minIntegerDigits: number = DEFAULT_MIN_INTEGER_DIGITS;
  @Input()
  minFractionDigits: number = DEFAULT_MIN_FRACTION_DIGITS;
  @Input()
  maxFractionDigits: number = DEFAULT_MAX_FRACTION_DIGITS;
  @Input()
  isNegativeCurrency: boolean;
  @Input()
  allowSpecialCharacters: boolean;
  @Input()
  set validationPattern(value: string) {
    if (value) {
      this.regex = new RegExp(value);
      this.validationRegex = value;
    }
  }
  private validationRegex: string;
  regex: RegExp;
  errorStateMatcher = new CommonMaterialComponentErrorStateMatcher();
  invalidChars = [
    '-',
    '+',
    'e',
  ];
  constructor(historyService: HistoryService) {
    super(historyService);
  }

  ngOnInit() {
    this.regex = this.validationRegex ? new RegExp(this.validationRegex) : /^-?\d+$/;
    super.ngOnInit();
  }

  onBlur($event?: Event) {
    /* For composite controls, when any value is selected, the focus shits to the input element. Here we are writing conditions for the scenarios when the blur event of the input control must not be called. Add the class 'skip-input-blur-event' to achieve this */
    if ($event instanceof FocusEvent && $event.relatedTarget
      && ($event.relatedTarget['classList'].contains('mat-select') || $event.relatedTarget['id'].includes(this.hyphenatedID) ||
        $event.relatedTarget['parentElement'].classList.contains('skip-input-blur-event'))) {
      // do nothing
      return;
    }
    this.sanitizeInputValue(true);
    super.onBlur($event);
  }


  getValidatorMessage(validatorKey: string): string {
    if (validatorKey.toUpperCase() === 'PATTERN') {
      return 'Use Format: -123 Or 123';
    } else {
      return super.getValidatorMessage(validatorKey);
    }
  }

  getCurrencySymbol(): string {
    return this.currencyCode ? getCurrencySymbol(this.currencyCode, 'narrow') : '';
  }

  toNumber(data: string): number {
    return +data;
  }

  getDisplayFormat(): string {
    return `${this.minIntegerDigits}.${this.minFractionDigits}-${this.maxFractionDigits}`;
  }

  sanitizeInputValue(triggerSanitizeInput: boolean, event?) {
    if (this.isNegativeCurrency && ((event && event.key === 'Enter') || triggerSanitizeInput)) {
      if (this.toNumber(this.control.value) < 1) {
        this.control.setValue(Math.abs(this.toNumber(this.control.value)).toString());
      }
    }
  }

  onKeyDown(event: KeyboardEvent): void {
    // block special character from input field unless explicitly asked for
    if (this.invalidChars.includes(event.key) && !this.allowSpecialCharacters) {
      event.preventDefault();
    }
  }

}
