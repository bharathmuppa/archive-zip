/*
 * Public API Surface of material
 */

export * from './wizard-assessment-dialog.component';
export * from './wizard-assessment-dialog.module';
