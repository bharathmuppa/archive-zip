import {Component, Inject, OnInit} from '@angular/core';
import {AbstractControl, UntypedFormArray, UntypedFormControl, UntypedFormGroup} from '@angular/forms';
import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material/dialog';
import {AssessmentQuestion, AssessmentResult} from '../wizard-assessment/wizard-assessment.model';
import {AALWizardAssessmentService} from '../wizard-assessment/wizard-assessment.service';

@Component({
  selector: 'aal-wizard-assessment-dialog',
  templateUrl: './wizard-assessment-dialog.component.html',
  styleUrls: ['./wizard-assessment-dialog.component.scss']
})
export class AALWizardAssessmentDialogComponent implements OnInit {
  result: string;
  title: string;
  impact: string;
  assessmentResult: AssessmentResult;
  applicabilityCheck: AssessmentQuestion;
  assessmentCriteria: AssessmentQuestion[];
  assessmentWizardFormGroup: UntypedFormGroup;
  assessmentWizardFormGroupBackup: UntypedFormGroup;
  aalWizardAssessmentService: AALWizardAssessmentService;
  submitEnabled: boolean;
  isSubmitApplicable: boolean;
  constructor(private readonly dialogRef: MatDialogRef<AALWizardAssessmentDialogComponent>,
              @Inject(MAT_DIALOG_DATA) public data: any) {
  }

  ngOnInit() {
    this.result = '';
    this.title = this.data.title;
    this.applicabilityCheck = this.data.applicabilityCheck;
    this.assessmentCriteria = this.data.assessmentCriteria;
    this.assessmentWizardFormGroup = this.data.assessmentWizardFormGroup;
    this.assessmentResult = this.data.assessmentResult;
    this.assessmentWizardFormGroupBackup = this.createBackup(this.data.assessmentWizardFormGroup) as UntypedFormGroup;
    this.aalWizardAssessmentService = this.data.aalWizardAssessmentService;
    this.isSubmitApplicable = this.data.isSubmitApplicable;
  }

  cancel(): void {
    this.restoreBackup();
    this.dialogRef.close();
  }

  submit(): void {
    this.dialogRef.close(this.assessmentResult);
  }

  assessmentSubmittable($event: AssessmentResult) {
    if ($event) {
      this.submitEnabled = $event.complete;
      this.result = $event.result;
      this.assessmentResult = $event;
    }
  }

  answerAcceptChanges($event) {
    this.result = $event.result;
    this.assessmentResult = $event;
  }

  answerDetailAcceptChanges($event) {
    this.result = $event.result;
    this.assessmentResult = $event;
  }

  restoreBackup() {
    this.assessmentWizardFormGroup.patchValue(this.assessmentWizardFormGroupBackup.value);
  }

  createBackup(control: AbstractControl): UntypedFormGroup | UntypedFormControl | UntypedFormArray {
    if (control instanceof UntypedFormControl) {
      return new UntypedFormControl(control.value);
    } else if (control instanceof UntypedFormGroup) {
      const copy = new UntypedFormGroup({});
      Object.keys(control.getRawValue()).forEach(key => {
        copy.addControl(key, this.createBackup(control.controls[key]));
      });
      return copy;
    } else if (control instanceof UntypedFormArray) {
      const copy = new UntypedFormArray([]);
      control.controls.forEach(localControl => {
        copy.push(this.createBackup(localControl));
      });
      return copy;
    } else {
      return new UntypedFormGroup({});
    }
  }

}
