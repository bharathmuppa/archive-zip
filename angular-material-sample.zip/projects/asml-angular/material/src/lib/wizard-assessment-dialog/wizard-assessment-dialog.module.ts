import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {AALOverlayCardHelpModule} from '../overlay-card-help/overlay-card-help.module';
import {AALButtonToggleInputModule} from '../button-toggle-input/button-toggle-input.module';
import {AALWizardAssessmentDialogComponent} from './wizard-assessment-dialog.component';
import {AALWizardAssessmentModule} from '../wizard-assessment/wizard-assessment.module';
import {AALRichTextAreaModule} from '../rich-text-area/rich-text-area.module';
import {MatIconModule} from '@angular/material/icon';
import {MatDialogModule} from '@angular/material/dialog';
import {FlexLayoutModule} from '@angular/flex-layout';
import {MatButtonModule} from '@angular/material/button';

@NgModule({
  declarations: [AALWizardAssessmentDialogComponent],
  imports: [
    CommonModule,
    AALButtonToggleInputModule,
    AALOverlayCardHelpModule,
    AALWizardAssessmentModule,
    AALRichTextAreaModule,
    MatButtonModule,
    MatIconModule,
    MatDialogModule,
    FlexLayoutModule
  ],
  exports: [
    AALWizardAssessmentDialogComponent
  ]
})
export class AALWizardAssessmentDialogModule { }
