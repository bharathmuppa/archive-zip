import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import {MAT_DIALOG_DATA, MatDialogModule, MatDialogRef} from '@angular/material/dialog';
import {MatBadgeModule} from '@angular/material/badge';
import {UntypedFormArray, UntypedFormControl, UntypedFormGroup} from '@angular/forms';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {CommonModule} from '@angular/common';
import {AALCommonComponentsModule, Info} from '@asml-angular/common';

import {AALWizardAssessmentComponent} from '../wizard-assessment/wizard-assessment.component';
import {SharedMaterialModule} from '../shared/shared-material.module';
import {SharedFormModule} from '../shared/shared-form.module';
import {SharedModule} from '../shared/shared.module';
import {SharedFlexLayoutModule} from '../shared/shared-flex-layout.module';
import {AALButtonToggleInputModule} from '../button-toggle-input/button-toggle-input.module';
import {AALWizardAssessmentDialogComponent} from './wizard-assessment-dialog.component';
import {AssessmentResult} from '../wizard-assessment/wizard-assessment.model';

describe('AALWizardAssessmentComponent', () => {
  let component: AALWizardAssessmentDialogComponent;
  let fixture: ComponentFixture<AALWizardAssessmentDialogComponent>;
  const dialogMock = {
    close: () => { }
  };

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [AALWizardAssessmentDialogComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [
        { provide: MAT_DIALOG_DATA, useValue: {}},
        { provide: MatDialogRef, useValue: dialogMock }
      ],
      imports: [
        CommonModule,
        SharedMaterialModule,
        SharedFormModule,
        AALCommonComponentsModule,
        SharedModule,
        SharedFlexLayoutModule,
        MatBadgeModule,
        AALButtonToggleInputModule,
        MatDialogModule
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALWizardAssessmentDialogComponent);
    component = fixture.componentInstance;
    component.assessmentCriteria = [];
    component.applicabilityCheck = {
      explanation: new Info('Sample Data', ''),
      ID: 'applicabilityCheck0',
      question: 'Sample Question',
      sequence: 0,
      answerEnumeration: [],
      answerPlaceholder: 'Sample Place holder',
      answerDetailPlaceholder: 'Sample details placeholder',
      answerDetailMaxLength: 0,
      valuesWhereAnswerDetailIsApplicable: [],
      detailID: '',
      isEditable: true,
      disableAssessmentQuestionsFor: []
    };
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call answerDetailAcceptChanges', () => {
    const $event = { result: 'test result' };
    component.answerDetailAcceptChanges($event);
    expect(component.assessmentResult.result).toBe('test result');
  });

  it('should call answerAcceptChanges', () => {
    const $event = { result: 'test result' };
    component.answerAcceptChanges($event);
    expect(component.assessmentResult.result).toBe('test result');
  });

  it('should call assessmentSubmittable', () => {
    const $event = { result: 'test result', complete: true } as AssessmentResult;
    component.assessmentSubmittable($event);
    expect(component.assessmentResult.result).toBe('test result');
  });

  it('should call submit', () => {
    component.assessmentResult =  { result: 'test result', complete: true } as AssessmentResult;
    component.submit();
    // TODO check dialog is closed or not
    expect(true).toBe(true);
  });

  it('should call createBackup', () => {
     const control = new UntypedFormControl('No');
     const returnValueControl = component.createBackup(control);
     expect(returnValueControl.value).toBe('No');

     const formGroupWithControl = new UntypedFormGroup({
      value: new UntypedFormControl('Yes')
     });
     const returnValueGroup = component.createBackup(formGroupWithControl);
     expect(returnValueGroup.value.value).toBe('Yes');

     const formArray = new UntypedFormArray([formGroupWithControl]);
     const returnValueArray = component.createBackup(formArray);
     expect(returnValueArray.value[0].value).toBe('Yes');
  });

  it('should  call cancel', () => {
    component.assessmentWizardFormGroup = new UntypedFormGroup({value: new UntypedFormControl('Yes')});
    fixture.detectChanges();
    component.cancel();
    expect(component.assessmentWizardFormGroup.value.value).toBe('Yes');
  });
});
