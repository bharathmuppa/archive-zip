import { Component } from '@angular/core';
import {AALCommonButtonComponent} from '@asml-angular/common';

@Component({
  selector: 'aal-button-icon-contained',
  templateUrl: './button-icon-contained.component.html',
  styleUrls: ['./button-icon-contained.component.scss']
})
export class AALButtonIconContainedComponent extends AALCommonButtonComponent {

}
