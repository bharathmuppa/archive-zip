/*
 * Public API Surface of material
 */

export * from './button-icon-contained.component';
export * from './button-icon-contained.module';
