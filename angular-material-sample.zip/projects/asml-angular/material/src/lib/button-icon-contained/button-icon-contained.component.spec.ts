import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import {CommonModule} from '@angular/common';
import {SharedFlexLayoutModule} from '../shared/shared-flex-layout.module';
import {SharedModule} from '../shared/shared.module';
import {AALCommonComponentsModule} from '@asml-angular/common';
import {SharedFormModule} from '../shared/shared-form.module';
import {SharedMaterialModule} from '../shared/shared-material.module';
import {MatBadgeModule} from '@angular/material/badge';

import { AALButtonIconContainedComponent } from './button-icon-contained.component';

describe('ButtonIconContainedComponent', () => {
  let component: AALButtonIconContainedComponent;
  let fixture: ComponentFixture<AALButtonIconContainedComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ AALButtonIconContainedComponent ],
      imports: [
        CommonModule,
        SharedMaterialModule,
        SharedFormModule,
        AALCommonComponentsModule,
        SharedModule,
        SharedFlexLayoutModule,
        MatBadgeModule
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALButtonIconContainedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
