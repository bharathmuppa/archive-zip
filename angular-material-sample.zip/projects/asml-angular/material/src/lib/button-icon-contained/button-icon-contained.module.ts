import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AALButtonIconContainedComponent } from './button-icon-contained.component';
import {AALCommonComponentsModule} from '@asml-angular/common';
import {MatBadgeModule} from '@angular/material/badge';
import {MatButtonModule} from '@angular/material/button';
import {MatIconModule} from '@angular/material/icon';
import {MatTooltipModule} from '@angular/material/tooltip';

@NgModule({
  declarations: [AALButtonIconContainedComponent],
  imports: [
    CommonModule,
    AALCommonComponentsModule,
    MatBadgeModule,
    MatButtonModule,
    MatIconModule,
    MatTooltipModule,
  ],
  exports: [AALButtonIconContainedComponent]
})
export class AALButtonIconContainedModule { }
