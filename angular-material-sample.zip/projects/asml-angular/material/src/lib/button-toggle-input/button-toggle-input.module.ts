import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {A11yModule} from '@angular/cdk/a11y';
import {AALButtonToggleInputComponent} from './button-toggle-input.component';
import {AALToolbarConfirmModule} from '../toolbar-confirm/toolbar-confirm.module';
import {AALOverlayCardHelpModule} from '../overlay-card-help/overlay-card-help.module';
import {AALOverlayCardErrorModule} from '../overlay-card-alert/overlay-card-alert.module';
import {AALInputTextAreaModule} from '../input-text-area/input-text-area.module';
import {AALRichTextAreaModule} from '../rich-text-area/rich-text-area.module';
import {AALButtonTextModule} from '../button-text/button-text.module';
import {AALEditableDivTextAreaModule} from '../editable-div-text-area/editable-div-text-area.module';
import {AALCommonModule} from '@asml-angular/common';
import {MatTooltipModule} from '@angular/material/tooltip';
import {MatButtonToggleModule} from '@angular/material/button-toggle';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {FlexLayoutModule} from '@angular/flex-layout';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';


@NgModule({
  declarations: [AALButtonToggleInputComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    AALCommonModule,
    AALToolbarConfirmModule,
    AALOverlayCardHelpModule,
    AALOverlayCardErrorModule,
    AALInputTextAreaModule,
    AALRichTextAreaModule,
    AALButtonTextModule,
    AALEditableDivTextAreaModule,
    A11yModule,
    MatButtonToggleModule,
    MatProgressSpinnerModule,
    MatTooltipModule,
    FlexLayoutModule
  ],
  exports: [
    AALButtonToggleInputComponent
  ]
})
export class AALButtonToggleInputModule {
}
