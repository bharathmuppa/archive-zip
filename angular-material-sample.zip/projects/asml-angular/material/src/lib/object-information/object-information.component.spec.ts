import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ObjectInformationComponent } from './object-information.component';

describe('ObjectInformationComponent', () => {
  let component: ObjectInformationComponent;
  let fixture: ComponentFixture<ObjectInformationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ObjectInformationComponent ]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ObjectInformationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should emit objClickEvent when we call objectInformationClickEvent() with an argument.', () => {
    
    spyOn(component.objClickEvent, 'emit');
    component.objectInformationClickEvent('1234567890', {});
    expect(component.objClickEvent.emit).toHaveBeenCalled();

  })


});
