import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AALCommonComponentsModule, AALCommonModule } from '@asml-angular/common';
import { FlexLayoutModule } from '@angular/flex-layout';
import { MatButtonModule } from '@angular/material/button';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatChipsModule } from '@angular/material/chips';
import { ObjectInformationComponent } from './object-information.component';


@NgModule({
  declarations: [
    ObjectInformationComponent
  ],
  imports: [
    CommonModule,
    AALCommonComponentsModule,
    AALCommonModule,
    FlexLayoutModule,
    MatButtonModule,
    MatChipsModule,
    MatTooltipModule
  ],
  exports: [
    ObjectInformationComponent
  ]
})
export class AALObjectInformationModule { }
