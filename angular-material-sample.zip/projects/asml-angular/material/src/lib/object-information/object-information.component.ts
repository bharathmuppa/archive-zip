import { Component, Input, Output, EventEmitter, TemplateRef } from '@angular/core';


@Component({
  selector: 'aal-object-information',
  templateUrl: './object-information.component.html',
  styleUrls: ['./object-information.component.scss']
})
export class ObjectInformationComponent {

  @Input() blnObjectClassificationCard: boolean; 
  @Input() tmpIconTemplate: TemplateRef<any>; 
  @Input() strIconTooltip: string; 

  @Input() strIdValue: string; 
  @Input() strIdTooltip: string; 
  @Input() tmpIdTemplate: TemplateRef<any>; 

  @Input() tmpShieldIconTemplate: TemplateRef<any>; 
  @Input() strShieldIconTooltip: string; 

  @Input() strStatusChipValue: string; 
  @Input() objStatusChipStyles: any; 
  @Input() strStatusChipTooltip: string; 

  @Input() strPriorityChipValue: string; 
  @Input() objPriorityChipStyles: any; 
  @Input() strPriorityChipTooltip: string; 

  @Input() strTitle: TemplateRef<any>; 
  @Input() strTitleTooltip: string; 

  @Input() tmpObjectChipsTemplate: TemplateRef<any>; 
  @Output() objClickEvent: EventEmitter<any> = new EventEmitter(); 
  @Input() strObjectHeight: string; 

  objectInformationClickEvent(fromField: string, event?){
    this.objClickEvent.emit({"fromField": fromField, "event": event});
  }

}
