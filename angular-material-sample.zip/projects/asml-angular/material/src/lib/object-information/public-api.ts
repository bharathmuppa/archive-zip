/*
 * Public API Surface of material
 */

export * from './object-information.module';
export * from './object-information.component';
