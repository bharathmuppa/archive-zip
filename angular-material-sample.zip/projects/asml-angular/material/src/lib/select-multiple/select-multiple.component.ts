import {AfterViewChecked, Component, Input, OnInit} from '@angular/core';
import {AALFixedInputFormControlComponent, HistoryService} from '@asml-angular/common';

@Component({
  selector: 'aal-select-multiple',
  templateUrl: './select-multiple.component.html',
  styleUrls: ['./select-multiple.component.scss']
})
export class AALSelectMultipleComponent extends AALFixedInputFormControlComponent implements OnInit, AfterViewChecked {
  @Input()
  showSections?: boolean;
  @Input()
  sectionTag?: string;
  @Input()
  valueForNoOptionSelected?: string;

  constructor(historyService: HistoryService) {
    super(historyService);
  }

  ngAfterViewChecked() {
    if (this.selectField) {
      this.selectField.optionValueField = this.optionValueField;
      this.selectField.primaryKeyInValue = this.primaryKeyInValue;
    }
  }

  onChange($event?: Event) {
    if (!$event) {
      super.onChange($event);
    }
  }

  onClick() {
    super.onClick();
    setTimeout(() => {
      if (this.selectField && this.selectField.trigger) {
        this.selectField.trigger.nativeElement.click();
      }
    }, 200);
  }

  onKeyUp(event) {
    if (event.key === 'Enter' && this.selectField && this.selectField.panel) {
      super.triggerAcceptChanges();
    }
  }
}
