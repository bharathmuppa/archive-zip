import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import {CommonModule} from '@angular/common';
import {By} from '@angular/platform-browser';
import {UntypedFormControl, FormGroupDirective, NgControl, NgForm, Validators} from '@angular/forms';
import {ChangeDetectorRef, ElementRef, NgZone} from '@angular/core';
import {MatSelect} from '@angular/material/select';
import {ViewportRuler} from '@angular/cdk/overlay';
import {ErrorStateMatcher} from '@angular/material/core';
import {Directionality} from '@angular/cdk/bidi';
import {MatFormField} from '@angular/material/form-field';
import {LiveAnnouncer} from '@angular/cdk/a11y';

import {SharedMaterialModule} from '../shared/shared-material.module';
import {SharedFormModule} from '../shared/shared-form.module';
import {SharedFlexLayoutModule} from '../shared/shared-flex-layout.module';
import {SharedModule} from '../shared/shared.module';
import {AALSelectMultipleComponent} from './select-multiple.component';
import {AALFixedInputFormControlComponent} from '@asml-angular/common';

describe('SelectMultipleComponent', () => {
  let component: AALSelectMultipleComponent;
  let fixture: ComponentFixture<AALSelectMultipleComponent>;
  let button: ElementRef;
  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [AALSelectMultipleComponent],
      imports: [CommonModule,
        SharedMaterialModule,
        SharedFormModule,
        SharedModule,
        SharedFlexLayoutModule],
    }).compileComponents().then(() => {
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALSelectMultipleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    jasmine.clock().uninstall();
    component.control = new UntypedFormControl('actualVal', Validators.compose([]));
    button = fixture.debugElement.query(By.css('.aal-input-read-section'));
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should open options list, when onClick is triggered', () => {
    spyOn(AALFixedInputFormControlComponent.prototype, 'onClick').and.callFake(() => {});
    component.selectField = {
      trigger: {
        nativeElement: {
          click: () => {}
        }
      }
    };
    const spy = spyOn(component.selectField.trigger.nativeElement, 'click');
    jasmine.clock().install();
    component.onClick();
    fixture.detectChanges();
    jasmine.clock().tick(200);
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
    jasmine.clock().uninstall();
  });

  it('should call onChange of super Component', () => {
    spyOn(AALFixedInputFormControlComponent.prototype, 'onChange');
    component.onChange();
    expect(AALFixedInputFormControlComponent.prototype.onChange).toHaveBeenCalled();
  });

  it('should assign option specific properties to select field', () => {
    // @ts-ignore
    component.selectField = new MatSelect({} as ViewportRuler, {} as ChangeDetectorRef, {} as NgZone, {} as ErrorStateMatcher, {} as ElementRef, {} as Directionality, {} as NgForm, {} as FormGroupDirective, {} as MatFormField, {} as NgControl, '1', () => {}, {} as LiveAnnouncer);
    component.primaryKeyInValue = 'name';
    component.optionValueField = 'name';
    component.ngAfterViewChecked();
    expect(component.selectField.primaryKeyInValue).toBe('name');
  });

  it('should call triggerAcceptChanges, when onKeyUp is triggered after ENTER key is pressed', () => {
    const spy = spyOn(AALFixedInputFormControlComponent.prototype, 'triggerAcceptChanges');
    component.selectField = {
      panel: {}
    };
    component.onKeyUp({key: 'Enter'});
    expect(spy).toHaveBeenCalled();
  });
});
