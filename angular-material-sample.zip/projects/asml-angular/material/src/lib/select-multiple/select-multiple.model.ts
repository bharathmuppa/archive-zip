export class SectionedOptions {
  sectionName: string;
  items: OptionItem[];
}

export class OptionItem {
  name: string;
  description: string;
  section: string;
}
