import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {AALSelectMultipleComponent} from './select-multiple.component';
import {FlexLayoutModule} from '@angular/flex-layout';
import {AALOverlayCardHelpModule} from '../overlay-card-help/overlay-card-help.module';
import {AALOverlayCardErrorModule} from '../overlay-card-alert/overlay-card-alert.module';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import {MatInputModule} from '@angular/material/input';
import {MatSelectModule} from '@angular/material/select';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {MatTooltipModule} from '@angular/material/tooltip';
import {AALCommonModule} from '@asml-angular/common';

@NgModule({
  declarations: [AALSelectMultipleComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    AALCommonModule,
    AALOverlayCardHelpModule,
    AALOverlayCardErrorModule,
    MatInputModule,
    MatProgressSpinnerModule,
    MatSelectModule,
    MatTooltipModule,
    FlexLayoutModule
  ],
  exports: [
    AALSelectMultipleComponent
  ]
})
export class AALSelectMultipleModule {
}
