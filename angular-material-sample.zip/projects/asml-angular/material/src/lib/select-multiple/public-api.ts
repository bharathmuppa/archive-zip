/*
 * Public API Surface of material
 */

export * from './select-multiple.component';
export * from './select-multiple.model';
export * from './select-multiple.module';
