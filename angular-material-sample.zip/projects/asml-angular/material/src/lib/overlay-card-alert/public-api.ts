/*
 * Public API Surface of material
 */

export * from './overlay-card-alert.component';
export * from './overlay-card-alert.module';
