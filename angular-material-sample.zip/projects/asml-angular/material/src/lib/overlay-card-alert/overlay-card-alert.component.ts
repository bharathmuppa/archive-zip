import {Component, Input, OnInit, SecurityContext, ViewChild, ViewEncapsulation} from '@angular/core';
import {DomSanitizer, SafeValue} from '@angular/platform-browser';
import {Info, InfoLevels} from '@asml-angular/common';

@Component({
  selector: 'aal-overlay-card-alert',
  templateUrl: './overlay-card-alert.component.html',
  styleUrls: ['./overlay-card-alert.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class AALOverlayCardAlertComponent implements OnInit {
  title: string;
  message: string;
  animation: string;
  thumbnail: string;
  level: string;
  showAnimation: boolean;
  alertData: Info;
  @Input()
  titleColor: string;
  @Input()
  set alert(alertData: Info) {
    this.alertData = alertData;
    this.setErrorValues();
  }
  get alert() {
    return this.alertData;
  }
  @Input()
  sanitize: boolean;

  @ViewChild('trigger', {static: false}) menuTrigger;
  highlightIcon: boolean;

  @Input()
  hideTooltip: boolean;

  constructor(private readonly sanitizer: DomSanitizer) {
      this.hideTooltip = false;
  }

  openMenu() {
    this.highlightIcon = true;
    this.menuTrigger.openMenu();
  }

  closeMenu() {
    this.highlightIcon = false;
    this.menuTrigger.closeMenu();
  }

  ngOnInit() {
  }

  setErrorValues() {
    const localTitle = this.alert ? this.alert.title : '';
    const localMessage = this.alert ? this.alert.message : '';
    const localAnimation = this.alert ? this.alert.animation : '';
    const localThumbnail = this.alert ? this.alert.thumbnail : '';
    const localLevel = (this.alert && this.alert.level) ? this.alert.level : InfoLevels.WARN;
    this.sanitize = this.sanitize || false;

    if (this.sanitize) {
      this.title = this.sanitizeHTML(localTitle);
      this.message = this.sanitizeHTML(localMessage);
      this.animation = this.sanitizeURL(localAnimation);
      this.thumbnail = this.sanitizeURL(localThumbnail);
    } else {
      this.title = localTitle;
      this.message = localMessage;
      this.animation = localAnimation;
      this.thumbnail = localThumbnail;
    }
    this.showAnimation = false;
    this.level = localLevel;
  }
  sanitizeHTML(content: SafeValue) {
    return this.sanitizer.sanitize(SecurityContext.HTML, content);
  }

  sanitizeURL(content: SafeValue) {
    return this.sanitizer.sanitize(SecurityContext.URL, content);
  }

  onKeyUp(event: KeyboardEvent) {
    if (event.key === 'Escape') {
      this.closeMenu();
    }
    event.stopPropagation();
  }

  onClick() {
    this.openMenu();
  }

  getTooltip(): string {
    return this.level === InfoLevels.ERROR ? 'Error' : 'Warning';
  }

  getColor(): string {
    if (this.highlightIcon) {
      return 'cdk-program-focused';
    } else if (this.level === InfoLevels.ERROR) {
      return 'error';
    } else {
      return 'warn';
    }
  }

  onToggleAnimation($event: Event) {
    this.showAnimation = !this.showAnimation;
    $event.stopPropagation();
  }
}
