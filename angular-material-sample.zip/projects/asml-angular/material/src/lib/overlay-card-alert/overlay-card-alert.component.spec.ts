import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import {InfoLevels} from '@asml-angular/common';
import {CommonModule} from '@angular/common';

import {AALOverlayCardAlertComponent} from './overlay-card-alert.component';
import {SharedMaterialModule} from '../shared/shared-material.module';
import {SharedFlexLayoutModule} from '../shared/shared-flex-layout.module';

describe('AALOverlayCardAlertComponent', () => {
  let component: AALOverlayCardAlertComponent;
  let fixture: ComponentFixture<AALOverlayCardAlertComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [AALOverlayCardAlertComponent],
      imports: [
        CommonModule,
        SharedMaterialModule,
        SharedFlexLayoutModule
      ]
    }).compileComponents().then(() => {
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALOverlayCardAlertComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize the component (ngOnInit)', () => {
    component.sanitize = true;
    component.ngOnInit();
    expect(component).toBeTruthy();
  });

  it('should sanitize Html content (sanitizeURL)', () => {
    const sanitizedHtml = component.sanitizeHTML('<script></script><h1>header</h1>');
    expect(sanitizedHtml).toEqual('<h1>header</h1>');
  });

  it('should sanitize URL (sanitizeURL)', () => {
    const sanitizedUrl = component.sanitizeURL('<a href=\'http://sample.com\'>Sample</a>');
    expect(sanitizedUrl).toEqual('unsafe:<a href=\'http://sample.com\'>Sample</a>');
  });

  it('should menu be closed (onKeyUp)', () => {
    component.menuTrigger = {
      closeMenu(): void {
      },
      openMenu(): void {
      }
    };
    const keyBoardEvent = {
      key: 'Escape',
      stopPropagation(): void {
      }
    } as KeyboardEvent;
    const menuCloseSpy = spyOn(component.menuTrigger, 'closeMenu').and.returnValue(null);
    component.onKeyUp(keyBoardEvent);
    expect(component.highlightIcon).toBeFalsy();
    expect(menuCloseSpy).toHaveBeenCalled();
  });
  it('should menu be opened (onClick)', () => {
    component.menuTrigger = {
      closeMenu(): void {
      },
      openMenu(): void {
      }
    };
    const menuCloseSpy = spyOn(component.menuTrigger, 'openMenu').and.returnValue(null);
    component.onClick();
    expect(component.highlightIcon).toBeTruthy();
    expect(menuCloseSpy).toHaveBeenCalled();
  });
  it('should animation flag be toggled (onToggleAnimation)', () => {
    const event = {
      stopPropagation(): void {
      }
    } as Event;
    component.showAnimation = false;
    component.onToggleAnimation(event);
    expect(component.showAnimation).toBeTruthy();
  });

  it('should return tooltip (getTooltip)', () => {
    component.level = 'ERROR';
    const toolTip = component.getTooltip();
    expect(toolTip).toEqual('Error');
  });

  it('should return cdk-program-focused color (getColor)', () => {
    component.highlightIcon = true;
    const color = component.getColor();
    expect(color).toEqual('cdk-program-focused');
  });

  it('should return warn color (getColor)', () => {
    component.level = 'WARN';
    const color = component.getColor();
    expect(color).toEqual('warn');
  });

  it('should return error color as default (getColor)', () => {
    component.level = 'ERROR';
    const color = component.getColor();
    expect(color).toEqual('error');
  });

  it('should setErrorValues', () => {
    component.alert = {
      title: 'sample title',
      message: 'sample message',
      animation: 'sample animation',
      thumbnail: 'icon-thumb',
      level: InfoLevels.WARN
    };
    component.sanitize = true;
    component.setErrorValues();
    expect(component.title).toBe('sample title');
  });
});
