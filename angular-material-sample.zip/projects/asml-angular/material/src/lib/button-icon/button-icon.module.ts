import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {AALButtonIconComponent} from './button-icon.component';
import {AALCommonComponentsModule} from '@asml-angular/common';
import {MatBadgeModule} from '@angular/material/badge';
import {MatTooltipModule} from '@angular/material/tooltip';
import {MatButtonModule} from '@angular/material/button';
import {MatIconModule} from '@angular/material/icon';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';

@NgModule({
  declarations: [AALButtonIconComponent],
  imports: [
    CommonModule,
    AALCommonComponentsModule,
    MatTooltipModule,
    MatButtonModule,
    MatIconModule,
    MatBadgeModule,
    FormsModule,
    ReactiveFormsModule
  ],
  exports: [AALButtonIconComponent]
})
export class AALButtonIconModule {
}
