import {Component} from '@angular/core';
import {AALCommonButtonComponent} from '@asml-angular/common';

@Component({
  selector: 'aal-button-icon',
  templateUrl: './button-icon.component.html',
  styleUrls: ['./button-icon.component.scss']
})
export class AALButtonIconComponent extends AALCommonButtonComponent {

}
