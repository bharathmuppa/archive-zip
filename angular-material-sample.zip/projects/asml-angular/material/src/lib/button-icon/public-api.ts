/*
 * Public API Surface of material
 */

export * from './button-icon.component';
export * from './button-icon.module';
