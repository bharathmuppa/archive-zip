import {Component, EventEmitter, Input, OnInit, Output, TemplateRef} from '@angular/core';
import {Info} from '@asml-angular/common';
import {ButtonType} from '@asml-angular/common/lib/models/enumeration.model';

export interface ActionEventData {
  ID: string;
  action: string;
}

@Component({
  selector: 'aal-list-item',
  templateUrl: './list-item.component.html',
  styleUrls: ['./list-item.component.scss']
})
export class AALListItemComponent implements OnInit {
  @Input()
  ID: string;
  @Input()
  item: any;
  @Input()
  icon: string;
  @Input()
  imageURL: string;
  @Input()
  svgIcon: string;
  @Input()
  title: string;
  @Input()
  mainDescription: string;
  @Input()
  mainDescriptionCaption: string;
  @Input()
  subDescription: string;
  @Input()
  subDescriptionCaption: string;
  @Input()
  label: string;
  @Input()
  labelLink: string;
  @Input()
  labelCaption: string;
  @Input()
  separator: string;
  @Input()
  showActionButton: boolean;
  @Input()
  actionButtonText: string;
  @Input()
  action: string;
  @Input()
  actionButtonIcon: string;
  @Input()
  actionButtonTooltip: string;
  @Input()
  actionButtonType: ButtonType;
  @Input()
  isClickable: boolean;
  @Input()
  help: Info;
  @Input()
  showHelp: Info;
  @Input()
  error: Info;
  @Input()
  showError: Info;
  @Input()
  isBusy: boolean;
  @Input()
  showActionButtonOnFocus: ButtonType;
  @Output()
  actionSubmit: EventEmitter<ActionEventData> = new EventEmitter<ActionEventData>();
  @Output()
  itemClick: EventEmitter<string> = new EventEmitter<string>();

  @Input()
  titleTemplateRef: TemplateRef<any>;
  @Input()
  mainDescriptionTemplateRef: TemplateRef<any>;
  @Input()
  subDescriptionTemplateRef: TemplateRef<any>;
  @Input()
  imageDisplayRef: TemplateRef<any>;
  hasFoucs: boolean;

  constructor() {
  }

  ngOnInit() {
  }

  triggerAction($event): void {
    this.actionSubmit.emit({
      ID: this.ID,
      action: this.action
    } as ActionEventData);
    $event.stopPropagation();
  }

  onClick(): void {
    if (this.isClickable) {
      this.itemClick.emit(this.ID);
    }
  }

  getTooltipContent(element: any, data: string): string {
    if (element) {
      return element.offsetWidth < element.scrollWidth ? data : '';
    }
    return '';
  }

  getFlex() {
    return this.showHelp && this.showError ? 90 : (this.showHelp ? 95 : this.showError ? 95 : 100);
  }

}
