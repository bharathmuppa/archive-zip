import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {AALListItemComponent} from './list-item.component';
import {AALButtonIconModule} from '../button-icon/button-icon.module';
import {AALOverlayCardHelpModule} from '../overlay-card-help/overlay-card-help.module';
import {AALOverlayCardErrorModule} from '../overlay-card-alert/overlay-card-alert.module';
import {AALCardSummaryModule} from '../card-summary/card-summary.module';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import {FlexLayoutModule} from '@angular/flex-layout';

@NgModule({
  declarations: [AALListItemComponent],
  imports: [
    CommonModule,
    AALButtonIconModule,
    AALOverlayCardHelpModule,
    AALOverlayCardErrorModule,
    AALCardSummaryModule,
    MatProgressSpinnerModule,
    FlexLayoutModule
  ],
  exports: [AALListItemComponent]
})
export class AALListItemModule {
}
