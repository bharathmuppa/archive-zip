import {ComponentFixture, TestBed, waitForAsync} from '@angular/core/testing';

import {AALListItemComponent} from './list-item.component';
import {NO_ERRORS_SCHEMA} from '@angular/core';
import {Info} from '@asml-angular/common';

describe('AALListItemComponent', () => {
  let component: AALListItemComponent;
  let fixture: ComponentFixture<AALListItemComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [AALListItemComponent],
      schemas: [NO_ERRORS_SCHEMA],
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALListItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should prevent current event propagation when triggerAction is clicked', () => {
    const event = new MouseEvent('click');
    spyOn(event, 'stopPropagation');
    component.triggerAction(event);
    expect(event.stopPropagation).toHaveBeenCalled();
  });
  it('should emit itemClick when onClick is clicked and isClickable is true', () => {
    spyOn(component.itemClick, 'emit');
    component.isClickable = true;
    component.ID = 'test';
    component.onClick();
    expect(component.itemClick.emit).toHaveBeenCalledWith('test');
  });
  it('should return data when offsetWidth is less than scrollWidth', () => {
    const returnValue = component.getTooltipContent({offsetWidth: 2, scrollWidth: 3}, 'data');
    expect(returnValue).toEqual('data');
  });
  it('should return empty when offsetWidth is greater than scrollWidth', () => {
    const returnValue = component.getTooltipContent({offsetWidth: 3, scrollWidth: 2}, 'data');
    expect(returnValue).toEqual('');
  });
  it('should return empty when offsetWidth and scrollWidth are null', () => {
    const returnValue = component.getTooltipContent(null, 'data');
    expect(returnValue).toEqual('');
  });
  it('should return 90 when showHelp and showError are defined', () => {
    component.showHelp = {} as Info;
    component.showError = {} as Info;
    const returnValue = component.getFlex();
    expect(returnValue).toEqual(90);
  });
  it('should return 95 when showError is undefined', () => {
    component.showHelp = {} as Info;
    const returnValue = component.getFlex();
    expect(returnValue).toEqual(95);
  });
  it('should return 95 when showHelp is undefined ', () => {
    component.showError = {} as Info;
    const returnValue = component.getFlex();
    expect(returnValue).toEqual(95);
  });
  it('should return 90 when showHelp and showError are undefined', () => {
    component.showHelp = null;
    component.showError = null;
    const returnValue = component.getFlex();
    expect(returnValue).toEqual(100);
  });
});
