import {Component, EventEmitter, Inject, OnInit, Output} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material/dialog';


@Component({
  selector: 'aal-light-box',
  templateUrl: './light-box.component.html',
  styleUrls: ['./light-box.component.scss']
})
export class AALLightBoxComponent implements OnInit {
  @Output() readonly viewNextOrPreviousItem: EventEmitter<any> = new EventEmitter<any>();
  @Output() readonly downloadAttachment: EventEmitter<any> = new EventEmitter<any>();
  constructor(public dialogRef: MatDialogRef<AALLightBoxComponent>, @Inject(MAT_DIALOG_DATA) public data: any) {
  }

  ngOnInit() {
  }
  editNextOrPrevious(direction): void {
    this.viewNextOrPreviousItem.emit(direction);
  }

  download() {
    this.downloadAttachment.emit();
  }
}
