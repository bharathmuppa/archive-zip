/*
 * Public API Surface of material
 */
export {AALLightBoxComponent} from './light-box.component';
export * from './light-box.module';
