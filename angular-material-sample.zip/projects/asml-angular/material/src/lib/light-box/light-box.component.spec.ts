import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import {CommonModule} from '@angular/common';
import {AALCommonComponentsModule} from '@asml-angular/common';
import {MatBadgeModule} from '@angular/material/badge';
import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material/dialog';

import { AALLightBoxComponent } from './light-box.component';
import {SharedMaterialModule} from '../shared/shared-material.module';
import {SharedFormModule} from '../shared/shared-form.module';
import {SharedModule} from '../shared/shared.module';
import {SharedFlexLayoutModule} from '../shared/shared-flex-layout.module';

describe('AALLightBoxComponent', () => {
  let component: AALLightBoxComponent;
  let fixture: ComponentFixture<AALLightBoxComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ AALLightBoxComponent ],
      imports: [
        CommonModule,
        SharedMaterialModule,
        SharedFormModule,
        AALCommonComponentsModule,
        SharedModule,
        SharedFlexLayoutModule,
        MatBadgeModule
      ],
      providers: [
        { provide: MAT_DIALOG_DATA, useValue: {} },
        { provide: MatDialogRef, useValue: {} }
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALLightBoxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should emit downloadAttachment, when downLoad is triggered', () => {
    const spy = spyOn(component.downloadAttachment, 'emit');
    component.download();
    expect(spy).toHaveBeenCalled();
  });

  it('should call editNextOrPrevious', () => {
    spyOn(component.viewNextOrPreviousItem, 'emit');
    component.editNextOrPrevious('right');
    expect(component.viewNextOrPreviousItem.emit).toHaveBeenCalled();
  });
});
