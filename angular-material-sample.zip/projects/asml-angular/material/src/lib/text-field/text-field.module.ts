import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {AALTextFieldComponent} from './text-field.component';
import {AALCommonComponentsModule, AALCommonModule} from '@asml-angular/common';
import {AALOverlayCardHelpModule} from '../overlay-card-help/overlay-card-help.module';
import {AALOverlayCardErrorModule} from '../overlay-card-alert/overlay-card-alert.module';
import {AALToolbarConfirmModule} from '../toolbar-confirm/toolbar-confirm.module';
import {FlexLayoutModule} from '@angular/flex-layout';
import {MatTooltipModule} from '@angular/material/tooltip';

@NgModule({
  declarations: [AALTextFieldComponent],
  imports: [
    CommonModule,
    AALCommonModule,
    AALCommonComponentsModule,
    AALOverlayCardHelpModule,
    AALOverlayCardErrorModule,
    AALToolbarConfirmModule,
    MatTooltipModule,
    FlexLayoutModule
  ],
  exports: [
    AALTextFieldComponent
  ]
})
export class AALTextFieldModule {
}
