import {Component, ElementRef, Input, OnInit, ViewChild} from '@angular/core';
import {Info} from '@asml-angular/common';

@Component({
  selector: 'aal-text-field',
  templateUrl: './text-field.component.html',
  styleUrls: ['./text-field.component.css']
})
export class AALTextFieldComponent implements OnInit {
  @Input()
  label: string;
  @Input()
  value: string;
  @Input()
  fontSize: string;
  @Input()
  help: Info;
  @Input()
  tooltip: string;
  @Input()
  align: string;
  @Input()
  isSingleLine: boolean;
  @Input()
  showFullText: boolean;
  @Input()
  textFieldMaxHeight: number;
  @ViewChild('readModeDiv', {static: false}) readModeDivision: ElementRef;
  showMore: boolean;
  overflow: boolean;
  @ViewChild("refShowMore") refShowMore: ElementRef;
  @Input() defaultShowMore: boolean;
  @Input() enableShowMoreAfter: number;
  oneRem: number = 16;
 
  ngOnInit() {
    this.showMore = this.defaultShowMore ?? false;
    this.textFieldMaxHeight = this.textFieldMaxHeight || 40;
    this.enableShowMoreAfter = this.enableShowMoreAfter ?? 4;
  }

  ngAfterViewInit() {
    if (this.defaultShowMore && (Math.ceil(this.readModeDivision?.nativeElement?.scrollHeight) > this.enableShowMoreAfter * this.oneRem)) {
      this.refShowMore?.nativeElement?.click();
    }
  }
}
