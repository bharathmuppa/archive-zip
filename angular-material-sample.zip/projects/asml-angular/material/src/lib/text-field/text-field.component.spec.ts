import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { AALTextFieldComponent } from './text-field.component';
import {CommonModule} from '@angular/common';
import {SharedMaterialModule} from '../shared/shared-material.module';
import {SharedFormModule} from '../shared/shared-form.module';
import {AALCommonComponentsModule} from '@asml-angular/common';
import {SharedModule} from '../shared/shared.module';
import {SharedFlexLayoutModule} from '../shared/shared-flex-layout.module';
import {MatBadgeModule} from '@angular/material/badge';

describe('TextFieldComponent', () => {
  let component: AALTextFieldComponent;
  let fixture: ComponentFixture<AALTextFieldComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ AALTextFieldComponent ],
      imports: [
        CommonModule,
        SharedMaterialModule,
        SharedFormModule,
        AALCommonComponentsModule,
        SharedModule,
        SharedFlexLayoutModule,
        MatBadgeModule
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALTextFieldComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set default value for show more', () => {
    component.ngOnInit();
    expect(component.showMore).toBe(false);
  });

  it("should show the full text content by default, when we pass defaultShowMore value as true from the application", () => {
    component.defaultShowMore = true;
    component.ngOnInit();
    expect(component.showMore).toBe(true);
    component.ngAfterViewInit();
    expect(component.enableShowMoreAfter).toBe(4);
  });

  it("shouldn't show the full text content by default, when we pass defaultShowMore value as false from the application", () => {
    component.defaultShowMore = false;
    component.ngOnInit();
    expect(component.showMore).toBe(false);
    component.ngAfterViewInit();
    expect(component.enableShowMoreAfter).toBe(4);
  });

});
