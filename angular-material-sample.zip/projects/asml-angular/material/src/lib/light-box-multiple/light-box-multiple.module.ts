import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {AALLightBoxMultipleComponent} from './light-box-multiple.component';
import {AALCommonComponentsModule} from '@asml-angular/common';
import {AALOverlayCardHelpModule} from '../overlay-card-help/overlay-card-help.module';
import {AALOverlayCardErrorModule} from '../overlay-card-alert/overlay-card-alert.module';
import {AALToolbarConfirmModule} from '../toolbar-confirm/toolbar-confirm.module';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import {MatIconModule} from '@angular/material/icon';
import {MatTooltipModule} from '@angular/material/tooltip';
import {FlexLayoutModule} from '@angular/flex-layout';
import {MatDialogModule} from "@angular/material/dialog";
import {MatButtonModule} from "@angular/material/button";

@NgModule({
    declarations: [AALLightBoxMultipleComponent],
  imports: [
    CommonModule,
    AALCommonComponentsModule,
    AALOverlayCardHelpModule,
    AALOverlayCardErrorModule,
    AALToolbarConfirmModule,
    MatIconModule,
    MatSlideToggleModule,
    MatTooltipModule,
    FlexLayoutModule,
    MatDialogModule,
    MatButtonModule
  ],
    exports: [
        AALLightBoxMultipleComponent
    ]
})
export class AALLightBoxMultipleModule {
}
