import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import {CommonModule} from '@angular/common';
import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material/dialog';
import {MatBadgeModule} from '@angular/material/badge';
import {AALCommonComponentsModule} from '@asml-angular/common';
import {MatDialogModule} from '@angular/material/dialog';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';

import {SharedMaterialModule} from '../shared/shared-material.module';
import {SharedFormModule} from '../shared/shared-form.module';
import {SharedModule} from '../shared/shared.module';
import {SharedFlexLayoutModule} from '../shared/shared-flex-layout.module';
import { AALLightBoxMultipleComponent } from './light-box-multiple.component';

describe('LightBoxMultipleComponent', () => {
  let component: AALLightBoxMultipleComponent;
  let fixture: ComponentFixture<AALLightBoxMultipleComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ AALLightBoxMultipleComponent ],
      imports: [CommonModule,
        SharedMaterialModule,
        SharedFormModule,
        SharedModule,
        SharedFlexLayoutModule,
        AALCommonComponentsModule,
        MatBadgeModule,
        MatDialogModule],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [
        { provide: MAT_DIALOG_DATA,
          useValue: {
                  index: 0,
                  images: [{
                    url: 'assets/light-box-multiple/AsIs.jpg',
                    name: 'AsIs.jpg',
                    uploadedBy: 'Mansur Abdirimov',
                    uploadedOn: new Date('2019-11-16T12:00:00.000Z'),
                    title: 'As-is'
                  }, {
                    url: 'assets/light-box-multiple/AsIs.jpg',
                    name: 'AsIs.jpg',
                    uploadedBy: 'Harshit',
                    uploadedOn: new Date('2019-11-16T12:00:00.000Z'),
                    title: 'As-is'
                  }],
                  navigationTooltips: {left: '', right: ''}
              }},
        { provide: MatDialogRef, useValue: {} }
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALLightBoxMultipleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call followDirection', () => {
    component.followDirection('next');
    expect(component.disableDirection).toBe('right');

    component.followDirection('previous');
    expect(component.disableDirection).toBe('left');
    component.data = {
      index: 0,
      images: [{
        url: 'assets/light-box-multiple/AsIs.jpg',
        name: 'AsIs.jpg',
        uploadedBy: 'Mansur Abdirimov',
        uploadedOn: new Date('2019-11-16T12:00:00.000Z'),
        title: 'As-is'
      }],
      navigationTooltips: {left: '', right: ''}
    }
    component.followDirection('previous');
    expect(component.disableDirection).toBe('both');

    component.data = {
      index: 4,
      images: [],
      navigationTooltips: {left: '', right: ''}
    }
    component.followDirection('next');
    expect(component.disableDirection).toBe('none');
  });

  it('should call toggleSideBySide', () => {
    component.toggleSideBySide(true);
    expect(component.sideBySideChecked).toBe(true);
  });

  it('should call getSideBySideTitle', () => {
    const returnValue = component.getSideBySideTitle();
    expect(returnValue).toBe('As-is & As-is');
  });
});
