export class LightBoxMultipleData {
  index: number;
  images: LightBoxMultipleImage [];
  navigationTooltips?: NavigationTooltips;
}

export class LightBoxMultipleImage {
  url: string;
  name: string;
  uploadedBy?: string;
  uploadedOn?: Date;
  title: string;
}
export class NavigationTooltips {
  left: string;
  right: string;
}
