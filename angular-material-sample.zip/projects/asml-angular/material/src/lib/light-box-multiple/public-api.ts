/*
 * Public API for Light Box Multiple
 */
export * from './light-box-multiple.module';
export * from './light-box-multiple.component';
export * from './light-box-multiple.model';
