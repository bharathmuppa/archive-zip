import {Component, Inject} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material/dialog';
import {LightBoxMultipleData} from './light-box-multiple.model';

@Component({
  selector: 'aal-light-box-multiple',
  templateUrl: './light-box-multiple.component.html',
  styleUrls: ['./light-box-multiple.component.scss']
})
export class AALLightBoxMultipleComponent {
  disableDirection = 'both';
  sideBySideChecked = false;

  constructor(public dialogRef: MatDialogRef<AALLightBoxMultipleComponent>, @Inject(MAT_DIALOG_DATA) public data: LightBoxMultipleData) {
    this.checkAvailableDirections();
  }

  checkAvailableDirections() {
    if (this.data.images && this.data.images.length === 1) {
      this.disableDirection = 'both';
    } else if (this.data.images && this.data.index === (this.data.images.length - 1)) {
      this.disableDirection = 'right';
    } else if (this.data.index === 0) {
      this.disableDirection = 'left';
    } else {
      this.disableDirection = 'none';
    }
  }

  followDirection(direction: string) {
    if (direction === 'next'
      && this.data.index < this.data.images.length) {
      this.data.index += 1;
    } else if (direction === 'previous' && this.data.index > 0) {
      this.data.index -= 1;
    }
    this.checkAvailableDirections();
  }

  toggleSideBySide(sideBySideChecked: boolean) {
    this.sideBySideChecked = sideBySideChecked;
  }

  getSideBySideTitle(): string {
    let concatenatedTitle = '';
    this.data.images.forEach((image, index) => {
      concatenatedTitle += image.title;
      if (index < this.data.images.length - 1) {
        concatenatedTitle += ' & ';
      }
    });
    return concatenatedTitle;
  }
}
