import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {AALButtonToolbarComponent} from './button-toolbar.component';
import {AALCommonComponentsModule} from '@asml-angular/common';
import {AALButtonModule} from '../button/button.module';
import {MatDividerModule} from '@angular/material/divider';
import {FlexLayoutModule} from '@angular/flex-layout';

@NgModule({
  declarations: [AALButtonToolbarComponent],
  imports: [
    CommonModule,
    AALCommonComponentsModule,
    FlexLayoutModule,
    AALButtonModule,
    MatDividerModule
  ],
  exports: [AALButtonToolbarComponent]
})
export class AALButtonToolbarModule {
}
