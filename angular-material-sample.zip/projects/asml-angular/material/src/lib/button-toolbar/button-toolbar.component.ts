import {Component, Input, OnInit} from '@angular/core';
import {ButtonConfiguration} from '../shared/shared.model';

@Component({
  selector: 'aal-button-toolbar',
  templateUrl: './button-toolbar.component.html',
  styleUrls: ['./button-toolbar.component.scss']
})
export class AALButtonToolbarComponent implements OnInit {
  @Input()
  toolbarConfiguration: ButtonConfiguration[];

  constructor() {
  }

  ngOnInit() {
  }

}
