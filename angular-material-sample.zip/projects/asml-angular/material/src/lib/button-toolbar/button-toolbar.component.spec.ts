import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { AALButtonToolbarComponent } from './button-toolbar.component';
import {CommonModule} from '@angular/common';
import {SharedMaterialModule} from '../shared/shared-material.module';
import {SharedFormModule} from '../shared/shared-form.module';
import {AALCommonComponentsModule} from '@asml-angular/common';
import {SharedModule} from '../shared/shared.module';
import {SharedFlexLayoutModule} from '../shared/shared-flex-layout.module';
import {MatBadgeModule} from '@angular/material/badge';
import {AALButtonModule} from '../button/button.module';

describe('AALButtonToolbarComponent', () => {
  let component: AALButtonToolbarComponent;
  let fixture: ComponentFixture<AALButtonToolbarComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ AALButtonToolbarComponent ],
      imports: [
        CommonModule,
        SharedMaterialModule,
        SharedFormModule,
        AALCommonComponentsModule,
        SharedModule,
        SharedFlexLayoutModule,
        MatBadgeModule,
        AALButtonModule
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALButtonToolbarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
