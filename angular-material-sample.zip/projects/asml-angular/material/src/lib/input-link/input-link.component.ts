import {Component} from '@angular/core';
import {AALInputFormControlComponent, HistoryService} from '@asml-angular/common';
import {CommonMaterialComponentErrorStateMatcher} from '../shared/common-material-component.error-state-matcher';

@Component({
  selector: 'aal-input-link',
  templateUrl: './input-link.component.html',
  styleUrls: ['./input-link.component.scss']
})
export class AALInputLinkComponent extends AALInputFormControlComponent {
  pattern: RegExp;
  errorStateMatcher = new CommonMaterialComponentErrorStateMatcher();
  showLinkHint: boolean;
  timeOutReference: any;

  constructor(historyService: HistoryService) {
    super(historyService);
    this.pattern = /^(http:\/\/www\.|https:\/\/www\.|http:\/\/|https:\/\/.|ftp:\/\/.|file:\/\/)?[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?$/;
    this.showLinkHint = true;
    this.ignoreValidations = true;
  }

  getValidatorMessage(validatorKey?: string): string {
    if (validatorKey.toUpperCase() === 'PATTERN') {
      return 'Link Might Not Work';
    } else {
      return super.getValidatorMessage(validatorKey);
    }
  }

  onBlur($event?: Event) {
    if ($event instanceof FocusEvent && $event.relatedTarget && $event.relatedTarget['id'].includes(this.hyphenatedID)) {
    //  do nothing
      return;
    }
    this.sanitizeControlValue();
    super.onBlur($event);
  }

  onKeyUp(event: KeyboardEvent) {
    this.showLinkHint = true;
    if (this.timeOutReference) {
      clearTimeout(this.timeOutReference);
    }
    this.timeOutReference = setTimeout(() => {
      this.showLinkHint = false;
    }, 5000);

    super.onKeyUp(event);
  }

  triggerAcceptChanges() {
    this.sanitizeControlValue();
    super.triggerAcceptChanges();
  }

  openLink($event) {
    if (this.control.value) {
      window.open(this.control.value, '_blank');
    }
    $event.stopPropagation();
  }

  private sanitizeControlValue() {
// Remove spaces, Split with delimiters and filter unwanted format
    const temp = (this.control && this.control.value) ? this.control.value : '';
    this.control.setValue(temp.replace(/^[ ]+|[ ]+$/g, ''));
  }

  isLinkValid(): boolean {
    return this.control && this.control.dirty && this.control.valid && this.showLinkHint && this.control.value.length > 0;
  }

  getTooltip(): string {
    return (this.control && this.control.value && this.control.value.length > 0) ? '' : 'Set Hyperlink First';
  }

  click($event): void {
    const target = $event.target;
    if (target.id !== 'linkButton') {
      super.onClick();
    }
  }

}
