/*
 * Public API Surface of material
 */

export * from './input-link.component';
export * from './input-link.module';
