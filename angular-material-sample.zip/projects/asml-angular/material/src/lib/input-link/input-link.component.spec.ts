import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import {CommonModule} from '@angular/common';
import {UntypedFormControl, Validators} from '@angular/forms';
import {AALInputFormControlComponent} from '@asml-angular/common';

import {SharedMaterialModule} from '../shared/shared-material.module';
import {SharedFormModule} from '../shared/shared-form.module';
import {SharedFlexLayoutModule} from '../shared/shared-flex-layout.module';
import {SharedModule} from '../shared/shared.module';
import {AALInputLinkComponent} from './input-link.component';

describe('AALInputLinkComponent', () => {
  let component: AALInputLinkComponent;
  let fixture: ComponentFixture<AALInputLinkComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [AALInputLinkComponent],
      imports: [CommonModule,
        SharedMaterialModule,
        SharedFormModule,
        SharedModule,
        SharedFlexLayoutModule],
    }).compileComponents().then(() => {
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALInputLinkComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    component.control = new UntypedFormControl('actualVal', Validators.compose([]));
    jasmine.clock().uninstall();
  });

  afterEach(() => {
    jasmine.clock().uninstall();
  });


  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should be able to get pattern validation messages', () => {
    const validatorMessage = component.getValidatorMessage('PATTERN');
    expect(validatorMessage).toBe('Link Might Not Work');
  });

  it('should be able to get validation messages from super class', () => {
    spyOn(AALInputFormControlComponent.prototype, 'getValidatorMessage').and.returnValue('Sample');
    const validatorMessage = component.getValidatorMessage('');
    expect(validatorMessage).toContain('Sample');
  });

  describe('should test window open event', () => {
    it('should deepLink url be opened in new window', () => {
      component.control.setValue('https://www.google.com');
      spyOn(window, 'open').and.callThrough();
      component.openLink({
        stopPropagation: () => {
        }
      });
      expect(window.open).toHaveBeenCalled();
      expect(window.open).toHaveBeenCalledWith(component.control.value, '_blank');
    });
  });

  it('should call triggerAcceptChanges of super Component', () => {
    spyOn(AALInputFormControlComponent.prototype, 'triggerAcceptChanges');
    component.triggerAcceptChanges();
    expect(AALInputFormControlComponent.prototype.triggerAcceptChanges).toHaveBeenCalled();
  });

  it('should call onBlur of super Component', () => {
    spyOn(AALInputFormControlComponent.prototype, 'onBlur').and.callThrough();
    component.onBlur();
    expect(AALInputFormControlComponent.prototype.onBlur).toHaveBeenCalled();
  });

  it('should return, when onBlur is triggered and relatedTarget is the confirm-toolbar', () => {
    component.ID = 'test';
    const elem = document.createElement('div');
    elem.id = 'test_close';
    const event = new FocusEvent('focus', {relatedTarget: elem});
    const ret = component.onBlur(event);
    expect(ret).toEqual(undefined);
  });

  it('should accept event changes on onKeyUp function', () => {
    const event = new Event('keyup') as KeyboardEvent;
    jasmine.clock().install();
    component.timeOutReference = 1234;
    component.onKeyUp(event);
    jasmine.clock().tick(5001);
    jasmine.clock().uninstall();
    expect(component.showLinkHint).toBe(false);
  });

  it('should accept invalid value in control', () => {
    component.control = new UntypedFormControl('', Validators.required);
    component.control.setValue('');
    fixture.detectChanges();
    expect(component.isLinkValid()).toBe(false);
  });

  it('should call click of super Component', () => {
    spyOn(AALInputFormControlComponent.prototype, 'onClick');
    const $event = {
      target: {id: 'linkButtonContainer-test'}
    };
    component.click($event);
    expect(AALInputFormControlComponent.prototype.onClick).toHaveBeenCalled();
  });

  it('should return default tooltip when control is null or blank', () => {
    component.control.setValue('');
    const returnValue = component.getTooltip();
    expect(returnValue).toBe('Set Hyperlink First');
  });

  it('should return null tooltip when control is not null or blank', () => {
    component.control.setValue('test link');
    const returnValue = component.getTooltip();
    expect(returnValue).toBe('');
  });
});


