/*
 * Public API Surface of material
 */

export * from './select-single.component';
export * from './select-single.module';
