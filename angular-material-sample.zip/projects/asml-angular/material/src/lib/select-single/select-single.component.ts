import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {AALFixedInputFormControlComponent, HistoryService} from '@asml-angular/common';

@Component({
  selector: 'aal-select-single',
  templateUrl: './select-single.component.html',
  styleUrls: ['./select-single.component.scss']
})
export class AALSelectSingleComponent extends AALFixedInputFormControlComponent implements OnInit {
  @Output()
  optionPanelClosed: EventEmitter<void> = new EventEmitter();
  @Input()
  showBorderLine: boolean;
  @Input()
  showBorderAtIndex: number;
  @Input()
  set openOptionsPanel(value: boolean) {
    if (value) {
      this.onClick();
    }
  }

  constructor(historyService: HistoryService) {
    super(historyService);
  }

  onChange($event?: Event) {
    if (!$event) {
      super.onChange($event);
    }
  }

  onClick() {
    super.onClick();
    setTimeout(() => {
      if (this.selectField && this.selectField.trigger) {
        this.selectField.trigger.nativeElement.click();
      }
    }, 200);
  }

  optionsPanelClosed() {
    this.optionPanelClosed.emit();
  }
}
