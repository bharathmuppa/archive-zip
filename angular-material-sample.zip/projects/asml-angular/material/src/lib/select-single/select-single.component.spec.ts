import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import {ElementRef} from '@angular/core';
import {By} from '@angular/platform-browser';
import {UntypedFormControl, Validators} from '@angular/forms';
import {CommonModule} from '@angular/common';
import {AALFixedInputFormControlComponent} from '@asml-angular/common';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';

import {SharedMaterialModule} from '../shared/shared-material.module';
import {SharedFormModule} from '../shared/shared-form.module';
import {SharedModule} from '../shared/shared.module';
import {SharedFlexLayoutModule} from '../shared/shared-flex-layout.module';
import {AALChipModule} from '../chip/chip.module';
import {AALSelectSingleComponent} from './select-single.component';

describe('AALSelectSingleComponent', () => {
  let component: AALSelectSingleComponent;
  let fixture: ComponentFixture<AALSelectSingleComponent>;
  let button: ElementRef;
  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [AALSelectSingleComponent],
      imports: [
        CommonModule,
        SharedMaterialModule,
        SharedFormModule,
        SharedModule,
        SharedFlexLayoutModule,
        AALChipModule,
        BrowserAnimationsModule
      ]
    }).compileComponents().then(() => {
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALSelectSingleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    jasmine.clock().uninstall();
    component.control = new UntypedFormControl('actualVal', Validators.compose([]));
    button = fixture.debugElement.query(By.css('.aal-input-read-section'));
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should compare objects using compareByValue function', () => {
    const value1 = {name: 'Option'};
    const value2 = {name: 'Option'};
    expect(component.compareByValue(value1, value2)).toBe(true);
  });
  it('should compare strings using compareByValue function', () => {
    const value1 = 'Option';
    const value2 = 'Option';
    expect(component.compareByValue(value1, value2)).toBe(true);
  });
  it('should call onClick of super Component', () => {
    spyOn(AALFixedInputFormControlComponent.prototype, 'onClick');
    component.onClick();
    expect(AALFixedInputFormControlComponent.prototype.onClick).toHaveBeenCalled();
  });
  it('should open optionsPanel, when onClick is triggered and secondaryControl does not exist', () => {
    component.selectField = {
      trigger: new ElementRef<any>({
        click: () => {}
      })
    };
    const spy = spyOn(component.selectField.trigger.nativeElement, 'click').and.callFake(() => {});
    jasmine.clock().install();
    component.onClick();
    jasmine.clock().tick(300);
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
    jasmine.clock().uninstall();
  });

  it('should call onChange of super Component', () => {
    spyOn(AALFixedInputFormControlComponent.prototype, 'onChange');
    component.onChange();
    expect(AALFixedInputFormControlComponent.prototype.onChange).toHaveBeenCalled();
  });

  it('should display all the options, when openOptionsPanel is set to true', () => {
    const spy = spyOn(component, 'onClick');
    component.openOptionsPanel = true;
    expect(spy).toHaveBeenCalled();
  });

  it('should emit optionPanelClosed, when optionsPanelClosed is triggered', () => {
    const spy = spyOn(component.optionPanelClosed, 'emit');
    component.optionsPanelClosed();
    expect(spy).toHaveBeenCalled();
  });

});
