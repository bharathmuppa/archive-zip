import {ComponentFixture, TestBed, waitForAsync} from '@angular/core/testing';
import {AALDatePickerWeekComponent} from './date-picker-week.component';
import {AALCommonComponentsModule} from '@asml-angular/common';
import {CommonModule} from '@angular/common';
import {MatDatepickerModule} from '@angular/material/datepicker';

import {SharedMaterialModule} from '../shared/shared-material.module';
import {SharedFormModule} from '../shared/shared-form.module';
import {SharedModule} from '../shared/shared.module';
import {SharedFlexLayoutModule} from '../shared/shared-flex-layout.module';
import {AALDatePickerComponent} from '../date-picker/date-picker.component';
import {AALDatePickerSelectComponent} from '../date-picker-select/date-picker-select.component';

describe('AALDatePickerWeekComponent', () => {
  let component: AALDatePickerWeekComponent;
  let fixture: ComponentFixture<AALDatePickerWeekComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [AALDatePickerWeekComponent, AALDatePickerComponent, AALDatePickerSelectComponent],
      imports: [CommonModule,
        SharedMaterialModule,
        SharedFormModule,
        AALCommonComponentsModule,
        SharedModule,
        SharedFlexLayoutModule,
        MatDatepickerModule]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALDatePickerWeekComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    jasmine.clock().uninstall();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should get week list when getListOfWeeks trigger and End is not 1', () => {
    const weekList = component.getListOfWeeks(3, 5, 4);
    expect(weekList).toEqual([3, 4, 5, 6]);
  });

  it('should get week list when getListOfWeeks trigger and End is 1', () => {
    const weekList = component.getListOfWeeks(10, 1, 4);
    expect(weekList).toEqual([10, 11, 12, 1]);
  });

  it('should set date to control', () => {
    const today = new Date();
    component.dateValue = today;
    component.setDateInput();
    expect(component.control.value).toBe(today);
  });

  it('should get month number when month name value is passed on trigger getMonthNumber', () => {
    expect(component.getMonthNumber('Mar')).toBe(2);
  });

  it('should call addCalenderEvents, when datePickerOpened is triggered', () => {
    component.control.setValue(new Date());
    spyOn(component, 'initializeDatePicker').and.callFake(() => {
    });
    spyOn(component, 'addCalenderEvents').and.callFake(() => {
    });
    component.datePickerOpened();
    expect(component.addCalenderEvents).toHaveBeenCalled();
  });

  it('should call insertAdjacentHTML, when initializeDatePicker is triggered', () => {
    const ele = document.createElement('div');
    spyOn(document, 'getElementsByClassName').and.returnValue(
      [ele] as unknown as HTMLCollection
    );
    const spy = spyOn(ele, 'insertAdjacentHTML');
    component.weekSection = {
      nativeElement: {
        innerHTML: '<p>Test</p>'
      }
    };
    jasmine.clock().install();
    component.initializeDatePicker();
    jasmine.clock().tick(300);
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
    jasmine.clock().uninstall();
  });

  it('should call getListOfWeeks, when calculateWeeks is triggered and the date is 1-JAN-2017', () => {
    const spy = spyOn(component, 'getListOfWeeks');
    component.calculateWeeks('Jan', 2017);
    expect(spy).toHaveBeenCalled();
  });

  it('should call getListOfWeeks, when calculateWeeks is triggered and the date is 1-AUG-2021', () => {
    const spy = spyOn(component, 'getListOfWeeks');
    component.calculateWeeks('Aug', 2021);
    expect(spy).toHaveBeenCalled();
  });

  it('should call renderWeekList, when addCalenderEvents is triggered', () => {
    const ele1 = document.createElement('div');
    const ele2 = document.createElement('div');
    const btn1 = document.createElement('button');
    const btn2 = document.createElement('button');
    const btn3 = document.createElement('button');
    const spy = spyOn(component, 'renderWeekList').and.callThrough();
    spyOn(document, 'getElementsByClassName').and.callFake(() => {
      return [ele1] as unknown as HTMLCollection;
    });
    spyOn(ele1, 'getElementsByClassName').and.callFake(() => {
      return [ele2] as unknown as HTMLCollection;
    });
    spyOn(document, 'querySelectorAll').and.returnValue([btn1, btn2] as unknown as NodeListOf<Element>);
    spyOn(document, 'querySelector').and.returnValue(btn3);
    spyOn(Element.prototype, 'addEventListener').and.callFake(
      (evt, data) => {
        data('mockEvent', {});
      }
    );
    jasmine.clock().install();
    component.addCalenderEvents();
    jasmine.clock().tick(400);
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
    jasmine.clock().uninstall();
  });

  it('should call calculateWeeks, when renderWeekList is triggered', () => {
    const ele1 = document.createElement('div');
    const ele2 = document.createElement('div');
    const btn = document.createElement('button');
    btn.innerText = 'test';
    const spy = spyOn(component, 'calculateWeeks');

    spyOn(document, 'getElementsByClassName').and.callFake(() => {
      return [ele1] as unknown as HTMLCollection;
    });
    spyOn(ele1, 'getElementsByClassName').and.callFake(() => {
      return [ele2] as unknown as HTMLCollection;
    });
    spyOn(document, 'querySelector').and.returnValue(btn);
    component.weekSection = {
      nativeElement: {
        innerHTML: '<p>Test</p>'
      }
    };
    jasmine.clock().install();
    component.renderWeekList();
    jasmine.clock().tick(300);
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
    jasmine.clock().uninstall();
  });

  it('should return appropriate weeksList, when getListOfWeeks is triggered', () => {
    const returnValue = component.getListOfWeeks(53, 2, 4);
    expect(returnValue).toEqual([53, 1, 2, 3]);
  });

  it('should call renderWeekList, when monthSelected is triggered', () => {
    const ele1 = document.createElement('div');
    spyOn(document, 'getElementsByClassName').and.callFake(() => {
      return [ele1] as unknown as HTMLCollection;
    });
    const spy = spyOn(component, 'renderWeekList');
    component.weekSection = {
      nativeElement: {
        innerHTML: '<p>Test</p>'
      }
    };
    jasmine.clock().install();
    component.monthSelected({});
    jasmine.clock().tick(300);
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
    jasmine.clock().uninstall();
  });
});
