import {Component, ElementRef, Renderer2, ViewChild} from '@angular/core';
import {MatDatepicker} from '@angular/material/datepicker';
import {UntypedFormControl} from '@angular/forms';
import {AALDatePickerFormControlComponent, HistoryService} from '@asml-angular/common';
import {DateTime} from 'luxon';

@Component({
  selector: 'aal-date-picker-week',
  templateUrl: './date-picker-week.component.html',
  styleUrls: ['./date-picker-week.component.scss']
})
export class AALDatePickerWeekComponent extends AALDatePickerFormControlComponent {
  weeksList: Array<number>;
  @ViewChild('picker', {static: false}) datepicker: MatDatepicker<any>;
  @ViewChild('weekSection', {static: false}) weekSection: ElementRef;
  dateValue: Date;
  startDay: number;

  constructor(public renderer: Renderer2,
              historyService: HistoryService) {
    super(historyService);
    this.control = new UntypedFormControl();
  }

  datePickerOpened() {
    this.dateValue = this.control.value;
    this.initializeDatePicker();
    this.calculateWeeks();
    this.addCalenderEvents();
  }

  initializeDatePicker() {
    setTimeout(() => {
      const matDatePicker = document.getElementsByClassName('mat-datepicker-content')[0];
      matDatePicker.insertAdjacentHTML('afterbegin', this.weekSection.nativeElement.innerHTML);
    }, 200);
  }

  calculateWeeks(month?, year?) {
    let startDate = new Date();
    if (month && year) {
      startDate = DateTime.fromObject({year: year, month: this.getMonthNumber(month) + 1}).toJSDate();
    } else if (this.dateValue) {
      startDate = DateTime.fromObject({
        year: new Date(this.dateValue).getFullYear(),
        month: (new Date(this.dateValue).getMonth() + 1)
      }).toJSDate();
    }
    this.startDay = DateTime.fromJSDate(startDate).startOf('month').weekday;
    const startOfMonth = DateTime.fromJSDate(startDate).startOf('month').toJSDate();
    const endOfMonth = DateTime.fromJSDate(startDate).endOf('month').toJSDate();
    let startWeekNumber = DateTime.fromJSDate(startOfMonth).weekNumber as any;
    let endWeekNumber = DateTime.fromJSDate(endOfMonth).weekNumber as any;
    const numWeeksInMonth: any = DateTime.fromMillis(DateTime.now().endOf('month').diff(DateTime.now().startOf('month')).milliseconds).weekNumber;
    // if first day of month is sunday, This is because week starts from Monday
    if (startOfMonth.getDay() === 0) {
      startWeekNumber = startWeekNumber + 1;
      endWeekNumber = endWeekNumber + 1;
      // if its first week of Jan
      if (startWeekNumber >= 52) {
        startWeekNumber = 1;
      } else {
        endWeekNumber = endWeekNumber - 1;
      }
    }
    this.weeksList = this.getListOfWeeks(startWeekNumber, endWeekNumber, numWeeksInMonth);
  }

  addCalenderEvents() {
    setTimeout(() => {
      this.setDateInput();
      const matDatePicker = document.getElementsByClassName('mat-datepicker-content')[0];
      const nextPreviousButtons = document.querySelectorAll('.mat-calendar .mat-calendar-previous-button,' + '.mat-calendar .mat-calendar-next-button');
      const monthYearSection = document.querySelector('.mat-calendar-period-button .mat-button-wrapper');

      setTimeout(() => {
        const calendarPeriodButton = document.querySelector('.mat-calendar-period-button');
        if (calendarPeriodButton) {
          this.renderer.listen(calendarPeriodButton, "click", (event) => {
            this.renderWeekList();
          });
        }
        if (nextPreviousButtons) {
          Array.from(nextPreviousButtons).forEach(button => {
            this.renderer.listen(button, 'click', () => {
              this.renderWeekList();
            });
          });
        }
      }, 100);
    }, 200);
  }

  renderWeekList() {
    const matDatePicker = document.getElementsByClassName('mat-datepicker-content')[0];
    const period = (document.querySelector('.mat-calendar-period-button .mat-button-wrapper') as HTMLElement).innerText;
    const selectedDate = new Date(isNaN(Date.parse(period)) ? period.split(' ')[0] : period);
    const monthChanged = DateTime.fromJSDate(selectedDate).monthShort;
    const yearChanged = selectedDate.getFullYear();
    this.calculateWeeks(monthChanged, yearChanged);
    setTimeout(() => {
      if (matDatePicker.getElementsByClassName('week-section')[0]) {
        matDatePicker.getElementsByClassName('week-section')[0].remove();
      }
      if (period && period.length !== 11) { // to check whether it is Month period(8) or Year period(11)
        matDatePicker.insertAdjacentHTML('afterbegin', this.weekSection.nativeElement.innerHTML);
      }
    }, 200);
  }


  getListOfWeeks(start, end, numWeeksInMonth): Array<number> {
    numWeeksInMonth = parseInt(numWeeksInMonth, 10);
    const weeksList = [];
    if (end < start) {
      if (start >= 52) {
        weeksList.push(start);
        for (let i = 1; i < numWeeksInMonth; i++) {
          weeksList.push(i);
        }
      } else {
        for (let i = 1; i <= numWeeksInMonth - 1; i++) {
          weeksList.push(start++);
        }
        weeksList.push(end);
      }
    } else {
      for (let i = 1; i <= numWeeksInMonth; i++) {
        weeksList.push(start++);
      }
    }
    return weeksList;
  }

  monthSelected(event) {
    setTimeout(() => {
      const matDatePicker = document.getElementsByClassName('mat-datepicker-content')[0];
      matDatePicker.insertAdjacentHTML('afterbegin', this.weekSection.nativeElement.innerHTML);
      this.renderWeekList();
    }, 200);
  }

  getMonthNumber(month) {
    const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return monthNames.findIndex(item => item.toLowerCase() === month.toLowerCase());
  }

  setDateInput() {
    this.control.setValue(this.dateValue);
  }
}
