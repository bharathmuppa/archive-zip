import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {AALDatePickerWeekComponent} from './date-picker-week.component';
import {AALCommonComponentsModule} from '@asml-angular/common';
import {MatDatepickerModule} from '@angular/material/datepicker';
import {MatNativeDateModule} from '@angular/material/core';
import {AALTextFieldModule} from '../text-field/text-field.module';
import {FlexLayoutModule} from '@angular/flex-layout';

@NgModule({
  declarations: [AALDatePickerWeekComponent],
  imports: [
    CommonModule,
    AALTextFieldModule,
    AALCommonComponentsModule,
    MatDatepickerModule,
    MatNativeDateModule,
    FlexLayoutModule
  ],
  exports: [
    AALDatePickerWeekComponent
  ]
})
export class AALDatePickerWeekModule {
}
