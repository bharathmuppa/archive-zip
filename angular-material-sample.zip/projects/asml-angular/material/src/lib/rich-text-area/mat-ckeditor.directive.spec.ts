import {Component, DebugElement, OnInit} from '@angular/core';
import {
  FormsModule,
  ReactiveFormsModule,
  UntypedFormBuilder,
  UntypedFormControl
} from '@angular/forms';
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import {DEFAULT_RICH_TEXT_CONFIGURATION} from './rich-text-area.model';
import {ComponentFixture, TestBed} from '@angular/core/testing';
import {CkeditorDirective} from './ckeditor.directive';
import {BlurEvent, CKEditorComponent, CKEditorModule} from '@ckeditor/ckeditor5-angular';
import {By} from '@angular/platform-browser';
import {BehaviorSubject} from 'rxjs';


@Component({
  template: `
    <ckeditor aalCkeditor #ckEditor [config]="editorConfig" [editor]="editor" [formControl]="control"></ckeditor>`
})
class TestComponent implements OnInit {
  control: UntypedFormControl;
  editor = ClassicEditor;
  editorConfig = DEFAULT_RICH_TEXT_CONFIGURATION;

  constructor(private formBuilder: UntypedFormBuilder) {
  }

  ngOnInit() {
    this.control = this.formBuilder.control(' test value ');
  }
}

describe('MatCkeditorDirective', () => {
  let directive: CkeditorDirective;
  let component: TestComponent;
  let fixture: ComponentFixture<TestComponent>;
  let debugElement: DebugElement;
  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [
        TestComponent,
        CkeditorDirective
      ],
      imports: [
        FormsModule,
        ReactiveFormsModule,
        CKEditorModule
      ]
    }).compileComponents().then(() => {
      const editor = {
        blur: new BehaviorSubject(''),
        focus: new BehaviorSubject('')
      } as unknown as CKEditorComponent;
      directive = new CkeditorDirective(editor, null, null, null, null, null);
    });
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TestComponent);
    component = fixture.componentInstance;
    debugElement = fixture.debugElement.query(By.directive(CkeditorDirective));
    fixture.detectChanges();
  });

  it('should create component', () => {
    directive = new CkeditorDirective(null, null, null, null, null, null);
    expect(directive).toBeTruthy();
  });

  it('should set focused as false, when onBlur of editor is triggered', () => {
    const editor = {
      blur: new BehaviorSubject(''),
      focus: new BehaviorSubject('')
    } as unknown as CKEditorComponent;
    directive = new CkeditorDirective(editor, null, null, null, null, null);
    directive.focused = true;
    directive.ngOnInit();
    directive.editor.blur.next({} as BlurEvent);
    expect(directive.focused).toEqual(false);
  });

  it('should trigger editor focus method, when onContainer click is called', () => {
    const editor = {
      editorInstance: {
        editing: {
          view: {
            focus: () => {}
          }
        }
      }
    } as unknown as CKEditorComponent;
    const spy = spyOn(editor.editorInstance.editing.view, 'focus');
    directive = new CkeditorDirective(editor, null, null, null, null, null);
    directive.onContainerClick();
    expect(spy).toHaveBeenCalled();
  });

  it('should set appropriate describedBy, when setDescribedByIds is triggered', () => {
    const editor = {
      blur: new BehaviorSubject('')
    } as unknown as CKEditorComponent;
    directive = new CkeditorDirective(editor, null, null, null, null, null);
    directive.setDescribedByIds(['a', 'b']);
    expect(directive.describedBy).toEqual('a b');
  });

  it('should call setDisabledState, when disabled is set as true', () => {
    const editor = {
      setDisabledState: (isDisabled: boolean) => {}
    } as unknown as CKEditorComponent;
    const spy = spyOn(editor, 'setDisabledState');
    directive = new CkeditorDirective(editor, null, null, null, null, null);
    directive.disabled = true;
    const disabled = directive.disabled;
    expect(spy).toHaveBeenCalled();
  });

  it('should set editor data, when value is set', () => {
    const editor = {
      editorInstance: {
        getData: () => {
          return 'test';
        }
      }
    } as unknown as CKEditorComponent;
    directive = new CkeditorDirective(editor, null, null, null, null, null);
    directive.value = 'Foo';
    directive.focused = false;
    expect(directive.editor.data).toEqual('Foo');
  });
});


