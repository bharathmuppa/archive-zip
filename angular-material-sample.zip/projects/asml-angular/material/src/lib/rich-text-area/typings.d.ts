// Typings for the editor used in the sample app to satisfy the TS compiler.

declare module '@ckeditor/ckeditor5-build-classic' {
  const ClassicEditorBuild: any;

  export = ClassicEditorBuild;
}
