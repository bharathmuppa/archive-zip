export const DEFAULT_RICH_TEXT_CONFIGURATION = {
  toolbar: {
    items: [
      'bold',
      'italic',
      '|',
      'bulletedList',
      'numberedList',
      '|',
      'link',
      '|',
      'insertTable',
      '|',
      'undo',
      'redo'
    ],
    shouldNotGroupWhenFull: true
  },
  link: {
    decorators: {
      addTargetToExternalLinks: {
        mode: 'automatic',
        callback: url => /^(https?:)?\/\//.test( url ),
        attributes: {
          target: '_blank',
          rel: 'noopener noreferrer'
        }
      }
    }
  }
};
