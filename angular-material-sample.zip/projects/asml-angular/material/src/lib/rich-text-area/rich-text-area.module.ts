import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {CKEditorModule} from '@ckeditor/ckeditor5-angular';

import {AALRichTextAreaComponent} from './rich-text-area.component';
import {CkeditorDirective} from './ckeditor.directive';
import {AALOverlayCardHelpModule} from '../overlay-card-help/overlay-card-help.module';
import {FlexLayoutModule} from '@angular/flex-layout';
import {
  MatProgressSpinnerModule
} from '@angular/material/progress-spinner';
import {MatInputModule} from '@angular/material/input';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {AALToolbarConfirmModule} from '../toolbar-confirm/toolbar-confirm.module';
import {
  MatTooltipModule
} from '@angular/material/tooltip';
import {AALOverlayCardErrorModule} from '../overlay-card-alert/overlay-card-alert.module';
import {AALCommonModule} from '@asml-angular/common';
import {MatButtonModule} from '@angular/material/button';

@NgModule({
  declarations: [AALRichTextAreaComponent, CkeditorDirective],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    AALCommonModule,
    AALOverlayCardHelpModule,
    AALOverlayCardErrorModule,
    AALToolbarConfirmModule,
    CKEditorModule,
    MatButtonModule,
    MatInputModule,
    MatProgressSpinnerModule,
    MatTooltipModule,
    FlexLayoutModule
  ],
  exports: [
    AALRichTextAreaComponent
  ]
})
export class AALRichTextAreaModule {
}
