import {ComponentFixture, TestBed, waitForAsync} from '@angular/core/testing';
import {UntypedFormControl, Validators} from '@angular/forms';
import {AALRichTextAreaComponent} from './rich-text-area.component';
import {AALInputFormControlComponent} from '@asml-angular/common';
import {AALRichTextAreaModule} from "./rich-text-area.module";
import createSpyObj = jasmine.createSpyObj;

describe('AALRichTextAreaComponent', () => {
  let component: AALRichTextAreaComponent;
  let fixture: ComponentFixture<AALRichTextAreaComponent>;
  let event = {};
  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [
        AALRichTextAreaModule
      ],
    })
      .compileComponents().then(() => {
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALRichTextAreaComponent);
    component = fixture.componentInstance;
    event = createSpyObj('event', ['relatedTarget']);
    fixture.detectChanges();
    jasmine.clock().uninstall();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should check the overflow', () => {
    component.readModeDivision.nativeElement = document.createElement('div');
    expect(component.showMore).toBe(true);
  });

  it('should call triggerAcceptChanges of super Component when there in change in value ', () => {
    component.control = new UntypedFormControl('', Validators.required);
    spyOn(AALInputFormControlComponent.prototype, 'triggerAcceptChanges').and.callThrough();
    component.control.setValue('1234');
    component.triggerAcceptChanges();
    expect(AALInputFormControlComponent.prototype.triggerAcceptChanges).toHaveBeenCalled();
  });

  it('should call triggerAcceptChanges of super Component when there is no protocol in link added ', () => {
    component.control = new UntypedFormControl('', Validators.required);
    spyOn(AALInputFormControlComponent.prototype, 'triggerAcceptChanges').and.callThrough();
    component.control.setValue('<p>Test<a target="_blank" rel="noopener noreferrer" href="www.google.com">www.google.com</a></p>');
    component.triggerAcceptChanges();
    expect(component.control.value).toBe('<p>Test<a target="_blank" rel="noopener noreferrer" href="http://www.google.com">www.google.com</a></p>');
  });

  it('should call triggerAcceptChanges of super Component when there is protocol in link added ', () => {
    component.control = new UntypedFormControl('', Validators.required);
    spyOn(AALInputFormControlComponent.prototype, 'triggerAcceptChanges').and.callThrough();
    component.control.setValue('<p>Test<a target="_blank" rel="noopener noreferrer" href="http://www.google.com">www.google.com</a></p>');
    component.triggerAcceptChanges();
    expect(component.control.value).toBe('<p>Test<a target="_blank" rel="noopener noreferrer" href="http://www.google.com">www.google.com</a></p>');
  });


  it('should emit the values triggerRejectChanges', () => {
    spyOn(component.pressRejectEvent, 'emit');
    component.triggerRejectChanges();
    expect(component.pressRejectEvent.emit).toHaveBeenCalled();
  });

  it('should toggleShowMoreContent on click', () => {
    component.control = new UntypedFormControl('', Validators.required);
    const $event = new Event('click');
    component.showMore = true;
    component.expand = true;
    component.toggleShowMoreContent($event);
    expect(component.expand).toBe(true);
  });

  it('should accept changes for getTextLength', () => {
    component.control = new UntypedFormControl('', Validators.required);
    component.control.setValue('sample text');
    const returnValue = component.getTextLength();
    expect(returnValue).toBe(11);
  });

  it('should accept changes for getTextLength when null', () => {
    component.control = new UntypedFormControl('', Validators.required);
    component.control.setValue('');
    const returnValue = component.getTextLength();
    expect(returnValue).toBe(0);
  });

  it('Should call onClick method', () => {
    jasmine.clock().install();
    spyOn(component, 'handleKeyEvents');
    component.onClick();
    component.ckEditor = {
      editorInstance: {
        editing: {
          view: {
            document: {
              on: (evt, data) => {
              }
            },
            focus: () => {
            }
          }
        },
        model: {
          change: (writer) => {
          }
        },
        document: {
          on: (data) => {
          },
          getRoot: () => {
          }
        }
      }
    };
    jasmine.clock().tick(502);
    expect(component.handleKeyEvents).toHaveBeenCalled();
    jasmine.clock().uninstall();
  });

  it('should call onclick event', () => {
    const clickEvent = spyOn(component, 'onClick');
    component.setFocusInInput();
    expect(clickEvent).toHaveBeenCalled();
  });

  it('should click on related target if clickPrimaryControlOnBlur flag is set', () => {
    component.control = new UntypedFormControl('sample text');
    component.clickPrimaryControlOnBlur = true;
    const elem = document.createElement('input');
    const elemClickSpy = spyOn(elem, 'click');
    component.onBlur({relatedTarget: elem});
    expect(elemClickSpy).toHaveBeenCalled();
  });

  it('should call triggerRejectChanges, when handleKeyEvents is triggered', () => {
    component.ckEditor = {
      editorInstance: {
        editing: {
          view: {
            document: {
              on: (evt, data) => {
              }
            },
            focus: () => {
            }
          }
        },
        model: {
          change: (writer) => {
          }
        },
        document: {
          on: (data) => {
          },
          getRoot: () => {
          }
        }
      }
    };
    spyOn(component.ckEditor.editorInstance.editing.view.document, 'on').and.callFake(
      (evt, data) => {
        data('mockEvent', {keyCode: 27});
      }
    );
    component.handleKeyEvents();
  });

  it('should call onFocus of the parent class, when onfocus is triggered', () => {
    const spy = spyOn(AALInputFormControlComponent.prototype, 'onFocus');
    component.onfocus();
    expect(spy).toHaveBeenCalled();
  });

  it('should return, when onBlur is triggered and relatedTarget is mat-select', () => {
    const elem = document.createElement('div');
    elem.classList.add('mat-select');
    const evt = new FocusEvent('focus', {relatedTarget: elem});
    const ret = component.onBlur(evt);
    expect(ret).toEqual(undefined);
  });

  it("should call openShowMoreByDefault() and show the rich-text-area's full content by default when we pass showMoreWithoutEdit flag as true", () => {
    component.control = new UntypedFormControl('RamaSivaVarma Show full content test', Validators.required);
    component.showMore = true;
    component.expand = true;

    const openShowMoreByDefault = spyOn(component, 'openShowMoreByDefault');
    component.ngAfterViewInit();

    expect(openShowMoreByDefault).toHaveBeenCalled();
  });

  it("should call openShowMoreByDefault() and show the rich-text-area's full content by default when we pass showMoreWithoutEdit and showMoreByDefault flags as true", () => {
    component.control = new UntypedFormControl('Show full content test', Validators.required);
    component.expand = true;

    const openShowMoreByDefault = spyOn(component, 'openShowMoreByDefault');
    component.ngAfterViewInit();

    expect(openShowMoreByDefault).toHaveBeenCalled();
    expect(component.refNoShowMoreRichTextArea).not.toBeTruthy();
  });


  it("should pass expand value as false and on calling onBlurSetShowMore method, showMore value should be true .", () => {
    component.showMore = true;
    component.expand = false;

    component.toggleShowMoreContent();
    document.getElementById("div-in-read-mode").click();
    expect(component.isInShowMoreState).toBe(true);

  })

  it('should call toggleShowMoreContent() and emit show more value.', () => {
    const _event = new Event("click");

    component.showMore = true;

    const spyOnToggleProtectedShowMoreContent = spyOn(component, "toggleShowMoreContent");
    const spyOnEmitShowMoreValue = spyOn(component.emitShowMoreValue, 'emit');
    component.toggleShowMoreContent(_event);
    component.emitShowMoreValue.emit(component.showMore);

    expect(spyOnToggleProtectedShowMoreContent).toHaveBeenCalledWith(_event);
    expect(spyOnEmitShowMoreValue).toHaveBeenCalledWith(true);
  });


});
