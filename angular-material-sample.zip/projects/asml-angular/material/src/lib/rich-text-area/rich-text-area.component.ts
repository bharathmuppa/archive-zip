/**
 * Component that compose rich text area of CkEditor component and AAL Component style
 */

import {
  ChangeDetectorRef,
  Component,
  ElementRef,
  EventEmitter,
  HostListener,
  Input,
  NgZone,
  OnInit,
  Output,
  SecurityContext,
  ViewChild
} from '@angular/core';
import {AALInputFormControlComponent, HistoryService, Modes} from '@asml-angular/common';
import {DomSanitizer} from '@angular/platform-browser';
import {UntypedFormControl} from '@angular/forms';

import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import {CKEditor5} from "@ckeditor/ckeditor5-angular";

import {DEFAULT_RICH_TEXT_CONFIGURATION} from './rich-text-area.model';


@Component({
  selector: 'aal-rich-text-area',
  templateUrl: './rich-text-area.component.html',
  styleUrls: ['./rich-text-area.component.scss']
})
export class AALRichTextAreaComponent extends AALInputFormControlComponent implements OnInit {
  /**
   * Configuration required for CKEditor, it specifies the tools and plugins required by the User
   */
  @Input()
  editorConfig: any = DEFAULT_RICH_TEXT_CONFIGURATION;

  /**
   * Sets the RTE in disabled mode
   */
  @Input()
  disabled: boolean;

  /**
   * Flag to show/hide the Length hint
   */
  @Input()
  showLengthHint: boolean;

  /**
   * Max length of field
   */
  @Input()
  maxLength: number;

  /**
   * Hint about the field
   */
  @Input()
  hint: string;

  /**
   * TODO: Define what is Composite placeholder
   */
  @Input()
  compositePlaceholder?: string; // Used for composite controls

  /**
   * TODO: Define this property
   */
  @Input()
  clickPrimaryControlOnBlur?: boolean; // Used for composite controls to click on other element on blur

  @Output()
  pressAcceptEvent: EventEmitter<void> = new EventEmitter();
  @Output()
  pressRejectEvent: EventEmitter<void> = new EventEmitter();

  @ViewChild('ckEditor') ckEditor: any;
  /**
   * Editor instance required for CKEditor, it can be of following types
   * Classic Editor
   * Inline Editor and so on
   * @see https://ckeditor.com/docs/ckeditor5/latest/examples/builds/classic-editor.html
   */
  editor = ClassicEditor;

  /**
   * Editor instance used for listening to events
   * It is used as a result of mis behaving blur events when CKEditor is integrated with other frameworks
   * @see https://github.com/ckeditor/ckeditor5/issues/10490
   */
  private activeEditorInstance: CKEditor5.Editor;
  /**
   * flag to show showMore, if the content is more than desired height.
   */
  @Input() showMore: boolean = true;

  /**
   * Height after which show more/show less will be visible.(in px)
   * @Note
   * It should be accompanied by [showMore]="true"
   * It is number, don't use px or rem
   * @example
   * [showMore]="true" [showMoreAfterHeight]="80"
   */
  @Input() showMoreAfterHeight: number = 80;
  private _defaultExpandMode;

  /**
   *
   */
  @Input()
  set expand(isExpanded: boolean) {
    this._defaultExpandMode = isExpanded;
    this.isInShowMoreState = isExpanded;
  }

  get expand() {
    return this._defaultExpandMode;
  }

  public isInShowMoreState = false;
  public isShowMoreRequired = false;


  @ViewChild('readModeDiv') readModeDivision: ElementRef;
  @ViewChild("refShowMoreRichTextArea") refShowMoreRichTextArea: ElementRef;
  @ViewChild("refNoShowMoreRichTextArea") refNoShowMoreRichTextArea: ElementRef;
  @ViewChild("refProtectedShowMoreRichTextArea") refProtectedShowMoreRichTextArea: ElementRef;
  hideShowMoreOnFocus: boolean = false;

  customBlurEventRef = this.customCkEditorBlurEvent.bind(this);

  @Input() disableProtectedMode: boolean = false;
  @Output() emitShowMoreValue: EventEmitter<boolean> = new EventEmitter();

  constructor(historyService: HistoryService, private readonly ref: ChangeDetectorRef,
              private readonly domSanitizer: DomSanitizer, private ngZone: NgZone) {
    super(historyService);
  }

  get control() {
    return this.frmControl;
  }

  @Input()
  set control(control: UntypedFormControl) {
    this.frmControl = control;
    if (control) {
      this.oldValue = (typeof control.value === 'object' ?
        this.domSanitizer.sanitize(SecurityContext.HTML, JSON.parse(JSON.stringify(control.value))) :
        this.domSanitizer.sanitize(SecurityContext.HTML, control.value));
      this.oldValue = (this.oldValue === null || this.oldValue === undefined) ? this.oldValue : new DOMParser().parseFromString(this.oldValue, 'text/html').getElementsByTagName('body')[0].innerHTML;
      this.setInputValue(control.value);
    }
  }

  setInputValue(val): void {
    this.control.setValue(typeof val === 'object' ?
      this.domSanitizer.sanitize(SecurityContext.HTML, JSON.parse(JSON.stringify(val))) :
      this.domSanitizer.sanitize(SecurityContext.HTML, val));
  }

  ngOnInit() {
    this.mode$.subscribe(mode => {
      if (mode === Modes.READ) {
        this.ref.detectChanges();
      }
    });
    super.ngOnInit();
  }

  onfocus() {
    super.onFocus();
  }

  handleKeyEvents(): void {
    if (this.ckEditor && this.ckEditor.editorInstance) {
      this.ckEditor.editorInstance.editing.view.document.on('keyup', (evt, data) => {
        if (data.keyCode === 27) {   // Escape key
          super.triggerRejectChanges();
        }
      });
    }
  }

  /**
   * Checks whether this click should change aal-text-areas to edit mode
   * @param event
   */
  editText(event) {
    // it helps to stop propagation, if target is a hyperlink
    if (event.target.href) {
      return;
    }
    this.onClick();
  }

  onClick() {
    super.setModeToEdit();
    setTimeout(() => {
      if (this.ckEditor && this.ckEditor.editorInstance) {
        this.ckEditor.editorInstance.editing.view.focus();
        this.ckEditor.editorInstance.model.change(writer => {
          writer.setSelection(this.ckEditor.editorInstance.model.document.getRoot(), 'end');
        });
        this.handleKeyEvents();
      }
    }, 0);
  }

  triggerAcceptChanges() {
    this.hideShowMoreOnFocus = false;

    this.control.setValue(typeof this.control.value === 'object' ?
      this.domSanitizer.sanitize(SecurityContext.HTML, JSON.parse(JSON.stringify(this.control.value))) :
      this.domSanitizer.sanitize(SecurityContext.HTML, this.control.value));
    this.sanitizeLinks();
    super.triggerAcceptChanges();
    this.pressAcceptEvent.emit();
  }

  // Pre fix http if no protocol available
  sanitizeLinks() {
    if (this.control.value) {
      const parser = new DOMParser();
      const textHTML = parser.parseFromString(this.control.value, 'text/html');
      const anchorElements = textHTML.querySelectorAll('a') as unknown as any[];
      anchorElements.forEach((anchorElement) => {
        if (anchorElement.attributes && anchorElement.attributes.href && anchorElement.attributes.href.value &&
          !(anchorElement.attributes.href.value.includes('http://') ||
            anchorElement.attributes.href.value.includes('https://') ||
            anchorElement.attributes.href.value.includes('mailto:'))) {
          anchorElement.setAttribute('href', 'http://' + anchorElement.attributes.href.value);
        }
      });
      const innerHTML = textHTML.getElementsByTagName('body')[0].innerHTML;
      this.control.setValue(new DOMParser().parseFromString(innerHTML, 'text/html').getElementsByTagName('body')[0].innerHTML);
    }
  }

  triggerRejectChanges() {
    super.triggerRejectChanges();
    this.pressRejectEvent.emit();
  }

  toggleShowMoreContent($event?: Event) {
    this.isInShowMoreState = !this.isInShowMoreState;
    this.emitShowMoreValue.emit( this.isInShowMoreState);
    $event?.stopPropagation();
  }

  getTextLength(): number {
    const temporalDivElement = document.createElement('div');
    temporalDivElement.innerHTML = this.control.value;
    return (temporalDivElement.textContent || temporalDivElement.innerText || '').trim().length;
  }

  onBlur(evenVal?): void {
    let eventValue = event as any;
    eventValue = eventValue || evenVal;
    if (eventValue instanceof FocusEvent && eventValue.relatedTarget
      && (eventValue.relatedTarget['classList'].contains('mat-select') || eventValue.relatedTarget['classList'].contains('mat-radio-group') || eventValue.relatedTarget['id'].includes(this.hyphenatedID) ||
        eventValue.relatedTarget['parentElement'].classList.contains('skip-input-blur-event'))) {
      // do nothing
      return;
    }
    if (!eventValue.relatedTarget || !eventValue.relatedTarget.classList.contains('ck')) {
      if (eventValue.relatedTarget && this.clickPrimaryControlOnBlur) {
        eventValue.relatedTarget.click();
      }
      super.onBlur();
    }
  }

  setFocusInInput() {
    this.onClick();
  }

  openShowMoreByDefault() {
    if (this.showMore) {
      this.refShowMoreRichTextArea?.nativeElement.click();
    }
  }

  ngAfterViewInit() {
    this.openShowMoreByDefault();
  }

  public onReady(editor: CKEditor5.Editor) {
    this.activeEditorInstance = editor;
    this.activeEditorInstance.ui.focusTracker.on('change:isFocused', this.customBlurEventRef);
  }

  private customCkEditorBlurEvent(_evt, _name, value, oldValue) {
    if (value === false && oldValue === true) {
      this.ngZone.run(() => {
        super.onBlur(_evt);
        this.activeEditorInstance.ui.focusTracker.off('change:isFocused', this.customBlurEventRef);
        this.triggerAcceptChanges();
      });
    }
  }

}
