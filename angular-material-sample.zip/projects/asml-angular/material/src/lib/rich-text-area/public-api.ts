/*
 * Public API Surface of material
 */

export * from './rich-text-area.component';
export * from './rich-text-area.module';
