import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {AALButtonContainedComponent} from './button-contained.component';
import {AALCommonComponentsModule} from '@asml-angular/common';
import {MatBadgeModule} from '@angular/material/badge';
import {MatTooltipModule} from '@angular/material/tooltip';
import {MatButtonModule} from '@angular/material/button';

@NgModule({
  declarations: [AALButtonContainedComponent],
  imports: [
    CommonModule,
    AALCommonComponentsModule,
    MatBadgeModule,
    MatTooltipModule,
    MatButtonModule,
  ],
  exports: [AALButtonContainedComponent]
})
export class AALButtonContainedModule {
}
