import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import {MatBadgeModule} from '@angular/material/badge';
import {CommonModule} from '@angular/common';
import {AALCommonComponentsModule} from '@asml-angular/common';

import {SharedMaterialModule} from '../shared/shared-material.module';
import {SharedFormModule} from '../shared/shared-form.module';
import {SharedModule} from '../shared/shared.module';
import {SharedFlexLayoutModule} from '../shared/shared-flex-layout.module';
import {AALButtonContainedComponent} from './button-contained.component';

describe('AALButtonContainedComponent', () => {
  let component: AALButtonContainedComponent;
  let fixture: ComponentFixture<AALButtonContainedComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ AALButtonContainedComponent ],
      imports: [
        CommonModule,
        SharedMaterialModule,
        SharedFormModule,
        AALCommonComponentsModule,
        SharedModule,
        SharedFlexLayoutModule,
        MatBadgeModule
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALButtonContainedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
