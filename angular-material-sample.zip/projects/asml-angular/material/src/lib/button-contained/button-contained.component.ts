import {Component} from '@angular/core';
import {AALCommonButtonComponent} from '@asml-angular/common';

@Component({
  selector: 'aal-button-contained',
  templateUrl: './button-contained.component.html',
  styleUrls: ['./button-contained.component.scss']
})
export class AALButtonContainedComponent extends AALCommonButtonComponent {
}
