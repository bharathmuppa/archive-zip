import {Component, Input} from '@angular/core';
import {AALCommonButtonComponent, HistoryService} from '@asml-angular/common';
import {MatSnackBar} from '@angular/material/snack-bar';

import {ButtonState, ButtonStateConfiguration, ButtonStateData, ButtonStates} from './button-dynamic.model';
import {ToastComponent} from '../toast/toast.component';

@Component({
  selector: 'aal-button-dynamic',
  templateUrl: './button-dynamic.component.html',
  styleUrls: ['./button-dynamic.component.scss']
})
export class AALButtonDynamicComponent extends AALCommonButtonComponent {
  currentState: string;
  toastDuration;
  stateConfigurationValue: ButtonStateConfiguration;
  currentStateData: ButtonStateData;
  buttonStates = ButtonStates;
  @Input()
  showStatusToast: boolean;

  @Input()
  set state(value: ButtonState) {
    this.currentState = value;
    this.setStateData();
    this.setToast();
  }

  @Input()
  set stateConfiguration(stateConfig: ButtonStateConfiguration) {
    this.stateConfigurationValue = stateConfig;
    this.setStateData();
  }

  constructor(public readonly toastBar: MatSnackBar, historyService: HistoryService) {
    super(historyService);
    this.showStatusToast = true;
  }


  click($event): void {
    this.state = ButtonStates.INPROGRESS;
    super.click($event);
  }

  setStateData() {
    if (this.stateConfigurationValue && this.currentState) {
      this.currentStateData = this.stateConfigurationValue[this.currentState.toLowerCase()];
    }
  }

  setToast() {
    if ((this.currentState === ButtonStates.SUCCESS || this.currentState === ButtonStates.FAILURE) &&
      this.showStatusToast && this.currentStateData) {
      this.toastBar.openFromComponent(ToastComponent, {
        data: this.currentStateData.toast, // this.stateConfigurationValue[this.currentState].toast,
        duration: this.currentStateData.toastDuration
      });
    }
  }

  isDisabled(): boolean {
    return (this.currentState === ButtonStates.INPROGRESS) || (this.currentState === ButtonStates.SUCCESS) || (this.currentState === ButtonStates.FAILURE);
  }

}
