import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {AALButtonDynamicComponent} from './button-dynamic.component';
import {ToastModule} from '../toast/toast.module';
import {AALCommonComponentsModule} from '@asml-angular/common';
import {MatBadgeModule} from '@angular/material/badge';
import {MatTooltipModule} from '@angular/material/tooltip';
import {MatIconModule} from '@angular/material/icon';
import {FlexLayoutModule} from '@angular/flex-layout';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import { MatButtonModule } from '@angular/material/button';

@NgModule({
    declarations: [AALButtonDynamicComponent],
    imports: [
        CommonModule,
        AALCommonComponentsModule,
        MatBadgeModule,
        MatButtonModule,
        MatTooltipModule,
        MatIconModule,
        FlexLayoutModule,
        MatProgressSpinnerModule,
        ToastModule
    ],
    exports: [AALButtonDynamicComponent]
})
export class AALButtonDynamicModule {
}
