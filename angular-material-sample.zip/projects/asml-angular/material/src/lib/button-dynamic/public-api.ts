/*
 * Public API Surface of material
 */

export * from './button-dynamic.component';
export * from './button-dynamic.module';
export * from './button-dynamic.model';
