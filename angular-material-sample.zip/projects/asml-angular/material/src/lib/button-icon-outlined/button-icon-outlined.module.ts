import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AALButtonIconOutlinedComponent } from './button-icon-outlined.component';
import {AALCommonComponentsModule} from '@asml-angular/common';
import {MatTooltipModule} from '@angular/material/tooltip';
import {MatBadgeModule} from '@angular/material/badge';
import {MatIconModule} from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';

@NgModule({
  declarations: [AALButtonIconOutlinedComponent],
  imports: [
    CommonModule,
    AALCommonComponentsModule,
    MatBadgeModule,
    MatButtonModule,
    MatIconModule,
    MatTooltipModule,
  ],
  exports: [AALButtonIconOutlinedComponent]
})
export class AALButtonIconOutlinedModule { }
