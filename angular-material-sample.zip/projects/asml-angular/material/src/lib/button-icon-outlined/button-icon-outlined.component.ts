import {Component} from '@angular/core';
import {AALCommonButtonComponent} from '@asml-angular/common';

@Component({
  selector: 'aal-button-icon-outlined',
  templateUrl: './button-icon-outlined.component.html',
  styleUrls: ['./button-icon-outlined.component.scss']
})

export class AALButtonIconOutlinedComponent extends AALCommonButtonComponent {

}
