import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {AALAnalyticsPanelComponent} from './analytics-panel.component';
import {AALCommonComponentsModule} from '@asml-angular/common';
import { AALAnalyticsCardComponent } from './analytics-card/analytics-card.component';
import {MatTooltipModule} from '@angular/material/tooltip';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {MatIconModule} from '@angular/material/icon';
import {MatDividerModule} from '@angular/material/divider';
import {FlexLayoutModule} from '@angular/flex-layout';
import { MatButtonModule } from '@angular/material/button';


@NgModule({
  declarations: [AALAnalyticsPanelComponent, AALAnalyticsCardComponent],
  imports: [
    CommonModule,
    AALCommonComponentsModule,
    MatTooltipModule,
    MatCheckboxModule,
    MatButtonModule,
    MatIconModule,
    MatDividerModule,
    FlexLayoutModule
  ],
  exports: [
    AALAnalyticsPanelComponent
  ]
})
export class AALAnalyticsPanelModule {
}
