import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { AALAnalyticsPanelComponent } from './analytics-panel.component';

describe('AALAnalyticsPanelComponent', () => {
  let component: AALAnalyticsPanelComponent;
  let fixture: ComponentFixture<AALAnalyticsPanelComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ AALAnalyticsPanelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALAnalyticsPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should emit event when panel is selected', () => {
    component.panelData = [{checked: false}, {checked: false}];
    spyOn(component.cardsSelected, 'emit');
    component.onStatusCardSelection({checked: false});
    expect(component.cardsSelected.emit).toHaveBeenCalled();
  });

  it('should emit checked events when panel is selected', () => {
    component.mode = 'multiple';
    component.panelData = [{checked: true}, {checked: false}];
    spyOn(component.cardsSelected, 'emit');
    component.onStatusCardSelection({checked: true});
    expect(component.cardsSelected.emit).toHaveBeenCalledWith([{checked: true}]);
  });

  it('should emit empty string when panel is deselected', () => {
    component.panelData = [{checked: true}, {checked: false}];
    spyOn(component.cardsSelected, 'emit');
    component.onStatusCardSelection({checked: true});
    expect(component.cardsSelected.emit).toHaveBeenCalledWith('');
  });

});
