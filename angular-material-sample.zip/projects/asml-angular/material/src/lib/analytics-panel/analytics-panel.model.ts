
export interface NotificationAnalyticsData {
  notificationType: string;
  notificationCount: number;
  notificationTypeLabel: string;
  obsoletedCaseObjectsCount?: number;
  checked?: boolean;
  additionalData?: any;
  cardStyleClassName?: string;
  icon?: string;
}
