export interface PanelDataModel<T> {
  notificationType: string;
  notificationCount: number;
  notificationTypeLabel: string;
  cardStyleClassName: string;
  icon: string;
  additionalData: T;
}
