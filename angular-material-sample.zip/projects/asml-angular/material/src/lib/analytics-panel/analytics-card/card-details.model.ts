export interface CardDetailsModel {
  checked?: boolean;
  cardStyleClassName?: string;
  cardLabelKey?: string;
  icon?: string;
  svgIcon?: string;
  cardCountKey?: number;
}

