import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import {AALAnalyticsCardComponent} from './analytics-card.component';
import {SharedMaterialModule} from '../../shared/shared-material.module';


describe('AnalyticsCardComponent', () => {
  let component: AALAnalyticsCardComponent;
  let fixture: ComponentFixture<AALAnalyticsCardComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [SharedMaterialModule],
      declarations: [ AALAnalyticsCardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALAnalyticsCardComponent);
    component = fixture.componentInstance;
    component.cardDetail = {
      notificationType: 'ACTION',
      notificationCount : 0,
      notificationTypeLabel : 'Actions',
      checked: true
    };
    component.cardCountKey = 'notificationCount';
    component.cardLabelKey = 'notificationTypeLabel';
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should emit event when card is selected', () => {
    spyOn(component.cardChecked, 'emit');
    component.checked();
    expect(component.cardChecked.emit).toHaveBeenCalled();
  });
});
