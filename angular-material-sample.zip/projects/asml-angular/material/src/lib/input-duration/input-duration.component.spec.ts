import {ComponentFixture, TestBed, waitForAsync} from '@angular/core/testing';
import {CommonModule} from '@angular/common';
import {AALCommonComponentsModule, DurationTypes, Info} from '@asml-angular/common';
import {UntypedFormControl, Validators} from '@angular/forms';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';

import {SharedMaterialModule} from '../shared/shared-material.module';
import {SharedFormModule} from '../shared/shared-form.module';
import {AALOverlayCardHelpModule} from '../overlay-card-help/overlay-card-help.module';
import {AALOverlayCardErrorModule} from '../overlay-card-alert/overlay-card-alert.module';
import {AALToolbarConfirmModule} from '../toolbar-confirm/toolbar-confirm.module';
import {SharedFlexLayoutModule} from '../shared/shared-flex-layout.module';
import {AALInputDurationComponent} from './input-duration.component';

describe('AALInputDurationComponent', () => {
  let component: AALInputDurationComponent;
  let fixture: ComponentFixture<AALInputDurationComponent>;
  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [AALInputDurationComponent],
      imports: [CommonModule,
        SharedMaterialModule,
        SharedFormModule,
        AALCommonComponentsModule,
        AALOverlayCardHelpModule,
        AALOverlayCardErrorModule,
        AALToolbarConfirmModule,
        SharedFlexLayoutModule,
        BrowserAnimationsModule]
    })
      .compileComponents().then(() => {
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALInputDurationComponent);
    component = fixture.componentInstance;
    component.control = new UntypedFormControl('');
    component.type = 'default';
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set the default value to control if control has no value', () => {
    component.ngOnInit();
    expect(component.control.value).toBe('');
  });

  it('should set oldValue, newValue as null, when control is set with null value', () => {
    component.control = new UntypedFormControl(null);
    component.ngOnInit();
    expect(component.oldValue).toBe(null);
  });

  it('should set default value for pattern if null', () => {
    component.pattern = null;
    component.ngOnInit();
    expect(component.pattern).toBeTruthy();
  });

  it('should set appropriate value for pattern, when type is period', () => {
    component.pattern = null;
    component.type = DurationTypes.Period;
    component.ngOnInit();
    expect(component.pattern).toBeTruthy();
  });

  it('should set appropriate value for pattern, when type is duration', () => {
    component.pattern = null;
    component.type = DurationTypes.Duration;
    component.ngOnInit();
    expect(component.pattern).toBeTruthy();
  });

  it('should set hint text for inappropriate Pattern, when type is period', () => {
    component.pattern = null;
    component.type = DurationTypes.Period;
    component.formatStringHint = '';
    component.ngOnInit();
    expect(component.formatStringHint).toEqual('Use Format: 2y2mo2d Or 2yr2mo2d or 2y 2mo 2d');
  });

  it('should set hint text for inappropriate Pattern, when type is duration', () => {
    component.pattern = null;
    component.type = DurationTypes.Duration;
    component.formatStringHint = '';
    component.ngOnInit();
    expect(component.formatStringHint).toEqual('Use Format: 2d2h2m Or 2d 2h 2m');
  });

  it('should set default value for Patten formatted String if null', () => {
    component.ngOnInit();
    expect(component.formatStringHint).toBe('Use Format: 2y2mo2d2h2m Or 2yr2mo2d2hr2m Or 2y 2mo 2d 2h 2m');
  });

  it('should reject the changes on click of reject', () => {
    component.control.setValue('10:10');
    component.triggerRejectChanges();
    expect(component.control.value).toBe('');
  });

  it('should accept the value on blur', () => {
    component.control.setValue('10:10');
    component.onBlur(new Event('blur'));
    fixture.detectChanges();
    expect(component.control.value).toBe('10h 10m');
  });

  it('should accept the hours and minutes value on blur', () => {
    component.control.setValue('10h10m');
    component.onBlur(new Event('blur'));
    fixture.detectChanges();
    expect(component.control.value).toBe('10h 10m');
  });

  it('should accept the hours and minutes value on blur', () => {
    component.control.setValue('10:10');
    component.onBlur(new Event('blur'));
    fixture.detectChanges();
    expect(component.control.value).toBe('10h 10m');
  });

  it('should return nothing when value is set from history ', () => {
    component.control = new UntypedFormControl('10h', Validators.required);
    const matOption = document.createElement('mat-option');
    matOption.classList.add('mat-select');
    const event = new FocusEvent('focus', {relatedTarget: matOption});
    const returnValue = component.onBlur(event);
    expect(returnValue).toBe(undefined);
  });

  it('it should accept the changes for revertChanges', () => {
    spyOn(component, 'revertChanges');
    component.durationToRevert = '2h';
    component.alert = new Info('Sample Title', 'Sample Help Message', '', '', null);
    fixture.detectChanges();
    expect(component.revertChanges).toHaveBeenCalled();
  });

  it('should set the validation error', () => {
    component.control = new UntypedFormControl('', [Validators.required]);
    component.control.setValue(' ');
    expect(component.getValidatorMessage('PATTERN')).toContain('Use Format: 2y2mo2d2h2m Or 2yr2mo2d2hr2m Or 2y 2mo 2d 2h 2m');
  });

  it('should set error message and revert the changes', () => {
    component.control = new UntypedFormControl('', [Validators.required]);
    component.control.setValue(' ');
    expect(component.getValidatorMessage('PATTERN')).toContain('Use Format: 2y2mo2d2h2m Or 2yr2mo2d2hr2m Or 2y 2mo 2d 2h 2m');
  });

  it('should set error message and revert the changes', () => {
    component.control = new UntypedFormControl('', [Validators.required]);
    component.control.setValue(' ');
    expect(component.getValidatorMessage('PATTERN')).toContain('Use Format: 2y2mo2d2h2m Or 2yr2mo2d2hr2m Or 2y 2mo 2d 2h 2m');
  });

  it('should set the validation error', () => {
    component.control = new UntypedFormControl('', [Validators.required]);
    component.control.setValue('');
    expect(component.getValidatorMessage('required')).toContain('Failed validation: required');
  });

  it('should accept the changes for revertchanges', () => {
    component.durationToRevert = '2h';
    component.revertChanges();
    expect(component.oldValue).toBe('2h');
  });

  it('should set the control value in hour format', () => {
    component.control.setValue('0');
    component.triggerAcceptChanges();
    expect(component.control.value).toBe('0h');
  });

  it('it should accept the changes for revertChanges', () => {
    component.pattern = /^\d(\d*)((y|Y|yr|YR)?)\s*(\d*)((mo|MO)?)\s*(\d*)([dD]?)\s*(\d*)((h|H|hr|HR)?)\s*(\d*)([mM]?)(?![0-9])$|^\d(\d*):([0-5][0-9]$)/;
    spyOn(component, 'revertChanges');
    component.durationToRevert = '2yr 2mo 2d';
    component.alert = new Info('Sample Title', 'Sample Help Message', '', '', null);
    fixture.detectChanges();
    expect(component.revertChanges).toHaveBeenCalled();
  });

  it('should return duration format value when the value is 0', () => {
    component.control = new UntypedFormControl('PT0M');
    component.type = DurationTypes.Duration;
    expect(component.control.value).toBe('0h');
  });

  it('should set control value in dhm format', () => {
    component.type = DurationTypes.Duration;
    component.control = new UntypedFormControl('PT1H30M');
    expect(component.control.value).toBe('1h 30m');
    component.control = new UntypedFormControl('PT10H');
    expect(component.control.value).toBe('10h');
    component.control = new UntypedFormControl('PT10M');
    expect(component.control.value).toBe('10m');
  });

  it('should set old value in PT format, when duration format is duration', () => {
    component.type = DurationTypes.Duration;
    component.control = new UntypedFormControl('1h 20m');
    expect(component.oldValue).toBe('P0DT1H20M');
  });

  it('should set old value in PT format, when duration format is period', () => {
    component.type = DurationTypes.Period;
    component.control = new UntypedFormControl('1yr 6mo');
    expect(component.oldValue).toBe('P1Y6M0D');
  });

  it('should set correct control value when durationformat is yr-when value has year and month', () => {
    component.type = DurationTypes.Period;
    component.control = new UntypedFormControl('P1Y6M');
    expect(component.control.value).toBe('1yr 6mo');
  });

  it('should set correct control value when durationformat is yr- when value has year, month and days', () => {
    component.type = DurationTypes.Period;
    component.control = new UntypedFormControl('P1Y6M5D');
    expect(component.control.value).toBe('1yr 6mo 5d');
  });

  it('should set correct control value when durationformat is yr- when value only year', () => {
    component.type = DurationTypes.Period;
    component.control = new UntypedFormControl('P1Y');
    expect(component.control.value).toBe('1yr');
  });

  it('should set correct control value when durationformat is yr- when value only month', () => {
    component.type = DurationTypes.Period;
    component.control = new UntypedFormControl('P6M');
    expect(component.control.value).toBe('6mo');
  });

  it('should set correct control value when durationformat is yr- when value only days', () => {
    component.type = DurationTypes.Period;
    component.control = new UntypedFormControl('P10D');
    expect(component.control.value).toBe('10d');
  });

  it('should set correct control value when durationformat is yr- when value months and days', () => {
    component.type = DurationTypes.Period;
    component.control = new UntypedFormControl('P1M6D');
    expect(component.control.value).toBe('1mo 6d');
  });

  it('should set correct control value when durationformat is yr- when value years and days', () => {
    component.type = DurationTypes.Period;
    component.control = new UntypedFormControl('P1Y6D');
    expect(component.control.value).toBe('1yr 6d');
  });

  it('should set correct control value when durationformat is yr- when no value passed', () => {
    component.type = DurationTypes.Period;
    component.control = new UntypedFormControl('');
    expect(component.control.value).toBe('');
  });

  it('should transform the values correctly when values is entered in hh:mm format', () => {
    component.type = DurationTypes.Duration;
    component.control.setValue('12:30');
    component.triggerAcceptChanges();
    expect(component.control.value).toBe('12h 30m');
  });
});
