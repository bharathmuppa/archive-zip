import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NavigationConfirmationDialogComponent } from './navigation-confirmation-dialog.component';
import {RouterModule} from "@angular/router";
import {BrowserModule} from "@angular/platform-browser";
import {CUSTOM_ELEMENTS_SCHEMA} from "@angular/core";
import {MAT_DIALOG_DATA, MatDialogRef} from "@angular/material/dialog";

describe('NavigationConfirmationDialogComponent', () => {
  let component: NavigationConfirmationDialogComponent;
  let fixture: ComponentFixture<NavigationConfirmationDialogComponent>;
  const dialogMock = {
    close: () => {
    }
  };
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      imports: [BrowserModule, RouterModule],
      declarations: [NavigationConfirmationDialogComponent],
      providers: [
        {provide: MatDialogRef, useValue: dialogMock},
        {provide: MAT_DIALOG_DATA, useValue: {}}
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NavigationConfirmationDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set message on initialization', () => {
    component.data = {message: 'test message', isCaseObject: 'test Data'};
    component.ngOnInit();
    expect(component.message).toBe('test message');
  });

  it('dialog should close onYesClick triggered', () => {
    spyOn(component.dialogRef, 'close');
    component.onYesClick();
    expect(component.dialogRef.close).toHaveBeenCalled();
  });

  it('dialog should close onNoClick triggered', () => {
    spyOn(component.dialogRef, 'close');
    component.onNoClick();
    expect(component.dialogRef.close).toHaveBeenCalled();
  });
});
