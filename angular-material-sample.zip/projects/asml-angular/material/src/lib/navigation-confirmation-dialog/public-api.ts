/*
 * Public API Surface of material
 */

export * from './navigation-confirmation-dialog.component';
export * from './navigation-confirmation-dialog.module';
