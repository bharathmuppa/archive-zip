import {NgModule} from "@angular/core";
import {CommonModule} from "@angular/common";
import {NavigationConfirmationDialogComponent} from "./navigation-confirmation-dialog.component";
import {AALButtonOutlinedModule} from "../button-outlined/button-outlined.module";
import {AALButtonContainedModule} from "../button-contained/button-contained.module";
import {MatIconModule} from '@angular/material/icon';
import {MatDialogModule} from '@angular/material/dialog';
import {FlexLayoutModule} from '@angular/flex-layout';

@NgModule({
    imports: [
        CommonModule,
        AALButtonOutlinedModule,
        AALButtonContainedModule,
        MatIconModule,
        MatDialogModule,
        FlexLayoutModule
    ],
    declarations: [
        NavigationConfirmationDialogComponent
    ],
    exports: [
        NavigationConfirmationDialogComponent
    ]
})
export class AALNavigationConfirmationDialogModule {

}
