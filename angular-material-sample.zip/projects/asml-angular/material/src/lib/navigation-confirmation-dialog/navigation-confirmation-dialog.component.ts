import {Component, Inject, OnInit} from '@angular/core';
import {MatDialogRef, MAT_DIALOG_DATA} from "@angular/material/dialog";

@Component({
  selector: 'aal-navigation-confirmation-dialog',
  templateUrl: './navigation-confirmation-dialog.component.html',
  styleUrls: ['./navigation-confirmation-dialog.component.scss']
})
export class NavigationConfirmationDialogComponent implements OnInit {
  isCaseObject: boolean;
  message: string;
  isFooterButtonsNotRequired: boolean;
  buttonLabel: string;
  headerTitle: string;

  constructor(public dialogRef: MatDialogRef<NavigationConfirmationDialogComponent>,
              @Inject(MAT_DIALOG_DATA) public data: any) {
  }

  ngOnInit() {
    this.isCaseObject = this.data.isCaseObject;
    this.message = this.data.message;
    this.buttonLabel = (this.data.buttonLabel) ? this.data.buttonLabel : 'ok';
    this.headerTitle = (this.data.headerTitle) ? this.data.headerTitle : 'Alert';
    this.isFooterButtonsNotRequired = this.data && this.data.isFooterButtonsNotRequired ? this.data.isFooterButtonsNotRequired : false;
  }

  onYesClick() {
    this.dialogRef.close(true);
  }

  onNoClick() {
    this.dialogRef.close(false);
  }

}
