/*
 * Public API Surface of material
 */

export * from './input-text.component';
export * from './input-text.module';
