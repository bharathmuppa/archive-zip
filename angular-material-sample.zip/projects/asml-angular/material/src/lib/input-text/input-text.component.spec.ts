import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import {CommonModule} from '@angular/common';
import {UntypedFormControl, Validators} from '@angular/forms';
import {AALCommonComponentsModule, AALInputFormControlComponent} from '@asml-angular/common';

import {SharedMaterialModule} from '../shared/shared-material.module';
import {SharedFormModule} from '../shared/shared-form.module';
import {AALInputTextComponent} from './input-text.component';
import createSpyObj = jasmine.createSpyObj;

describe('AALInputTextComponent', () => {
  let component: AALInputTextComponent;
  let fixture: ComponentFixture<AALInputTextComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [AALInputTextComponent],
      imports: [CommonModule,
        SharedMaterialModule,
        SharedFormModule,
        AALCommonComponentsModule]
    }).compileComponents().then(() => {
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALInputTextComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    component.control = new UntypedFormControl('actualVal', Validators.compose([Validators.maxLength(50), Validators.minLength(5)]));
    component.showLengthHint = true;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should emit press Accept Event on Trigger Accept Changes', () => {
    spyOn(component.pressAcceptEvent, 'emit');
    component.triggerAcceptChanges();
    expect(component.pressAcceptEvent.emit).toHaveBeenCalled();
  });

  it('should call focus event on blur', () => {
    spyOn(AALInputFormControlComponent.prototype, 'onBlur');
    component.control.setValue('Sample text');
    const event = new MouseEvent('focus');
    spyOn(event, 'preventDefault');
    component.onBlur(event);
    expect(AALInputFormControlComponent.prototype.onBlur).toHaveBeenCalled();
  });

  it('should call onCLick function without selection data', () => {
    spyOn(AALInputFormControlComponent.prototype, 'onClick');
    const rangeObject = {
      toString() {
        return '';
      }
    } as Selection;
    spyOn(window, 'getSelection').and.returnValue(rangeObject);
    component.onClick();
    expect(AALInputFormControlComponent.prototype.onClick).toHaveBeenCalled();
  });

  it('should get the max length validation message', () => {
    component.placeholder = 'Text';
    component.control.setValue('Sample text to test the max length of the input field');
    const validatorMessage = component.getValidatorMessage('maxlength');
    expect(validatorMessage).toBe('Text should be less than or equal to 50 characters, actual length is 53 characters.');
  });

  it('should get the min length validation message', () => {
    component.placeholder = 'Text';
    component.control.setValue('Test');
    const validatorMessage = component.getValidatorMessage('minlength');
    expect(validatorMessage).toBe('Text should be more than or equal to 5 characters, actual length is 4 characters.');
  });

  it('should be able to get default validation messages', () => {
    spyOn(AALInputFormControlComponent.prototype, 'getValidatorMessage').and.returnValue('Sample');
    const validatorMessage = component.getValidatorMessage('');
    expect(validatorMessage).toContain('Sample');
  });

  it('should return nothing when value is set from history ', () => {
    component.control = new UntypedFormControl('sample data', Validators.required);
    const matOption = document.createElement('mat-option');
    matOption.classList.add('mat-select');
    const event = new FocusEvent('focus', {relatedTarget: matOption});
    const returnValue = component.onBlur(event);
    expect(returnValue).toBe(undefined);
  });

  it('should emit the values triggerRejectChanges', () => {
    spyOn(component.pressRejectEvent, 'emit');
    component.triggerRejectChanges();
    expect(component.pressRejectEvent.emit).toHaveBeenCalled();
  });

  it('should emit keyboard event', () => {
    spyOn(component.keyDown, 'emit');
    const $event = new Event('keyup') as KeyboardEvent;
    component.onKeyUp($event);
    expect(component.keyDown.emit).toHaveBeenCalled();
  });

  it('should call setFocusInInput of super Component', () => {
    spyOn(AALInputFormControlComponent.prototype, 'onClick');
    component.setFocusInInput();
    expect(AALInputFormControlComponent.prototype.onClick).toHaveBeenCalled();
  });

  it('should prevent invalid character on keydown event', () => {
    component.invalidChars = ['-'];
    const $event = new KeyboardEvent('keydown', { key: '-'}) as KeyboardEvent;
    spyOn($event, 'preventDefault');
    component.onKeyDown($event);
    expect($event.preventDefault).toHaveBeenCalled();
  });

  it('should not prevent valid character on keydown event', () => {
    const $event = new KeyboardEvent('keydown', { key: 'a'}) as KeyboardEvent;
    spyOn($event, 'preventDefault');
    component.onKeyDown($event);
    expect($event.preventDefault).not.toHaveBeenCalled();
  });

  it('should call super onBlur function when disableAcceptChangesOnBlur is set to false', () => {
    spyOn(AALInputFormControlComponent.prototype, 'onBlur');
    component.control = new UntypedFormControl('', Validators.required);
    component.disableAcceptChangesOnBlur = false;
    const event = createSpyObj('relatedTarget', ['']);
    component.onBlur(new Event(event));
    expect(AALInputFormControlComponent.prototype.onBlur).toHaveBeenCalled();
  });

  it('should be able to get custom validation messages when getValidatorMessage is triggered', () => {
    component.customValidationMessage = 'In-Valid text enter'
    const validatorMessage = component.getValidatorMessage('PATTERN');
    expect(validatorMessage).toBe('In-Valid text enter');
  });

  it('should be able to get validation messages from super class', () => {
    spyOn(AALInputFormControlComponent.prototype, 'getValidatorMessage').and.returnValue('Sample');
    const validatorMessage = component.getValidatorMessage('');
    expect(validatorMessage).toContain('Sample');
  });
});
