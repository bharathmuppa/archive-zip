import {Component, EventEmitter, Input, Output} from '@angular/core';
import {AALInputFormControlComponent, HistoryService} from '@asml-angular/common';
import {CommonMaterialComponentErrorStateMatcher} from '../shared/common-material-component.error-state-matcher';


@Component({
  selector: 'aal-input-text',
  templateUrl: './input-text.component.html',
  styleUrls: ['./input-text.component.scss']
})
export class AALInputTextComponent extends AALInputFormControlComponent {
  @Input()
  invalidChars: string[];
  @Input()
  hideError: boolean;
  @Input()
  floatLabel: boolean;
  @Input()
  disableAcceptChangesOnBlur: boolean;
  @Input()
  customValidationMessage: string;
  @Output()
  keyDown: EventEmitter<KeyboardEvent> = new EventEmitter();
  @Output()
  pressRejectEvent: EventEmitter<void> = new EventEmitter();
  @Output()
  pressAcceptEvent: EventEmitter<void> = new EventEmitter();
  errorStateMatcher = new CommonMaterialComponentErrorStateMatcher();

  constructor(historyService: HistoryService) {
    super(historyService);
    this.showLengthHint = (this.showLengthHint === null || this.showLengthHint === undefined) ?
      true : this.showLengthHint;
  }

  getValidatorMessage(validatorKey: string): string {
    if(this.customValidationMessage) {
      return this.customValidationMessage;
    } else {
      return super.getValidatorMessage(validatorKey);
    }
  }

  onBlur($event?: Event) {
    /* For composite controls, when any value is selected, the focus shits to the input element. Here we are writing conditions for the scenarios when the blur event of the input control must not be called. Add the class 'skip-input-blur-event' to achieve this */
    if ($event instanceof FocusEvent && $event.relatedTarget
      && ($event.relatedTarget['classList'].contains('mat-select') || $event.relatedTarget['id'].includes(this.hyphenatedID) ||
        $event.relatedTarget['parentElement'].classList.contains('skip-input-blur-event'))) {
      // do nothing
      return;
    }
    this.sanitizeControlValue();
    const isAcceptChangesNotNeeded = !this.confirmToolBarNotApplicable && this.disableAcceptChangesOnBlur;
    if(!isAcceptChangesNotNeeded){
      super.onBlur($event);
    }
  }


  triggerAcceptChanges() {
    this.sanitizeControlValue();
    super.triggerAcceptChanges();
    this.pressAcceptEvent.emit();
  }


  onClick() {
    const selection = window.getSelection();
    if (selection.toString().length === 0) {
      super.onClick();
    }
  }

  setFocusInInput() {
    super.onClick();
  }

  triggerRejectChanges() {
    super.triggerRejectChanges();
    this.pressRejectEvent.emit();
  }

  private sanitizeControlValue() {
// Remove spaces, Split with delimiters and filter unwanted format
    const temp = (this.control && this.control.value) ? this.control.value : '';
    this.control.setValue(temp.replace(/^[ ]+|[ ]+$/g, ''));
  }


  onKeyUp(event: KeyboardEvent): void {
    this.keyDown.emit(event);
    super.onKeyUp(event);
  }

  onKeyDown(event: KeyboardEvent): void {
    if (this.invalidChars && this.invalidChars.length && this.invalidChars.includes(event.key)) {
      event.preventDefault();
    }
  }
}

