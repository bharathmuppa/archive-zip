export class EndDateForm {
  [key: string]: EndDates;
}

export class EndDates {
  name: string;
  date: Date;
}
