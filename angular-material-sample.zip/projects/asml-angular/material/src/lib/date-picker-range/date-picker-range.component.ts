import {Component, OnInit, Renderer2} from '@angular/core';
import {AALUtil, HistoryService} from '@asml-angular/common';
import {AALDatePickerWeekComponent} from '../date-picker-week/date-picker-week.component';

@Component({
  selector: 'aal-date-picker-range',
  templateUrl: './date-picker-range.component.html',
  styleUrls: ['./date-picker-range.component.scss']
})
export class AALDatePickerRangeComponent extends AALDatePickerWeekComponent implements OnInit {
  beginDate: Date;
  constructor(renderer: Renderer2, historyService: HistoryService) {
    super(renderer, historyService);
    this.listValueSelected = false;
  }

  ngOnInit() {
    if (this.control && this.control.value) {
      this.datePickerSelection = this.selectedValue = AALUtil.setDateDefaultTime(this.control.value);
    }
    super.ngOnInit();
  }

  onChange($event?: Event) {
    if (this.control.value) {
      const isoDateObject = {
        begin: AALUtil.getDateInISOFormat(this.control.value.begin),
        end: AALUtil.getDateInISOFormat(this.control.value.end)
      };
      this.control.setValue(isoDateObject);
    }
    super.onChange($event);
  }

  changeDateFormat(event, dateType) {
    if (event.value) {
      if (!(event.value.begin)) {
        if (dateType === 'start') {
          this.beginDate = event.value;
        } else if (dateType === 'end') {
          this.control.patchValue({
            begin: this.beginDate,
            end: event.value
          });
        } else {
          this.control.setValue({
            begin: this.isPastDateRange ? event.value : this.today,
            end: this.isPastDateRange ? this.today : event.value
          });
          this.datePickerSelection = this.control.value;
        }
      } else {
        this.datePickerSelection = this.control.value;
      }
    } else {
      this.control.setValue('');
    }
  }

  onClick(): void {
    super.setModeToEdit();
    setTimeout(() => {
      if (this.selectField && this.selectField.trigger) {
        this.selectField.trigger.nativeElement.click();
      }
    }, 100);
  }
}
