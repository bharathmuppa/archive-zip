import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {AALCommonComponentsModule, AALCommonModule} from '@asml-angular/common';
import {MatDatepickerModule} from '@angular/material/datepicker';
import {AALDatePickerRangeComponent} from './date-picker-range.component';
import {AALDatePickerWeekModule} from '../date-picker-week/date-picker-week.module';
import {FlexLayoutModule} from '@angular/flex-layout';
import {AALOverlayCardHelpModule} from '../overlay-card-help/overlay-card-help.module';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import {MatInputModule} from '@angular/material/input';
import {MatTooltipModule} from '@angular/material/tooltip';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {AALOverlayCardErrorModule} from '../overlay-card-alert/overlay-card-alert.module';
import {MatSelectModule} from '@angular/material/select';

@NgModule({
  declarations: [AALDatePickerRangeComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    AALCommonModule,
    AALCommonComponentsModule,
    MatDatepickerModule,
    MatInputModule,
    MatProgressSpinnerModule,
    MatSelectModule,
    MatTooltipModule,
    AALDatePickerWeekModule,
    AALOverlayCardHelpModule,
    AALOverlayCardErrorModule,
    FlexLayoutModule
  ],
  exports: [AALDatePickerRangeComponent]
})
export class AALDatePickerRangeModule {
}
