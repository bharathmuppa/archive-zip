import {
  ChangeDetectorRef,
  Component,
  ElementRef,
  EventEmitter, Input,
  OnInit,
  Output,
  ViewChild
} from '@angular/core';
import {AALInputFormControlComponent, HistoryService, Modes} from '@asml-angular/common';
import {CommonMaterialComponentErrorStateMatcher} from '../shared/common-material-component.error-state-matcher';

@Component({
  selector: 'aal-input-text-area',
  templateUrl: './input-text-area.component.html',
  styleUrls: ['./input-text-area.component.scss']
})
export class AALInputTextAreaComponent extends AALInputFormControlComponent implements OnInit {
  showMore: boolean;
  errorStateMatcher = new CommonMaterialComponentErrorStateMatcher();
  readonly initialMinRows = 2;
  minRows = this.initialMinRows;
  @Input()
  compositePlaceholder?: string; // Used for composite controls
  @Output()
  pressAcceptEvent: EventEmitter<void> = new EventEmitter();
  @Output()
  pressRejectEvent: EventEmitter<void> = new EventEmitter();


  @ViewChild('readModeDiv', {static: false}) readModeDivision: ElementRef;
  @Input() alwaysEditMode: boolean;

  // differ: KeyValueDiffer<string, any>;

  constructor(historyService: HistoryService, private readonly ref: ChangeDetectorRef) {
    super(historyService);
  }

  ngOnInit() {
    this.mode$.subscribe(mode => {
      if (mode === Modes.READ) {
        this.ref.detectChanges();
      }
    });
    super.ngOnInit();
  }

  onKeyUp(event: KeyboardEvent) {
    if (event.key === 'Escape') {
      this.triggerRejectChanges();
    }
  }

  onBlur($event?: Event) {
    /* For composite controls, when any value is selected, the focus shits to the input element.
    Here we are writing conditions for the scenarios when the blur event of the input control must not be called.
     Add the class 'skip-input-blur-event' to achieve this */
    if ($event instanceof FocusEvent && $event.relatedTarget
      && ($event.relatedTarget['classList'].contains('mat-select') || $event.relatedTarget['classList'].contains('mat-radio-group') || $event.relatedTarget['id'].includes(this.hyphenatedID) ||
        $event.relatedTarget['parentElement'].classList.contains('skip-input-blur-event'))) {
      // do nothing
      return;
    }
    this.showMore = false;
    super.onBlur($event);
  }

  triggerAcceptChanges() {
    this.showMore = false;
    super.triggerAcceptChanges();
    this.pressAcceptEvent.emit();
  }

  toggleShowMoreContent($event: Event) {
    this.showMore = !this.showMore;
    $event.stopPropagation();
  }

  onClick(event?) {
    const selection = window.getSelection();
    if (selection.toString().length === 0) {
      super.onClick();
    }
  }

  setFocusInInput() {
    super.onClick();
  }

  triggerRejectChanges() {
    super.triggerRejectChanges();
    this.pressRejectEvent.emit();
  }

  stopBlur () {
    return;
  }
}
