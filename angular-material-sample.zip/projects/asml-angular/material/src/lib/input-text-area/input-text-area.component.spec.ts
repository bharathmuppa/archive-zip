import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import {CommonModule} from '@angular/common';
import {UntypedFormControl, Validators} from '@angular/forms';
import {AALCommonComponentsModule, AALInputFormControlComponent} from '@asml-angular/common';

import {SharedMaterialModule} from '../shared/shared-material.module';
import {SharedFormModule} from '../shared/shared-form.module';
import {AALOverlayCardHelpModule} from '../overlay-card-help/overlay-card-help.module';
import {AALOverlayCardErrorModule} from '../overlay-card-alert/overlay-card-alert.module';
import {AALToolbarConfirmModule} from '../toolbar-confirm/toolbar-confirm.module';
import {SharedFlexLayoutModule} from '../shared/shared-flex-layout.module';
import {AALInputTextAreaComponent} from './input-text-area.component';

describe('AALInputTextAreaComponent', () => {
  let component: AALInputTextAreaComponent;
  let fixture: ComponentFixture<AALInputTextAreaComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [AALInputTextAreaComponent],
      imports: [
        CommonModule,
        SharedMaterialModule,
        SharedFormModule,
        AALCommonComponentsModule,
        AALOverlayCardHelpModule,
        AALOverlayCardErrorModule,
        AALToolbarConfirmModule,
        SharedFlexLayoutModule
      ]
    }).compileComponents().then(() => {
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALInputTextAreaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should emit keyboard event', () => {
    spyOn(component, 'triggerRejectChanges');
    const event = new KeyboardEvent('keyup', {
      key: 'Escape'
    });
    component.onKeyUp(event);
    expect(component.triggerRejectChanges).toHaveBeenCalled();
  });

  it('should emit the values triggerRejectChanges', () => {
    spyOn(component.pressRejectEvent, 'emit');
    component.triggerRejectChanges();
    expect(component.pressRejectEvent.emit).toHaveBeenCalled();
  });

  it('should call supper method onClick when setFocusInInput trigger', () => {
    spyOn(AALInputFormControlComponent.prototype, 'onClick');
    component.setFocusInInput();
    expect(AALInputFormControlComponent.prototype.onClick).toHaveBeenCalled();
  });

  it('should return nothing when value is set from history ', () => {
    component.control = new UntypedFormControl('sample data', Validators.required);
    const matOption = document.createElement('mat-option');
    matOption.classList.add('mat-select');
    const event = new FocusEvent('focus', {relatedTarget: matOption});
    const returnValue = component.onBlur(event);
    expect(returnValue).toBe(undefined);
  });

  it('should call focus event on blur', () => {
    component.control = new UntypedFormControl('', Validators.required);
    spyOn(component, 'onBlur').and.callThrough();
    const $event = new MouseEvent('focus');
    component.onBlur($event);
    expect(component.onBlur).toHaveBeenCalled();
  });

  it('should call triggerAcceptChanges of super Component', () => {
    component.control = new UntypedFormControl('', Validators.required);
    spyOn(AALInputFormControlComponent.prototype, 'triggerAcceptChanges');
    component.control.setValue('1234');
    component.triggerAcceptChanges();
    expect(AALInputFormControlComponent.prototype.triggerAcceptChanges).toHaveBeenCalled();
  });

  it('Should set show more property to true when it is false', () => {
    component.control = new UntypedFormControl('', Validators.required);
    const $event = new  Event('click');
    component.showMore = false;
    component.toggleShowMoreContent($event);
    expect(component.showMore).toBe(true);
  });

  it('should call onClick of super Component', () => {
    spyOn(AALInputFormControlComponent.prototype, 'onClick');
    component.control = new UntypedFormControl('', Validators.required);
    spyOn(component, 'onClick').and.callThrough();
    const $event = new  Event('click');
    component.onClick($event);
    expect(AALInputFormControlComponent.prototype.onClick).toHaveBeenCalled();
  });

  it('should call stopBlur on blur when alwaysEditMode is set as true', () => {
    component.alwaysEditMode = true;
    component.control = new UntypedFormControl('', Validators.required);
    spyOn(component, 'stopBlur').and.callThrough();
    component.stopBlur();
    expect(component.stopBlur).toHaveBeenCalled();
  });
});
