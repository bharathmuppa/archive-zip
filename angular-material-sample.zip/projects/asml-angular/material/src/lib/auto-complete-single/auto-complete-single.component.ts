import {
  Component,
  EventEmitter,
  Input,
  Output,
  TemplateRef,
  ViewChild
} from '@angular/core';
import {
  CommonMaterialComponentErrorStateMatcher
} from '../shared/common-material-component.error-state-matcher';
import {UntypedFormControl} from '@angular/forms';
import {AALAutoCompleteFormControlComponent} from '@asml-angular/common';
import {MatAutocomplete, MatAutocompleteTrigger} from '@angular/material/autocomplete';

/**
 * Req 1:  it should hold one value
 * Req 2:  if I select a new option (Which has a previous value) and then click on clear icon ->
 */

@Component({
  selector: 'aal-auto-complete-single',
  templateUrl: './auto-complete-single.component.html',
  styleUrls: ['./auto-complete-single.component.scss']
})
export class AALAutoCompleteSingleComponent extends AALAutoCompleteFormControlComponent {
  errorStateMatcher = new CommonMaterialComponentErrorStateMatcher();
  oldValueUpdated: boolean;
  @ViewChild('resultAutoComplete', {static: false}) matAutoComplete: MatAutocomplete;
  @ViewChild('inputField', {read: MatAutocompleteTrigger}) autoTrigger: MatAutocompleteTrigger;
  @Input()
  hideDataLoadingIndicator: boolean;
  @Input()
  inputPrefix: string;
  @Input()
  disablePrefix: boolean;
  @Input()
  hint: string;
  @Input()
  floatLabel: string;
  @Input()
  defaultUsersList: any[];
  @Input()
  disableClearIcon: boolean;
  @Input()
  hideClearIcon: boolean = false;
  @Output()
  onFocus = new EventEmitter<any>();
  @Output()
  onBlur = new EventEmitter<any>();
  @Output()
  optionsPanelClosed = new EventEmitter<any>();
  @Input()
  highlightOption: boolean;
  @Input()
  itemTemplateRef: TemplateRef<any>;
  @Input()
  filteredList$: any;
  @Input()
  itemClassifierField: string;
  @Input()
  autoActiveFirstOption: boolean;

  @Input()
  set control(ctrl: UntypedFormControl) {
    this.frmControl = ctrl;
    if (ctrl && ctrl.value !== undefined) {
      this.oldValue = (typeof ctrl.value === 'object' ? JSON.parse(JSON.stringify(ctrl.value)) : ctrl.value);
      this.setInputValue(ctrl.value);
    }
    this.frmControl.valueChanges.subscribe(val => {
      if (!this.oldValueUpdated && typeof val === 'object' && this.oldValue && typeof this.oldValue === 'string') {
        this.oldValue = (typeof val === 'object' ? JSON.parse(JSON.stringify(val)) : val);
        this.oldValueUpdated = !this.oldValueUpdated;
      }
      this.setInputValue(val);
    });
  }

  get control() {
    return this.frmControl;
  }

  @Input()
  line1DisplayField: string[];

  onClick(): void {
    this.setInputValue(this.control.value);
    super.onClick();
  }

  setInputValue(val): void {
    this.inputControl.setValue(typeof val === 'object' ? JSON.parse(JSON.stringify(val)) : val);
  }

  emptyControl(): void {
    this.control.setValue('');
    this.inputControl.setValue('');
    if (this.control.valid) {
      this.triggerAcceptChanges();
    }
    this.mode = this.modes.EDIT;
  }

  onItemSelected(item): void {
    this.control.patchValue(item);
    this.triggerAcceptChanges();
  }

  onInputBlur(event: any): void {
  // TODO: Remove logic with related target as it is a work around to fix issue with reject changes and setMode function inside it
    if (event.relatedTarget && this.matAutoComplete.isOpen) {
      event.relatedTarget.click();
    } else if (event.relatedTarget && (event.relatedTarget.id === this.hyphenatedID + '_close')) {
      event.preventDefault();
    } else {
      // In lockMode EDIT only call triggerRejectChanges when the control is not valid
      if (this.lockMode === 'EDIT') {
        if (!this.control.valid) {
          // update old value with control value if the control value is changed
          // eg: in case, if there is any additional logic to set control value as object from string etc..
          if (this.control.value && typeof this.oldValue !== typeof this.control.value) {
            this.oldValue = this.control.value;
          }
          this.triggerRejectChanges();
        }
      } else {
        // update old value with control value if the control value is changed
        // eg: in case, if there is any additional logic to set control value as object from string etc..
        if (this.control.value && typeof this.oldValue !== typeof this.control.value) {
          this.oldValue = this.control.value;
        }
        this.triggerRejectChanges();
      }
    }
    this.onBlur.emit(event);
  }

  onKeyUp(event: any) {
    if (event.key === ' ' && this.autoTrigger && this.autoTrigger.activeOption) {
      this.onItemSelected(this.autoTrigger.activeOption.value);
    }
  }

  onInputFocus(event?): void {
    this.onFocus.emit(event);
  }

  onOptionsPanelClosed() {
    this.optionsPanelClosed.emit();
  }
}
