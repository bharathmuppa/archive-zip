import {ComponentFixture, TestBed, waitForAsync} from '@angular/core/testing';
import {CommonModule} from '@angular/common';
import {UntypedFormControl, Validators} from '@angular/forms';
import {Modes} from '@asml-angular/common';
import {MatOption} from '@angular/material/core';
import {MatAutocompleteTrigger} from '@angular/material/autocomplete';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';

import {SharedMaterialModule} from '../shared/shared-material.module';
import {SharedFormModule} from '../shared/shared-form.module';
import {SharedFlexLayoutModule} from '../shared/shared-flex-layout.module';
import {SharedModule} from '../shared/shared.module';
import {AALAutoCompleteSingleComponent} from './auto-complete-single.component';

describe('AALAutoCompleteSingleComponent', () => {
  let component: AALAutoCompleteSingleComponent;
  let fixture: ComponentFixture<AALAutoCompleteSingleComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ AALAutoCompleteSingleComponent ],
      imports: [CommonModule,
        SharedMaterialModule,
        SharedFormModule,
        SharedModule,
        SharedFlexLayoutModule,
        BrowserAnimationsModule]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALAutoCompleteSingleComponent);
    component = fixture.componentInstance;
    component.control = new UntypedFormControl('');
    component.itemDisplayField = 'name';
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should empty the control value', () => {
    const value = {name: 'abc', abbr: 'ab', id: 1};
    component.control.setValue(value);
    component.emptyControl();
    expect(component.control.value).toBe('');
  });

  it('should call accept changes on item select', () => {
    const value = {name: 'abc', abbr: 'ab', id: 1};
    component.control.setValue(value);
    const acceptChangesSpy = spyOn(component, 'triggerAcceptChanges').and.returnValue(null);
    component.onItemSelected({});
    expect(acceptChangesSpy).toHaveBeenCalled();
  });

  it('should call onInputBlur function if onblur is not triggered to display old values', () => {
    /*component.control.setValue('new value');
    const event = new MouseEvent('blur');
    spyOn(event, 'preventDefault');
    component.onInputBlur(event);
    fixture.detectChanges();
    expect(component.oldValue).toBe('new value');*/
  });

  it('should call onClick function', () => {
    spyOn(component, 'onClick');
    component.control = new UntypedFormControl('test');
    fixture.detectChanges();
    component.control.setValue({
      abbreviation: 'HKBI',
      departmentName: 'IT BAS CC Corporate BPI & Automation',
      email: 'harshit.kapoor@asml.net',
      fullName: 'Harshit Kapoor',
      photoURL: 'https://people.asml.com/_layouts/15/userphoto.aspx?size=M&accountname=asml%2Dcom%5Chkapoor',
      roles: ['changeSpecialist1'],
      userID: 'hkapoor'
    });
    fixture.detectChanges();
    expect(component.oldValue).toEqual({
      abbreviation: 'HKBI',
      departmentName: 'IT BAS CC Corporate BPI & Automation',
      email: 'harshit.kapoor@asml.net',
      fullName: 'Harshit Kapoor',
      photoURL: 'https://people.asml.com/_layouts/15/userphoto.aspx?size=M&accountname=asml%2Dcom%5Chkapoor',
      roles: ['changeSpecialist1'],
      userID: 'hkapoor'
    });
  });

  it('should call onCLick event', () => {
    component.onClick();
    expect(component.mode).toBe(Modes.EDIT);
  });

  it('should prevent default implementation when, on blur is triggered & relatedTarget is clear button', () => {
    const mockEvent = {
      relatedTarget: {
        id: 'test_close',
        click: () => ''
      },
      preventDefault: () => {}
    };
    const relatedTargetClick = spyOn(mockEvent, 'preventDefault');
    component.ID = 'test';
    component.matAutoComplete = jasmine.createSpyObj('isOpen', ['']);
    component.onInputBlur(mockEvent);
    expect(relatedTargetClick).toHaveBeenCalled();
  });

  it('should call onItemSelected, when onKeyUp is triggered after SPACE key is pressed', () => {
    spyOn(component, 'onItemSelected');
    component.autoTrigger = {
      get activeOption(): MatOption | null {
        return {} as MatOption;
      }
    } as MatAutocompleteTrigger;
    const event = new KeyboardEvent('keyup', {
      key: ' '
    });
    component.onKeyUp(event);
    expect(component.onItemSelected).toHaveBeenCalled();
  });

  it('should call triggerRejectChanges, when lockMode is EDIT, control is not valid and onInputBlur is triggered when no related target exists', () => {
    const spy = spyOn(component, 'triggerRejectChanges');
    component.lockMode = Modes.EDIT;
    component.oldValue = {value: 'YES'};
    component.control.setValue('Test');
    spyOnProperty(component.control, 'valid').and.returnValue(false);
    component.onInputBlur({});
    expect(spy).toHaveBeenCalled();
  });

  it('should call triggerRejectChanges, when onInputBlur is triggered when no related target exists', () => {
    const spy = spyOn(component, 'triggerRejectChanges');
    component.oldValue = {value: 'YES'};
    component.control.setValue('Test');
    component.onInputBlur({});
    expect(spy).toHaveBeenCalled();
  });

  it('should emit onFocus, when onInputFocus is triggered', () => {
    const spy = spyOn(component.onFocus, 'emit');
    component.onInputFocus();
    expect(spy).toHaveBeenCalled();
  });

  it('should click on the element, when onBlur is triggered and related target is the autocomplete options list', () => {
    component.onClick();
    fixture.detectChanges();
    spyOnProperty(component.matAutoComplete, 'isOpen').and.returnValue(true);
    const mockEvent = {
      relatedTarget: {
        id: 'test',
        click: () => ''
      }
    };
    const relatedTargetClick = spyOn(mockEvent.relatedTarget, 'click');
    component.onInputBlur(mockEvent);
    expect(relatedTargetClick).toHaveBeenCalled();
  });

  it('should emit optionPanelClosed, when option panel is closed', () => {
    const spy = spyOn(component.optionsPanelClosed, 'emit');
    component.onOptionsPanelClosed();
    expect(spy).toHaveBeenCalled();
  });

});
