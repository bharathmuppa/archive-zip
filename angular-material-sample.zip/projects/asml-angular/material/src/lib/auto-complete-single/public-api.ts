/*
 * Public API Surface of material
 */

export * from './auto-complete-single.component';
export * from './auto-complete-single.module';
