import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {AALExpansionPanelOverviewCardListComponent} from './expansion-panel-overview-card-list.component';
import {AALListItemModule} from '../list-item/list-item.module';
import {AALEmptyStateModule} from '../empty-state/empty-state.module';
import {AALButtonOverlayCardModule} from '../button-overlay-card/button-overlay-card.module';
import {AALCardSummaryModule} from '../card-summary/card-summary.module';
import {MatExpansionModule} from '@angular/material/expansion';
import {FlexLayoutModule} from '@angular/flex-layout';
import {AALOverlayCardHelpModule} from '../overlay-card-help/overlay-card-help.module';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import {MatTooltipModule} from '@angular/material/tooltip';
import {MatIconModule} from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';

@NgModule({
  declarations: [AALExpansionPanelOverviewCardListComponent],
  imports: [
    CommonModule,
    AALListItemModule,
    AALEmptyStateModule,
    AALButtonOverlayCardModule,
    AALOverlayCardHelpModule,
    AALCardSummaryModule,
    MatButtonModule,
    MatIconModule,
    MatExpansionModule,
    MatProgressSpinnerModule,
    MatTooltipModule,
    FlexLayoutModule
  ],
  exports: [AALExpansionPanelOverviewCardListComponent]
})
export class AALExpansionPanelOverviewCardListModule {
}
