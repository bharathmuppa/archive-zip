import {Component, EventEmitter, Input, OnInit, Output, TemplateRef} from '@angular/core';
import {
  EmptyStateData,
  ExpansionPanelItemConfiguration,
  OverlayCardData
} from '../expansion-panel-list/expansion-panel-list.model';
import {Info} from '@asml-angular/common';
import {ActionEventData} from '../list-item/list-item.component';

@Component({
  selector: 'aal-expansion-panel-overview-card-list',
  templateUrl: './expansion-panel-overview-card-list.component.html',
  styleUrls: ['./expansion-panel-overview-card-list.component.scss']
})
export class AALExpansionPanelOverviewCardListComponent implements OnInit {

  @Input()
  expansionPanelItemConfigurationList: ExpansionPanelItemConfiguration[];
  @Input()
  defaultItemIcon: string;
  @Input()
  defaultItemImageURL: string;
  @Input()
  defaultSvgIcon: string;
  @Input()
  help: Info | string;
  @Input()
  header: string;
  @Input()
  showAddButton: boolean;
  @Input()
  isExpanded: boolean;
  @Input()
  isBusy: boolean;
  @Input()
  emptyStateData: EmptyStateData;
  @Input()
  mainDescriptionTemplateRef: TemplateRef<any>;
  @Input()
  line1TemplateRef: TemplateRef<any>;
  @Input()
  imageDisplayRef: TemplateRef<any>;
  @Input()
  actionTemplateRef: TemplateRef<any>;
  @Input()
  emptyStateTemplateRef: TemplateRef<any>;
  @Input()
  expansionPanelListTemplateRef: TemplateRef<any>;
  @Input()
  expansionPanelListLoaderTemplateRef: TemplateRef<any>;
  @Output()
  addItem: EventEmitter<void> = new EventEmitter<void>();
  @Output()
  actionSubmit: EventEmitter<ActionEventData> = new EventEmitter<ActionEventData>();
  @Output()
  itemClick: EventEmitter<string> = new EventEmitter<string>();
  @Output()
  overlayCardOpened: EventEmitter<any> = new EventEmitter<any>();
  @Output()
  overlayListItemClick: EventEmitter<any> = new EventEmitter<any>();
  @Output()
  overlayCardSubmit: EventEmitter<any> = new EventEmitter<any>();
  @Input()
  addButtonToolTip: string;
  @Input()
  disableAddButton: boolean;
  @Input()
  overlayCardData: OverlayCardData[];
  @Input()
  overlayCardHeaderTitle: string;
  @Input()
  overlayHeaderIcon: string;
  @Input()
  overlayActionButtonText: string;
  @Input()
  defaultOverlayListIcon: string;
  @Input()
  hasBadge: boolean;
  @Input()
  badgeData: string;
  @Input()
  referenceBadgeData: string;
  @Input()
  badgeType: string;
  @Input()
  overlayMenuXPosition: string;
  @Input()
  overlayMenuYPosition: string;
  @Input()
  hideHelp: boolean;
  @Input()
  overlayButtonRef: TemplateRef<any>;

  hasAnyItemHelp: boolean;

  constructor() {
  }

  ngOnInit() {
    if (this.help && typeof this.help === 'string') {
      this.help = new Info(this.help);
    }
    this.hasAnyItemHelp = this.hasAnyItemHelpText();
  }

  hasAnyItemHelpText(): boolean {
    if (this.expansionPanelItemConfigurationList && this.expansionPanelItemConfigurationList.length > 0) {
      for (const item of this.expansionPanelItemConfigurationList) {
        if (item.help) {
          return true;
        }
      }
    }
    return false;
  }

  onActionSubmit(actionEventData: ActionEventData): void {
    this.actionSubmit.emit(actionEventData);
  }

  addItemClick($event): void {
    this.addItem.emit();
    $event.stopPropagation();
  }

  onItemClick(itemId: string): void {
    this.itemClick.emit(itemId);
  }

  onTitleClick(Id: string): void {
    this.itemClick.emit(Id);
  }
  buttonClick() {
    this.overlayCardSubmit.emit();
  }
  overlayCardOpen(event) {
    this.overlayCardOpened.emit(event);
  }
  overlayCardListItemClick(event) {
    this.overlayListItemClick.emit(event);
  }
}
