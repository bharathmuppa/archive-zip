import {ComponentFixture, TestBed, waitForAsync} from '@angular/core/testing';

import {AALExpansionPanelOverviewCardListComponent} from './expansion-panel-overview-card-list.component';
import {CommonModule} from '@angular/common';
import {SharedMaterialModule} from '../shared/shared-material.module';
import {SharedFormModule} from '../shared/shared-form.module';
import {AALCommonComponentsModule} from '@asml-angular/common';
import {SharedModule} from '../shared/shared.module';
import {SharedFlexLayoutModule} from '../shared/shared-flex-layout.module';
import {MatBadgeModule} from '@angular/material/badge';
import {AALListItemModule} from '../list-item/list-item.module';
import {AALButtonOverlayCardModule} from '../button-overlay-card/button-overlay-card.module';
import {AALEmptyStateModule} from '../empty-state/empty-state.module';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {ExpansionPanelItemConfiguration} from '../expansion-panel-list/expansion-panel-list.model';
import {ActionEventData} from '../shared/list-item-configuration.model';
import {NO_ERRORS_SCHEMA} from '@angular/core';

describe('AALExpansionPanelOverviewCardListComponent', () => {
  let component: AALExpansionPanelOverviewCardListComponent;
  let fixture: ComponentFixture<AALExpansionPanelOverviewCardListComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [AALExpansionPanelOverviewCardListComponent],
      schemas: [NO_ERRORS_SCHEMA],
      imports: [
        CommonModule,
        SharedMaterialModule,
        SharedFormModule,
        AALCommonComponentsModule,
        SharedModule,
        SharedFlexLayoutModule,
        MatBadgeModule,
        AALListItemModule,
        AALButtonOverlayCardModule,
        AALEmptyStateModule,
        BrowserAnimationsModule
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALExpansionPanelOverviewCardListComponent);
    component = fixture.componentInstance;
    component.help = 'test';
    component.expansionPanelItemConfigurationList = [{help: {message: 'sample'}}] as ExpansionPanelItemConfiguration[];
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should set hasAnyItemHelp as false, when expansionPanelItemConfigurationList is empty', () => {
    component.expansionPanelItemConfigurationList = [];
    component.ngOnInit();
    expect(component.hasAnyItemHelp).toBe(false);
  });
  it('should emit actionSubmit when onActionSubmit is clicked', () => {
    spyOn(component.actionSubmit, 'emit');
    component.onActionSubmit({} as ActionEventData);
    expect(component.actionSubmit.emit).toHaveBeenCalledWith({} as ActionEventData);
  });
  it('should prevent current event propagation when addItemClick is clicked', () => {
    const event = new MouseEvent('click');
    spyOn(event, 'stopPropagation');
    component.addItemClick(event);
    expect(event.stopPropagation).toHaveBeenCalled();
  });
  it('should emit itemClick when onTitleClick is clicked', () => {
    spyOn(component.itemClick, 'emit');
    component.onTitleClick('sample');
    expect(component.itemClick.emit).toHaveBeenCalledWith('sample');
  });
  it('should emit itemClick when onItemClick is clicked', () => {
    spyOn(component.itemClick, 'emit');
    component.onItemClick('sample');
    expect(component.itemClick.emit).toHaveBeenCalledWith('sample');
  });
  it('should emit overlayCardSubmit when buttonClick is clicked', () => {
    spyOn(component.overlayCardSubmit, 'emit');
    component.buttonClick();
    expect(component.overlayCardSubmit.emit).toHaveBeenCalled();
  });
  it('should emit overlayCardOpened event when overlayCardOpen is clicked', () => {
    const event = new MouseEvent('click');
    spyOn(component.overlayCardOpened, 'emit');
    component.overlayCardOpen(event);
    expect(component.overlayCardOpened.emit).toHaveBeenCalledWith(event);
  });
  it('should emit overlayListItemClick event when overlayCardListItemClick is clicked', () => {
    const event = new MouseEvent('click');
    spyOn(component.overlayListItemClick, 'emit');
    component.overlayCardListItemClick(event);
    expect(component.overlayListItemClick.emit).toHaveBeenCalledWith(event);
  });
});
