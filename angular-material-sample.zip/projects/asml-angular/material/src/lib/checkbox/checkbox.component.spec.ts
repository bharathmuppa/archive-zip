import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AALCheckboxComponent } from './checkbox.component';
import {CommonModule} from '@angular/common';
import {SharedMaterialModule} from '../shared/shared-material.module';
import {SharedFormModule} from '../shared/shared-form.module';
import {AALCommonComponentsModule, RejectedChange} from '@asml-angular/common';
import {AALOverlayCardHelpModule} from '../overlay-card-help/overlay-card-help.module';
import {AALOverlayCardErrorModule} from '../overlay-card-alert/overlay-card-alert.module';
import {AALToolbarConfirmModule} from '../toolbar-confirm/toolbar-confirm.module';
import {SharedFlexLayoutModule} from '../shared/shared-flex-layout.module';
import {UntypedFormControl} from '@angular/forms';

describe('AALCheckboxComponent', () => {
  let component: AALCheckboxComponent;
  let fixture: ComponentFixture<AALCheckboxComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AALCheckboxComponent ],
      imports: [
        CommonModule,
        SharedMaterialModule,
        SharedFormModule,
        AALCommonComponentsModule,
        AALOverlayCardHelpModule,
        AALOverlayCardErrorModule,
        AALToolbarConfirmModule,
        SharedFlexLayoutModule
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AALCheckboxComponent);
    component = fixture.componentInstance;
    component.control = new UntypedFormControl(['test2']);
    component.options = [
      {name: 'option1', description: 'description1'},
      {name: 'option2', description: 'test2'},
      {name: 'option3', description: 'test3'}
    ];
    component.optionType = 'object';
    component.optionValueField = 'description';
    jasmine.clock().uninstall();
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize checkBoxData, when options are of type string', () => {
    component.checkboxData = [];
    component.options = ['str option1', 'str option2', 'str option3'];
    component.ngOnInit();
    expect(component.checkboxData.length).toEqual(3);
  });

  it('should return, when onBlur is triggered and related target is one of the checkboxes', () => {
    component.hyphenatedID = 'test';
    const elem = document.createElement('div');
    elem.classList.add('checkbox-div');
    elem.id = 'test_button_toggle_1';
    const retValue = component.onBlur(new FocusEvent('focusout', {relatedTarget: elem}));
    expect(retValue).toEqual(undefined);
  });

  it('should set appropriate mode, when resetMode is triggered and related target is not one of the checkboxes', () => {
    component.resetMode({relatedTarget: null});
    expect(component.mode).toBe('READ');
  });

  it('should set appropriate mode, when onButtonRadioBlur is triggered, no relatedTarget exists or related target is not one of the radio button options', () => {
    component.onBlur({relatedTarget: null});
    expect(component.mode).toBe('READ');
  });

  it('should set appropriate mode, when onKeyUp is triggered and ESC key is pressed', () => {
    component.onKeyUp({
      key: 'Escape',
      currentTarget: {
        parentElement: {
          children: []
        }
      }
    });
    expect(component.mode).toBe('READ');
  });

  it('should focus on the next option, when onKeyUp is triggered and ArrowRight key is pressed', () => {
    const spy = spyOn(component, 'navigateOptions').and.callThrough();
    const event = {
      key: 'ArrowRight',
      currentTarget: {
        parentElement: {
          children: [
            {
              classList: {
                contains: () => {
                  return true;
                },
                add: () => {}
              },
              focus: () => {}
            },
            {
              classList: {
                contains: () => {
                  return true;
                },
                add: () => {}
              },
              focus: () => {}
            }
          ]
        }
      }
    };
    component.onKeyUp(event);
    expect(spy).toHaveBeenCalled();
  });

  it('should focus on the previous option, when onKeyUp is triggered and ArrowLeft key is pressed', () => {
    const spy = spyOn(component, 'navigateOptions').and.callThrough();
    const event = {
      key: 'ArrowLeft',
      currentTarget: {
        parentElement: {
          children: [
            {
              classList: {
                contains: () => {
                  return true;
                },
                add: () => {}
              },
              focus: () => {}
            },
            {
              classList: {
                contains: () => {
                  return true;
                },
                add: () => {}
              },
              focus: () => {}
            }
          ]
        }
      }
    };
    component.onKeyUp(event);
    expect(spy).toHaveBeenCalled();
  });

  it('should select the appropriate option, when onKeyUp is triggered and an alphabet key is pressed', () => {
    const event = {
      key: 'S',
      currentTarget: {
        parentElement: {
          children: [
            {
              innerText: 'Test'
            },
            {
              innerText: 'Select Option',
              children: [
                {
                  click: () => {}
                }
              ]
            }
          ]
        }
      }
    };
    const spy = spyOn(event.currentTarget.parentElement.children[1].children[0], 'click');
    component.onKeyUp(event);
    expect(spy).toHaveBeenCalled();
  });

  it('should reset the control, when onKeyUp is triggered, the control has a value and C key is pressed', () => {
    const spy = spyOn(component, 'resetControl');
    component.control = new UntypedFormControl('Opt 1');
    component.onKeyUp({
      key: 'C',
      currentTarget: {
        parentElement: {
          children: [
            {
              innerText: 'Test'
            },
            {
              innerText: 'Select Option'
            }
          ]
        }
      }
    });
    expect(spy).toHaveBeenCalled();
  });

  it('should click the focused checkbox, when onKeyUp is triggered and Enter or Space key is pressed', () => {
    const event = {
      key: 'Enter',
      currentTarget: {
        parentElement: {
          children: []
        }
      },
      target: {
        children: [
          {
            click: () => {}
          }
        ]
      }
    };
    const spy = spyOn(event.target.children[0], 'click');
    component.onKeyUp(event);
    expect(component.mode).toBe('READ');
  });

  it('should focus on the checkbox, when onClick is triggered', () => {
    component.checkbox = {
      focus: () => {}
    };
    const spy = spyOn(component.checkbox, 'focus');
    jasmine.clock().install();
    component.onClick();
    jasmine.clock().tick(300);
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
    jasmine.clock().uninstall();
  });

  it('should select appropriate checkbox, when setSelectedOption is triggered', () => {
    component.options = ['str option1', 'str option2', 'str option3'];
    component.checkboxData = [
      {label: 'str option1', value: 'str option1', selected: false},
      {label: 'str option2', value: 'str option2', selected: false},
      {label: 'str option3', value: 'str option3', selected: false}
    ];
    component.optionType = 'string';
    component.control.patchValue(['str option1']);
    component.setSelectedOptions();
    expect(component.checkboxData[0].selected).toBe(true);
  });

  it('should set appropriate control value, when onChange is triggered and optionType is object', () => {
    component.checkboxData = [
      {name: 'option1', description: 'description1', selected: true},
      {name: 'option2', description: 'test2', selected: false},
      {name: 'option3', description: 'test3', selected: false}
    ];
    component.onChange({});
    expect(component.control.value).toEqual(['description1']);
  });

  it('should set appropriate control value, when onChange is triggered and optionType is string', () => {
    component.options = ['str option1', 'str option2', 'str option3'];
    component.checkboxData = [
      {label: 'str option1', value: 'str option1', selected: false},
      {label: 'str option2', value: 'str option2', selected: true},
      {label: 'str option3', value: 'str option3', selected: true}
    ];
    component.optionType = 'string';
    component.onChange({});
    expect(component.control.value).toEqual(['str option2', 'str option3']);
  });

  it('should call setSelectedOptions, when rejectChanges is emitted', () => {
    const spy = spyOn(component, 'setSelectedOptions');
    component.rejectChanges.emit(new RejectedChange('test', ['option1'], []))
    expect(spy).toHaveBeenCalled();
  });

    it('should call trigger accept changes and set all checkboxes to checked, when Select All is checked', () => {
        const spy = spyOn(component, 'triggerAcceptChanges');
        component.options = ['str option1', 'str option2', 'str option3'];
        component.checkboxData = [
            {label: 'str option1', value: 'str option1', selected: false},
            {label: 'str option2', value: 'str option2', selected: true},
            {label: 'str option3', value: 'str option3', selected: true}
        ];
        component.optionType = 'string';
        component.onSelectAll({checked:true});
        //all items should be selected
        expect(component.checkboxData.filter(item => item.selected === true).length === 3);
        expect(spy).toHaveBeenCalled();
    });

    it('should trigger accept changes on change, when triggerAcceptOnSelect is set', () => {
        const spy = spyOn(component, 'triggerAcceptChanges');
        component.options = ['str option1', 'str option2', 'str option3'];
        component.checkboxData = [
            {label: 'str option1', value: 'str option1', selected: false},
            {label: 'str option2', value: 'str option2', selected: false},
            {label: 'str option3', value: 'str option3', selected: true}
        ];
        component.optionType = 'string';
        component.triggerAcceptOnSelect = true;
        component.onChange({checked:true});
        //should trigger accept changes
        expect(spy).toHaveBeenCalled();
    });
});
