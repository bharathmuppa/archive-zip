/*
 * Public API Surface of material
 */

export * from './checkbox.component';
export * from './checkbox.module';
