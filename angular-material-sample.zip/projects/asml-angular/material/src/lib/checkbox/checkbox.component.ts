import {Component, Input, OnInit, ViewChild} from '@angular/core';
import {AALFixedInputFormControlComponent, HistoryService, Modes, RejectedChange} from '@asml-angular/common';

@Component({
  selector: 'aal-checkbox',
  templateUrl: './checkbox.component.html',
  styleUrls: ['./checkbox.component.scss']
})
export class AALCheckboxComponent extends AALFixedInputFormControlComponent implements OnInit {
  checkboxData: any[];
  @Input()
  layout: string;
  @Input()
  alignOptionsHorizontally: boolean;
  @Input() hideClearSelection: boolean;
  @ViewChild('checkbox') checkbox;
  @Input()
  showSelectAll: boolean;
  selectAllSelected: boolean;
  @Input()
  triggerAcceptOnSelect: boolean;

  constructor(historyService: HistoryService) {
    super(historyService);
    this.checkboxData = [];
    this.showSelectAll = false;
    this.triggerAcceptOnSelect = false;
  }

  ngOnInit() {
    this.options.forEach(option => {
      if (typeof option === 'string') {
        this.checkboxData.push({label: option, value: option, selected: false});
      } else {
        this.checkboxData.push({...option, selected: false});
      }
    });
    this.setLayout();
    this.setSelectedOptions();
    this.subscribeToRejectedChange();
    super.ngOnInit();
  }

  setLayout() {
    if (!this.layout && this.options) {
      this.layout = this.options.length > 3 ? 'column' : 'row';
    }
  }

  resetMode(event) {
    if (event && (!event.relatedTarget || !(event.relatedTarget.classList && event.relatedTarget.id && event.relatedTarget.id.includes(this.hyphenatedID)))) {
      // Set the mode to the default mode, when focus is lost from the 'Clear Selection' button and related target is not the secondaryControl or the options
      this.mode = this.lockMode ? this.lockMode : Modes.READ;
      this.triggerAcceptChanges();
    }
  }

  onBlur(event) {
    if (event && event.relatedTarget && (event.relatedTarget.id && event.relatedTarget.id.includes(this.hyphenatedID) ||
      event.relatedTarget.classList && event.relatedTarget.classList.contains('checkbox-div'))) {
      // If relatedTarget of focusOut event is the next/previous option, do nothing
      return;
    } else if (event && (!event.relatedTarget || (event.relatedTarget && !event.relatedTarget.id) ||
      (event.relatedTarget && event.relatedTarget.id && !event.relatedTarget.id.includes(this.hyphenatedID)))) {
      // when navigating to an unrelated element, set back the default mode
      this.mode = this.lockMode ? this.lockMode : Modes.READ;
      this.triggerAcceptChanges();
    }
  }

  onKeyUp(event) {
    const regex = new RegExp('^([A-Z])$');
    const children = Array.from(event.currentTarget.parentElement.children) as any[];
    const key = event.key.toUpperCase();
    if (event.key === 'Escape') {
      // If Esc key is pressed and lockMode is not set, set the mode to READ
      this.mode = this.lockMode ? this.lockMode : Modes.READ;
    } else if (event.key === 'ArrowRight') {
      this.navigateOptions(children, 'RIGHT');
    } else if (event.key === 'ArrowLeft') {
      this.navigateOptions(children, 'LEFT');
    } else if ((event.key === 'Enter' || event.key === ' ') && event.target && event.target.children && event.target.children.length) {
      event.target.children[0].click();
    } else if (regex.test(key)) {
      if (key === 'C' && this.control.value) {
        // If the key pressed is <c> or <C> and the control has a value it is cleared
        this.resetControl();
      } else {
        // Below code is to select an option based on the key typed by the user Ex: If the user presses 'A' the below code selects and saves the first option which starts with either <a> or <A>
        for (const child of children) {
          const firstChar = child.innerText.substring(0, 1).toUpperCase();
          if (firstChar === key) {
            child.children[0].click();
            break;
          }
        }
      }
    }
  }

  navigateOptions(children, direction) {
    // When arrow left/right key is pressed need to focus the previous/next button, a.k.a button to the left/right of the currently focused button
    let currentIndex = 0;
    let nextIndex = 0;
    for (const child of children) {
      if (child.classList.contains('cdk-focused')) {
        currentIndex = children.indexOf(child);
        nextIndex = (currentIndex === 0 && direction === 'LEFT') ? children.length - 1 :
          (currentIndex === children.length - 1 && direction === 'RIGHT') ? 0 :
            (direction === 'LEFT') ? currentIndex - 1 : currentIndex + 1;
      }
    }
    // Manually set the focus to the previous checkbox and apply appropriate CSS
    children[nextIndex].tabIndex = 0;
    children[nextIndex].focus();
    children[nextIndex].classList.add('cdk-focused');
    children[nextIndex].classList.add('cdk-keyboard-focused');
  }


  onClick() {
    super.onClick();
    setTimeout(() => {
      if (this.checkbox) {
        this.checkbox.focus();
      }
    }, 200);
  }

  setSelectedOptions() {
    // This method is used to set the appropriate checkbox as selected based on the control value
    this.checkboxData.forEach((option: any, index: number) => {
      if (this.optionType !== 'string' && this.control && this.control.value) {
        this.control.value.forEach(value => {
          if (value && option[this.optionValueField].includes(value)) {
            option.selected = true;
          }
        });
      } else {
        this.control.value.forEach(value => {
          if (value && option.value.includes(value)) {
            option.selected = true;
          }
        });
      }
    });
      const selectedCheckboxes = this.checkboxData.filter(item => item.selected === true);
      this.selectAllSelected = selectedCheckboxes.length === this.checkboxData.length;
  }

  onChange($event: any) {
    const affectedCheckboxes = this.checkboxData.filter(item => item.selected === $event.checked);
    this.selectAllSelected = $event.checked && affectedCheckboxes.length === this.checkboxData.length;
    // We need to filter all the checkboxes that are checked from checkboxData array and then set control value accordingly
    const filteredData = this.checkboxData.filter(item => item.selected);
    const selectedOptions = [];
    filteredData.forEach(item => {
      selectedOptions.push(this.optionType === 'string' ? item.value : item[this.optionValueField]);
    });
    this.control.patchValue(selectedOptions);
    if (this.triggerAcceptOnSelect) {
        this.triggerAcceptChanges();
    }
  }

    onSelectAll($event: any) {
      this.selectAllSelected = $event.checked;
        // We need to filter all the checkboxes that are checked from checkboxData array and then set control value accordingly
        this.checkboxData.forEach(item => item.selected = $event.checked);
        const selectedOptions = [];
        this.checkboxData.forEach(item => {
            if (item.selected) {
                selectedOptions.push(this.optionType === 'string' ? item.value : item[this.optionValueField]);
            }
        });
        this.control.patchValue(selectedOptions);
        this.triggerAcceptChanges();
    }

  subscribeToRejectedChange() {
    // This method is used to update the checkboxData array to revert back the checkbox selected states in case a value has been rejected
    this.rejectChanges.subscribe(val => {
      if (val && val instanceof RejectedChange) {
        this.control.patchValue(this.oldValue);
        this.setSelectedOptions();
      }
    });
  }
}
