import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {AALCommonComponentsModule, AALCommonModule} from '@asml-angular/common';
import {AALOverlayCardHelpModule} from '../overlay-card-help/overlay-card-help.module';
import {AALOverlayCardErrorModule} from '../overlay-card-alert/overlay-card-alert.module';
import {AALToolbarConfirmModule} from '../toolbar-confirm/toolbar-confirm.module';
import {AALButtonTextModule} from '../button-text/button-text.module';
import {AALCheckboxComponent} from './checkbox.component';
import {FlexLayoutModule} from '@angular/flex-layout';
import {MatTooltipModule} from '@angular/material/tooltip';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import {MatInputModule} from '@angular/material/input';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';

@NgModule({
  declarations: [AALCheckboxComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    AALCommonModule,
    AALCommonComponentsModule,
    AALOverlayCardHelpModule,
    AALOverlayCardErrorModule,
    AALToolbarConfirmModule,
    AALButtonTextModule,
    MatCheckboxModule,
    MatInputModule,
    MatProgressSpinnerModule,
    MatTooltipModule,
    FlexLayoutModule
  ],
  exports: [
    AALCheckboxComponent
  ]
})
export class AALCheckBoxModule {
}
