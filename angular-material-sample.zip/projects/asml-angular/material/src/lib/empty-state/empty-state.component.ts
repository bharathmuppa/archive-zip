import {Component, Input, OnInit, TemplateRef} from '@angular/core';

@Component({
  selector: 'aal-empty-state',
  templateUrl: './empty-state.component.html',
  styleUrls: ['./empty-state.component.scss']
})
export class AALEmptyStateComponent implements OnInit {
  @Input()
  iconSize: string; // medium, small, large, extra-large
  @Input()
  isPageLevel: boolean;
  @Input()
  title: string;
  @Input()
  subTitle: string;
  @Input()
  description: string;
  @Input()
  icon: string;
  @Input()
  imageURL: string;
  @Input()
  svgIcon: string;
  @Input()
  imageTemplateRef: TemplateRef<any>;
  @Input()
  subTitleTemplateRef: TemplateRef<any>;
  @Input()
  titleTemplateRef: TemplateRef<any>;
  @Input()
  descriptionTemplateRef: TemplateRef<any>;

  constructor() {
  }

  ngOnInit() {
  }

}
