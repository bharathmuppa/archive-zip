import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {AALEmptyStateComponent} from './empty-state.component';
import {FlexLayoutModule} from '@angular/flex-layout';
import {MatIconModule} from '@angular/material/icon';

@NgModule({
  declarations: [AALEmptyStateComponent],
  imports: [
    CommonModule,
    MatIconModule,
    FlexLayoutModule
  ],
  exports: [AALEmptyStateComponent]
})
export class AALEmptyStateModule {
}
