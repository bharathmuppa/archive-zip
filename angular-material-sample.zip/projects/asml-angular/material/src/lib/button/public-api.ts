/*
 * Public API Surface of material
 */

export * from './button.component';
export * from './button.module';
