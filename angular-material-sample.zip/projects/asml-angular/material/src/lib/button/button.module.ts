import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {AALButtonComponent} from './button.component';
import {AALCommonComponentsModule} from '@asml-angular/common';
import {AALButtonContainedModule} from '../button-contained/button-contained.module';
import {AALButtonIconModule} from '../button-icon/button-icon.module';

@NgModule({
  declarations: [AALButtonComponent],
  imports: [
    CommonModule,
    AALCommonComponentsModule,
    AALButtonContainedModule,
    AALButtonIconModule,
  ],
  exports: [AALButtonComponent]
})
export class AALButtonModule {
}
