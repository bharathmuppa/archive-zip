import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import {CommonModule} from '@angular/common';
import {AALCommonComponentsModule} from '@asml-angular/common';
import {MatBadgeModule} from '@angular/material/badge';

import {SharedMaterialModule} from '../shared/shared-material.module';
import {SharedFormModule} from '../shared/shared-form.module';
import {SharedModule} from '../shared/shared.module';
import {SharedFlexLayoutModule} from '../shared/shared-flex-layout.module';
import { AALButtonComponent } from './button.component';
import {AALButtonContainedModule} from '../button-contained/button-contained.module';
import {AALButtonIconModule} from '../button-icon/button-icon.module';

describe('AALButtonComponent', () => {
  let component: AALButtonComponent;
  let fixture: ComponentFixture<AALButtonComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ AALButtonComponent ],
      imports: [
        CommonModule,
        SharedMaterialModule,
        SharedFormModule,
        AALCommonComponentsModule,
        SharedModule,
        SharedFlexLayoutModule,
        MatBadgeModule,
        AALButtonContainedModule,
        AALButtonIconModule
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALButtonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should emit on click', () => {
    spyOn(component.onClick, 'emit');
    const $event = new Event('click');
    component.click($event);
    expect(component.onClick.emit).toHaveBeenCalled();
  });
});
