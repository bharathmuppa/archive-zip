import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {ButtonConfiguration} from '../shared/shared.model';
import {ButtonTypes} from '@asml-angular/common';

@Component({
  selector: 'aal-button',
  templateUrl: './button.component.html',
  styleUrls: ['./button.component.scss']
})
export class AALButtonComponent implements OnInit {
  @Input()
  buttonConfiguration: ButtonConfiguration;
  @Output() onClick = new EventEmitter<any>();
  buttonTypes = ButtonTypes;

  ngOnInit() {
  }

  click($event): void {
    this.onClick.emit($event);
  }
}
