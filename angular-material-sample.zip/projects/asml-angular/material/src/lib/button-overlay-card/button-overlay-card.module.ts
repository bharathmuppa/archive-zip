import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {DragDropModule} from '@angular/cdk/drag-drop';
import {AALCommonComponentsModule} from '@asml-angular/common';
import { AALButtonOverlayCardComponent } from './button-overlay-card.component';
import {AALListItemModule} from '../list-item/list-item.module';
import {AALCardSummaryModule} from '../card-summary/card-summary.module';
import {AALEmptyStateModule} from '../empty-state/empty-state.module';
import {AALOverlayCardHelpModule} from '../overlay-card-help/overlay-card-help.module';
import {MatMenuModule} from '@angular/material/menu';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatTooltipModule} from '@angular/material/tooltip';
import {MatIconModule} from '@angular/material/icon';
import {MatBadgeModule} from '@angular/material/badge';
import {MatButtonModule} from '@angular/material/button';
import {MatDividerModule} from '@angular/material/divider';
import {FlexLayoutModule} from '@angular/flex-layout';

@NgModule({
  declarations: [AALButtonOverlayCardComponent],
  imports: [
    CommonModule,
    MatButtonModule,
    MatBadgeModule,
    MatDividerModule,
    MatIconModule,
    MatToolbarModule,
    MatTooltipModule,
    DragDropModule,
    AALCommonComponentsModule,
    AALListItemModule,
    AALCardSummaryModule,
    AALEmptyStateModule,
    MatMenuModule,
    AALOverlayCardHelpModule,
    FlexLayoutModule
  ],
  exports: [AALButtonOverlayCardComponent]
})
export class AALButtonOverlayCardModule { }
