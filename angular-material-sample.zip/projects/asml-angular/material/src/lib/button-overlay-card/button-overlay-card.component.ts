import {Component, EventEmitter, Input, Output, TemplateRef, ViewChild} from '@angular/core';
import {CdkDragDrop, moveItemInArray} from '@angular/cdk/drag-drop';
import {AALCommonButtonComponent, Info} from '@asml-angular/common';
import {ButtonType} from '@asml-angular/common/lib/models/enumeration.model';

import {Category, CategoryItemConfiguration, ListItemConfiguration} from '../shared/list-item-configuration.model';
import {EmptyStateData} from '../expansion-panel-list/expansion-panel-list.model';

@Component({
  selector: 'aal-button-overlay-card',
  templateUrl: './button-overlay-card.component.html',
  styleUrls: ['./button-overlay-card.component.scss']
})
export class AALButtonOverlayCardComponent extends AALCommonButtonComponent {
  @Input()
  closeOnItemClick: boolean;
  @Input()
  isDragDropAllowed: boolean;
  @Input()
  progressBar: boolean;
  @Input()
  showFooterBar: boolean;
  @Input()
  hideSectionDivider: boolean;
  @Input()
  isIconBorder: boolean;
  @Input()
  showCategories: boolean;
  @Input()
  categoryKey: string;
  @Input()
  categoryPropertyName: string;
  @Input()
  categoryItemsPropertyName: string;
  @Input()
  categoryItemsCount: number;
  @Input()
  fractionCount: number;
  @Input()
  totalItemsCount: number;
  @Input()
  headerIcon: string;
  @Input()
  headerTitle: any;
  @Input()
  buttonLabel: string;
  @Input()
  overlayData: any;
  @Input()
  buttonIcon: string;
  @Input()
  buttonType: ButtonType;
  @Input()
  buttonTooltip: string;
  @Input()
  footerButtonText: string;
  @Input()
  footerButtonColor: string;
  @Input()
  itemTemplateRef: TemplateRef<any>;
  @Input()
  tooltipDisabled: boolean;
  @Input()
  help: Info;
  @Input()
  emptyStateData: EmptyStateData;
  @Input()
  emptyStateTemplateRef: TemplateRef<any>;
  @Input()
  overlayCardLoaderTemplateRef: TemplateRef<any>;
  @Input()
  menuContentRef: TemplateRef<any>;
  @Input()
  hideHeaderSection: boolean;
  @ViewChild('overLayMenu', {static: false}) overLayMenu;
  listItems: CategoryItemConfiguration[] = [];
  @Input()
  set listItemDetails(data: ListItemConfiguration[] | CategoryItemConfiguration[] | Category) {
    if (data && Array.isArray(data)) {
      this.listItems = this.divideDataInCategories(data);
    } else if (data) {
      this.categoryItemsCount = data[this.totalItemsCount];
      this.categoryKey = this.categoryKey || 'subCategories';
      this.listItems = this.divideDataInCategories(data[this.categoryKey]);
    }
  }

  get listItemDetails(): ListItemConfiguration[] | CategoryItemConfiguration[] | Category {
    return this.listItems;
  }

  @Input()
  defaultItemIcon: string;
  @Input()
  defaultItemImageURL: string;
  @Input()
  defaultSvgIcon: string;
  @Input()
  titleTemplateRef: TemplateRef<any>;
  @Input()
  mainDescriptionTemplateRef: TemplateRef<any>;
  @Input()
  subDescriptionTemplateRef: TemplateRef<any>;
  @Output()
  submitClick: EventEmitter<string> = new EventEmitter<string>();
  @Output()
  overlayCardOpen: EventEmitter<string> = new EventEmitter<string>();
  @Input()
  overlayMenuXPosition: string;
  @Input()
  overlayMenuYPosition: string;
  @Input()
  largeAmountsLength: number;
  @Input()
  headerMenuClass: string;
  @Input()
  overlayMenuClass: string;
  @Input()
  largeAmountsTemplateRef: TemplateRef<any>;
  @Output()
  overlayCardListItemClick: EventEmitter<string> = new EventEmitter<string>();
  @Output()
  dragDropItems: EventEmitter<any> = new EventEmitter<any>();

  onsubmit($event) {
    this.submitClick.emit();
  }

  divideDataInCategories(data): CategoryItemConfiguration[] {
    let categoryItem: CategoryItemConfiguration;
    const categoryItems: CategoryItemConfiguration[] = [];
    if (!this.showCategories && data && data.length !== 0) {
      return [new CategoryItemConfiguration('', data)];
    }
    this.categoryPropertyName = this.categoryPropertyName || 'name';
    this.categoryItemsPropertyName = this.categoryItemsPropertyName || 'items';
    if (data && data.length !== 0) {
      data.forEach(item => {
        categoryItem = new CategoryItemConfiguration(item[this.categoryPropertyName], item[this.categoryItemsPropertyName]);
        categoryItems.push(categoryItem);
      });
    }
    return categoryItems as CategoryItemConfiguration[];
  }

  overlayCardOpened() {
    this.overlayCardOpen.emit();
  }

  onOverlayCardListItemClick($event) {
    this.overlayCardListItemClick.emit($event);
    if (this.closeOnItemClick) {
      this.overLayMenu.close.emit();
    }
  }

  onDrop(event: CdkDragDrop<string[]>, items): void {
    moveItemInArray(items, event.previousIndex, event.currentIndex);
    this.dragDropItems.emit(items);
  }
}
