import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import {CommonModule} from '@angular/common';
import {AALCommonComponentsModule} from '@asml-angular/common';

import {SharedMaterialModule} from '../shared/shared-material.module';
import {SharedFormModule} from '../shared/shared-form.module';
import {SharedModule} from '../shared/shared.module';
import {SharedFlexLayoutModule} from '../shared/shared-flex-layout.module';
import {AALCardSummaryModule} from '../card-summary/card-summary.module';
import {AALEmptyStateModule} from '../empty-state/empty-state.module';
import {AALButtonOverlayCardComponent} from './button-overlay-card.component';
import {CdkDragDrop} from '@angular/cdk/drag-drop';
import {Category} from "../shared/list-item-configuration.model";

describe('ButtonOverlayCardComponent', () => {
  let component: AALButtonOverlayCardComponent;
  let fixture: ComponentFixture<AALButtonOverlayCardComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [AALButtonOverlayCardComponent],
      imports: [
        CommonModule,
        SharedMaterialModule,
        SharedFormModule,
        AALCommonComponentsModule,
        SharedModule,
        SharedFlexLayoutModule,
        AALCardSummaryModule,
        AALEmptyStateModule,
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALButtonOverlayCardComponent);
    component = fixture.componentInstance;
    component.overlayMenuXPosition = 'before';
    component.overlayMenuYPosition = 'above';
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should emit on click of button', () => {
    spyOn(component.submitClick, 'emit');
    component.onsubmit(new Event('click'));
    expect(component.submitClick.emit).toHaveBeenCalled();
  });

  it('setting list item details should create category wise data', () => {
    component.showCategories = true;
    component.listItemDetails = [{
      name: 'abc',
      items: [{title: '1234', mainDescription: 'main description', subDescription: 'subdescription here'},
        {title: '12345', mainDescription: 'main description2', subDescription: 'subdescription here2'}]
    },
      {
        name: 'abcd',
        items: [{title: '1234', mainDescription: 'main description', subDescription: 'subdescription here'},
          {title: '12345', mainDescription: 'main description2', subDescription: 'subdescription here2'}]
      }];
    fixture.detectChanges();
    expect(component.listItems).toBeTruthy();
    expect(component.listItems.length).toBe(2);
  });

  it('setting list item details should create category wise data', () => {
    component.showCategories = false;
    component.listItemDetails = [
      {title: '1234', mainDescription: 'main description', subDescription: 'subdescription here'},
        {title: '12345', mainDescription: 'main description2', subDescription: 'subdescription here2'}
    ];
    fixture.detectChanges();
    expect(component.listItems.length).toBe(1);
  });

  it('setting list item details should create category wise data', () => {
    component.listItemDetails = {} as Category;
    fixture.detectChanges();
    expect(component.categoryKey).toBe('subCategories');
  });

  it('should set list items', () => {
    component.showCategories = false;
    const listItemDetails = [
      {title: '1234', mainDescription: 'main description', subDescription: 'subdescription here'},
      {title: '12345', mainDescription: 'main description2', subDescription: 'subdescription here2'}
    ];
    component.listItemDetails = listItemDetails;
    const spy = spyOnProperty(component, 'listItemDetails').and.callThrough();
    const result = component.listItemDetails;
    expect(spy).toHaveBeenCalled();
  });

  it('should emit event on opening of card', () => {
    spyOn(component.overlayCardOpen, 'emit');
    component.overlayCardOpened();
    expect(component.overlayCardOpen.emit).toHaveBeenCalled();
  });

  it('should emit event on click of item', () => {
    spyOn(component.overlayCardListItemClick, 'emit');
    component.onOverlayCardListItemClick({});
    expect(component.overlayCardListItemClick.emit).toHaveBeenCalled();

    spyOn(component.overLayMenu.close, 'emit');
    component.closeOnItemClick = true;
    component.onOverlayCardListItemClick({});
    expect(component.overLayMenu.close.emit).toHaveBeenCalled();
  });

  it('should emit event on dragging an item', () => {
    spyOn(component.dragDropItems, 'emit');
    const items = [];
    const event = {previousIndex: 0, currentIndex: 1, previousContainer: {},
    container: {}, item: {},
    isPointerOverContainer: true,
    distance: {x: 3, y: 73}} as CdkDragDrop<string[]>;
    component.onDrop(event, items);
    expect(component.dragDropItems.emit).toHaveBeenCalled();
  });
});
