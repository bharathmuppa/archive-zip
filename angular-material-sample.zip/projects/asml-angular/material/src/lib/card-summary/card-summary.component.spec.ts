import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import {CommonModule} from '@angular/common';
import {MatBadgeModule} from '@angular/material/badge';
import {AALCommonComponentsModule} from '@asml-angular/common';

import {AALCardSummaryComponent} from './card-summary.component';
import {SharedMaterialModule} from '../shared/shared-material.module';
import {SharedFormModule} from '../shared/shared-form.module';
import {SharedModule} from '../shared/shared.module';
import {SharedFlexLayoutModule} from '../shared/shared-flex-layout.module';

describe('AALObjectDetailsComponent', () => {
  let component: AALCardSummaryComponent;
  let fixture: ComponentFixture<AALCardSummaryComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [AALCardSummaryComponent],
      imports: [
        CommonModule,
        SharedMaterialModule,
        SharedFormModule,
        AALCommonComponentsModule,
        SharedModule,
        SharedFlexLayoutModule,
        MatBadgeModule
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALCardSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call super method mainDescriptionClick on onLabelClick trigger ', () => {
    spyOn(component.mainDescriptionClick, 'emit');
    component.onLabelClick('sample Data test');
    expect(component.mainDescriptionClick.emit).toHaveBeenCalled();
  });
});
