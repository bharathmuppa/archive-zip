import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {AALCardSummaryComponent} from './card-summary.component';
import {AALCommonComponentsModule, AALCommonModule} from '@asml-angular/common';
import {FlexLayoutModule} from '@angular/flex-layout';
import {MatTooltipModule} from '@angular/material/tooltip';
import {MatButtonModule} from '@angular/material/button';

@NgModule({
  declarations: [AALCardSummaryComponent],
  imports: [
    CommonModule,
    AALCommonModule,
    AALCommonComponentsModule,
    MatButtonModule,
    MatTooltipModule,
    FlexLayoutModule
  ],
  exports: [
    AALCardSummaryComponent
  ]
})
export class AALCardSummaryModule {
}
