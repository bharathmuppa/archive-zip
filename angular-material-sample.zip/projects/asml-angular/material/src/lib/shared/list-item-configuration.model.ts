import {Info} from '@asml-angular/common';

export class ListItemConfiguration {
  ID?: string;
  title?: string;
  mainDescription: string;
  subDescription: string;
  icon?: string;
  imageURL?: string;
  svgIcon?: string;
  isClickable?: boolean;
  help?: Info;
  error?: Info;
  label?: string;
  labelCaption?: string;
  mainDescriptionCaption?: string;
  subDescriptionCaption?: string;
  imageURL2?: string;
  imageView?: string;
  separator?: string;
  actionButtonConfiguration?: ActionButtonConfiguration;
}

export class Category {
  TotlaItems: number;
  subCategories: CategoryItemConfiguration;
}

export class CategoryItemConfiguration {
  name: string;
  items: ListItemConfiguration[];
  constructor(name: string, items: ListItemConfiguration[]) {
    this.name = name;
    this.items = items;
  }
}


export class ActionButtonConfiguration {
  actionButtonIcon: string;
  actionButtonText: string;
  actionButtonType: string;
  actionButtonTooltip: string;
  showActionButton: boolean;
  action: string;
}

export class ActionEventData {
  ID: string;
  action: string;
}

export class SortingConfiguration {
  title: string;
  sortingHeaders: SortingHeaderConfiguration[];
}

export class SortingHeaderConfiguration {
  label: string;
  id: string;
  sortDesc?: string;
  direction?: string;
}
export type ImageView = 'circle' | 'full';

export enum ImageShapes {Circle = 'circle', Square = 'full'}

export type Separator = 'interpunct' | 'colon' | 'hyphen';

export enum Separators {Interpunct = 'interpunct', Colon = 'colon', Hyphen = 'hyphen', Parenthesis = 'parenthesis'}

export class OverLayTabbedItemConfiguration {
  TotalItems?: string;
  categories?: OverLayTabbedCategoriesConfiguration[];
}

export class OverLayTabbedCategoriesConfiguration {
  name?: string;
  totalAgendaItems?: number;
  'sub-categories'?: OverLayTabbedSubCategoriesConfiguration[];
}

export class OverLayTabbedSubCategoriesConfiguration {
  name?: string;
  items?: OverLaySubChildCategoriesConfiguration[];
}

export class OverLaySubChildCategoriesConfiguration {
  ID?: string;
  section?: string;
  plannedDuration?: string;
  startDateTime?: Date;
  agendaSequenceNumber?:number;
  isAOB?: boolean;
  purpose?: string;
  link?: OverLaySubItemChildCategoriesConfiguration;
}

export class OverLaySubItemChildCategoriesConfiguration {
  ID?: string;
  type?: string;
  title?: string;
  status?: string;
}
