import {ChangeDetectorRef, Component, EventEmitter, Input, OnInit, Output, ViewChild} from '@angular/core';
import {
  AALFixedInputFormControlComponent,
  AcceptedChange,
  HistoryService,
  Info,
  Modes,
  Statuses
} from '@asml-angular/common';
import {UntypedFormControl, UntypedFormGroup, ValidatorFn, Validators} from '@angular/forms';

@Component({
  template: ``
})
export class AALFixedInputCompositeFormControlComponent extends AALFixedInputFormControlComponent implements OnInit {
  @Input()
  valuesWhereSecondaryControlIsApplicable: any[];
  @Input()
  valuesWhereSecondaryControlIsMandatory: any[];
  @Input()
  layout: string;
  @Input()
  secondaryControl: UntypedFormControl;
  @Input()
  secondaryControlHelp: Info;
  @Input()
  secondaryControlID: string;

  @Input()
  set secondaryControlAlert(error: Info) {
    this.secondaryControlError = error;
    if (error && this.secondaryControlOldValue !== null) {
      this.secondaryControl.setValue(this.secondaryControlOldValue);
    }
  }

  get secondaryControlAlert(): Info {
    return this.secondaryControlError;
  }

  @Input()
  secondaryControlPlaceholder: string;
  @Input()
  secondaryControlMaxLength: number;
  @Input()
  secondaryControlMinLength: number;
  @Input()
  secondaryShowLengthHint: boolean;
  @Input()
  secondaryControlLabel: string;
  @Input()
  secondaryControlHint: number;
  @Input()
  secondaryControlIsHistoryEnabled: boolean;
  @Input()
  secondaryControlIsBusy: boolean;
  @Input()
  showResetIcon: boolean;
  @Input()
  hideSecondaryHelp: boolean;
  @Input()
  clearDescriptionOnControlValueChange: boolean;
  @Input()
  isSecondaryControlValueHTML: boolean;
  @Input()
  combineValueChangeEvents: boolean;
  @Output()
  revertSecondaryControlChanges: EventEmitter<any> = new EventEmitter();
  @Output()
  acceptSecondaryControlChanges: EventEmitter<any> = new EventEmitter();
  @Output()
  rejectSecondaryControlChanges: EventEmitter<any> = new EventEmitter();
  @ViewChild('secondaryControlElement', {static: false}) secondaryControlElement;
  showSecondaryControlElement: boolean;
  secondaryControlError: Info;
  secondaryControlOldValue: string;
  formGroup: UntypedFormGroup;
  historyServiceRef: HistoryService;
  compositeControlHelp: Info;
  compositeControlPlaceholder: string;
  controlValueChanged: boolean;

  constructor(historyService: HistoryService, private readonly ref: ChangeDetectorRef) {
    super(historyService);
    this.historyServiceRef = historyService;
    this.secondaryControlOldValue = null;
  }

  ngOnInit() {
    super.ngOnInit();
    this.secondaryControlIsHistoryEnabled = this.secondaryControlIsHistoryEnabled || false;
    this.formGroup = new UntypedFormGroup({
      control: this.control
    });
    this.updateFormGroup();
    this.setLayout();
    this.updateControlProperties();
  }

  setLayout() {
    if (!this.layout && this.options) {
      this.layout = this.options.length > 3 ? 'column' : 'row';
    }
  }

  setDefaultValue(): void {
    super.setDefaultValue();
  }

  resetControl() {
    this.control.setValue(null);
    this.secondaryControl.setValue('');
    this.showSecondaryControlElement = false;
    this.triggerAcceptChanges();
    this.updateFormGroup();
    if (this.secondaryControlElement) {
      this.secondaryControlElement.triggerAcceptChanges();
    }
  }

  isSecondaryControlApplicableForSelectedValue(): boolean {
    if (this.control.value && (!this.valuesWhereSecondaryControlIsApplicable || this.valuesWhereSecondaryControlIsApplicable.length > 0)) {
      if (!this.valuesWhereSecondaryControlIsApplicable) {
        return true;
      }
      // check if the selected value is string or Array
      if (typeof this.control.value === 'string') {
        return this.valuesWhereSecondaryControlIsApplicable.includes(this.control.value);
      } else {
        return this.valuesWhereSecondaryControlIsApplicable.filter((item) =>
          this.control.value.includes(item)).length > 0;
      }
    }
    return false;
  }

// does selected control value has secondary field required
  isSecondaryControlRequiredForSelectedValue(): boolean {
    if (this.control.value && this.valuesWhereSecondaryControlIsMandatory &&
      this.valuesWhereSecondaryControlIsMandatory.length > 0) {
      // check if the selected value is string or Array
      if (typeof this.control.value === 'string') {
        return this.valuesWhereSecondaryControlIsMandatory.includes(this.control.value);
      } else {
        return this.valuesWhereSecondaryControlIsMandatory.filter((item) =>
          this.control.value.includes(item)).length > 0;
      }
    }
    return false;
  }

  onClick(): void {
    super.onClick();

    if (this.control.value) {
      this.showSecondaryControlElement = this.isSecondaryControlApplicableForSelectedValue();
      this.showConfirmationToolbar = this.isSecondaryControlApplicableForSelectedValue();
      this.ref.detectChanges();
      this.updateFormGroup();
    }
    this.updateControlProperties();
  }

  onChange($event: Event): void {
    const prevShowSecondaryControlElement = this.showSecondaryControlElement;
    this.showSecondaryControlElement = this.isSecondaryControlApplicableForSelectedValue();
    this.showConfirmationToolbar = this.isSecondaryControlApplicableForSelectedValue();
    this.updateFormGroup();
    this.updateControlProperties();
    this.triggerAcceptChanges();
    this.mode = this.showSecondaryControlElement ? Modes.EDIT : Modes.READ;
    if (((prevShowSecondaryControlElement && !this.showSecondaryControlElement) ||
      this.clearDescriptionOnControlValueChange) && this.secondaryControlElement) {
      this.secondaryControl.setValue('');
      this.secondaryControlElement.triggerAcceptChanges();
    } else if (this.combineValueChangeEvents && this.status === Statuses.ACCEPTED) {
      // When secondaryControl is not present, only emit changes of the primary control
      this.acceptChanges.emit(new AcceptedChange(this.ID, this.newValue || this.control.value, this.oldValue));
      this.updateOldValue();
    }
    this.ref.detectChanges();
  }

  triggerAcceptChanges(): void {
    if (!this.isSecondaryControlRequiredForSelectedValue() && !this.combineValueChangeEvents) {
      // Call triggerAcceptChanges for the control as secondaryControl is not mandatory
      super.triggerAcceptChanges();
    } else if (!this.isSecondaryControlRequiredForSelectedValue() && this.combineValueChangeEvents) {
      // Send a flag to parent triggerAcceptChanges method to skip acceptChanges event, when secondaryControl is not mandatory
      super.triggerAcceptChanges(true);
    } else if (this.isSecondaryControlRequiredForSelectedValue()) {
      // Making a note that the control value has changed, but parent triggerAcceptChanges method has not been called
      this.controlValueChanged = true;
    }
  }

  updateOldValue() {
    const temp = this.newValue || this.control.value;
    const acceptedValue = typeof temp === 'object' ? JSON.parse(JSON.stringify(temp)) : temp;
    this.oldValue = typeof acceptedValue === 'object' ? JSON.parse(JSON.stringify(acceptedValue)) : acceptedValue;
    this.status = Statuses.DRAFT;
  }

  onSecondaryAcceptChanges($event?: AcceptedChange): void {
    if (this.isSecondaryControlRequiredForSelectedValue() && !this.combineValueChangeEvents) {
      super.triggerAcceptChanges();
    } else if (this.isSecondaryControlRequiredForSelectedValue() && this.combineValueChangeEvents) {
      // Send a flag to parent triggerAcceptChanges method to skip acceptChanges event
      super.triggerAcceptChanges(true);
    }
    if ($event && !this.combineValueChangeEvents) {
      this.secondaryControlOldValue = $event.oldValue;
      this.acceptSecondaryControlChanges.emit($event);
    } else if ($event && this.combineValueChangeEvents) {
      this.secondaryControlOldValue = $event.oldValue;
      if (this.status === Statuses.ACCEPTED) {
        // When both the control and secondaryControl values have changed, emit acceptChanges event with the updated values of both the controls
        this.acceptChanges.emit({
          control: new AcceptedChange(this.ID, this.newValue || this.control.value, this.oldValue),
          secondaryControl: new AcceptedChange($event.ID, $event.value, $event.oldValue)
        });
        this.updateOldValue();
      } else {
        // When only the secondaryControl value has changed, emit acceptChanges event with the updated values of the secondaryControl
        this.acceptChanges.emit(new AcceptedChange($event.ID, $event.value, $event.oldValue));
      }
    } else if (!$event && this.combineValueChangeEvents && this.status === Statuses.ACCEPTED) {
      // When only the control value has changed, emit acceptChanges event with the updated values of the control
      this.acceptChanges.emit(new AcceptedChange(this.ID, this.newValue || this.control.value, this.oldValue));
      this.updateOldValue();
    }
    this.mode = Modes.READ;
  }

  onSecondaryRejectChanges($event?: Event): void {
    if ($event && !this.combineValueChangeEvents) {
      this.rejectSecondaryControlChanges.emit($event);
    } else if ($event && this.combineValueChangeEvents) {
      // When rejectChanges for the secondaryControl was emitted, emit rejectChanges event with the updated values of the control
      this.rejectChanges.emit($event);
    } else if (!$event && this.combineValueChangeEvents && this.status === Statuses.ACCEPTED) {
      // When value of the control was changed and rejectChanges for secondaryControl was not emitted, emit acceptChanges event with the updated values of the control
      this.acceptChanges.emit(new AcceptedChange(this.ID, this.newValue || this.control.value, this.oldValue));
    } else if (!$event && this.controlValueChanged) {
      // Revert the value of the control as secondaryControl was mandatory and reject changes for the secondaryControl was not emitted
      this.control.setValue(this.oldValue);
      this.showSecondaryControlElement = this.isSecondaryControlRequiredForSelectedValue();
      this.controlValueChanged = false;
    }
    this.mode = Modes.READ;
  }

  triggerRejectChanges(): void {
    super.triggerRejectChanges();
    setTimeout(() => {
      this.control.setValue(this.oldValue);
    }, 1);
    this.updateControlProperties();
  }

  updateFormGroup(isMultiSelect = false): void {
    if (this.secondaryControl) {
      if (this.control.value && this.isSecondaryControlApplicableForSelectedValue()) {
        this.formGroup.addControl('secondaryControl', this.secondaryControl);
        this.secondaryControl.clearValidators();
        this.secondaryControl.setValidators(this.getApplicableValidators());
        this.secondaryControl.updateValueAndValidity();
        setTimeout(() => {
          if (this.secondaryControlElement) {
            this.secondaryControlElement.setFocusInInput();
          }
        }, 200);
      } else if (this.control.valid) {
        this.secondaryControl.clearValidators();
        this.secondaryControl.updateValueAndValidity();
        this.formGroup.removeControl('secondaryControl');
      }
    }
  }

  updateControlProperties() {
    this.updateHelp();
    this.updatePlaceholder();
  }

  updateHelp() {
    if (this.help) {
      this.compositeControlHelp = new Info((this.help as Info).message, (this.help as Info).title,
        (this.help as Info).animation, (this.help as Info).thumbnail, (this.help as Info).level);
    } else if (this.secondaryControlHelp) {
      this.compositeControlHelp = new Info((this.secondaryControlHelp as Info).message,
        (this.secondaryControlHelp as Info).title, (this.secondaryControlHelp as Info).animation,
        (this.secondaryControlHelp as Info).thumbnail, (this.secondaryControlHelp as Info).level);
    }

    if (this.mode !== Modes.EDIT && this.isSecondaryControlApplicableForSelectedValue() && this.help && this.secondaryControlHelp) {
      this.compositeControlHelp.message = `${(this.help as Info).message} <br/><br/> ${(this.secondaryControlHelp as Info).message}`;
    }
  }

  updatePlaceholder() {
    if (this.placeholder) {
      this.compositeControlPlaceholder = this.placeholder;
    } else if (this.secondaryControlPlaceholder) {
      this.compositeControlPlaceholder = this.secondaryControlPlaceholder;
    }
    if (this.mode !== Modes.EDIT && this.isSecondaryControlApplicableForSelectedValue() &&
      this.placeholder && this.secondaryControlPlaceholder) {
      this.compositeControlPlaceholder = `${this.placeholder}, ${this.secondaryControlPlaceholder}`;
    }
  }

  getApplicableValidators(): ValidatorFn [] {
    const maxLengthValidator = (this.secondaryControlMaxLength && this.secondaryControlMaxLength > 0) ?
      [Validators.maxLength(this.secondaryControlMaxLength)] : [];
    const minLengthValidator = (this.secondaryControlMinLength && this.secondaryControlMinLength > 0) ?
      [Validators.minLength(this.secondaryControlMinLength)] : [];
    const requiredValidator = (this.isSecondaryControlRequiredForSelectedValue()) ? [Validators.required] : [];
    return [...maxLengthValidator, ...minLengthValidator, ...requiredValidator];
  }

  controlTabbedOut() {
    /*
    * The below piece of code is added to save the control and secondaryControl changes when the control loses focus
    */
    if (this.control.invalid || this.secondaryControl.invalid) {
      // Revert the changes if either control or secondaryControl values are invalid
      this.triggerRejectChanges();
    } else if (this.control.valid && this.secondaryControl.valid && this.combineValueChangeEvents) {
      if (this.oldValue !== this.control.value && this.secondaryControlOldValue !== this.secondaryControl.value) {
        // Emit acceptChanges with both control and secondaryControl values, when both control and secondaryControl values have changed
        this.acceptChanges.emit({
          control: new AcceptedChange(this.ID, this.newValue || this.control.value, this.oldValue),
          secondaryControl: new AcceptedChange(this.secondaryControlID, this.secondaryControl.value, this.secondaryControlOldValue)
        });
        this.secondaryControlOldValue = this.secondaryControl.value;
        this.updateOldValue();
        this.mode = this.lockMode ? this.lockMode : Modes.READ;
      } else if (this.oldValue !== this.control.value) {
        // Call triggerAcceptChanges when only control value has changed
        super.triggerAcceptChanges();
        this.updateOldValue();
        this.mode = this.lockMode ? this.lockMode : Modes.READ;
      } else if (this.secondaryControlOldValue !== this.secondaryControl.value) {
        // Emit acceptChanges with secondaryControl values, when only secondaryControl value has changed
        this.acceptChanges.emit(new AcceptedChange(this.secondaryControlID, this.secondaryControl.value, this.secondaryControlOldValue));
        this.secondaryControlOldValue = this.secondaryControl.value;
        this.mode = this.lockMode ? this.lockMode : Modes.READ;
      }
    } else if (this.control.valid && this.secondaryControl.valid && !this.combineValueChangeEvents) {
      if (this.oldValue !== this.control.value && this.secondaryControlOldValue !== this.secondaryControl.value) {
        // Call triggerAcceptChange for both the control and secondaryControl, when both control and secondaryControl value changed
        if (this.secondaryControlElement) {
          this.secondaryControlElement.triggerAcceptChanges();
        }
        super.triggerAcceptChanges();
        this.secondaryControlOldValue = this.secondaryControl.value;
        this.updateOldValue();
        this.mode = this.lockMode ? this.lockMode : Modes.READ;
      } else if (this.oldValue !== this.control.value) {
        // Call triggerAcceptChanges when only control value has changed
        super.triggerAcceptChanges();
        this.updateOldValue();
        this.mode = this.lockMode ? this.lockMode : Modes.READ;
      } else if (this.secondaryControlOldValue !== this.secondaryControl.value) {
        // Call secondaryControl triggerAcceptChanges when only secondaryControl value has changed
        this.secondaryControlElement.triggerAcceptChanges();
        this.secondaryControlOldValue = this.secondaryControl.value;
        this.mode = this.lockMode ? this.lockMode : Modes.READ;
      }
    }
  }
}
