import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {AALCommonComponentsModule} from '@asml-angular/common';
import {AALOverlayCardHelpModule} from '../overlay-card-help/overlay-card-help.module';
import {AALToolbarConfirmModule} from '../toolbar-confirm/toolbar-confirm.module';
import {AALOverlayCardErrorModule} from '../overlay-card-alert/overlay-card-alert.module';
import {AALFixedInputCompositeFormControlComponent} from './fixed-input-composite-form-control.component';

@NgModule({
  declarations: [
    AALFixedInputCompositeFormControlComponent
  ],
  imports: [
    CommonModule,
    AALCommonComponentsModule,
    AALOverlayCardHelpModule,
    AALOverlayCardErrorModule,
    AALToolbarConfirmModule
  ],
  exports: [
    AALCommonComponentsModule,
    AALOverlayCardHelpModule,
    AALOverlayCardErrorModule,
    AALToolbarConfirmModule
  ]
})
export class SharedModule {
}
