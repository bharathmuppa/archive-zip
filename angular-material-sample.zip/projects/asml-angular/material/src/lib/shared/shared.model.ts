import {
  BadgePosition,
  BadgeSize,
  ButtonType,
  IconSize,
  ThemeColor
} from '@asml-angular/common/lib/models/enumeration.model';

export class ButtonConfiguration {
  icon: string;
  svgIcon: string;
  image: string;
  name: string;
  color: ThemeColor;
  tooltip?: string;
  hasBadge?: boolean;
  badgeData?: number;
  referenceBadgeData?: number;
  disabled?: boolean;
  iconSize?: IconSize;
  badgeColor?: ThemeColor;
  isBadgeDisabled?: boolean;
  badgePosition?: BadgePosition;
  badgeSize: BadgeSize;
  hasSeparatorAfter: boolean;
  type: ButtonType;
}
