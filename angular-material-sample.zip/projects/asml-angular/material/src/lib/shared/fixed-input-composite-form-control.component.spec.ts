import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import {AALFixedInputFormControlComponent, AcceptedChange, Info, InfoLevels, Statuses} from '@asml-angular/common';
import {UntypedFormControl, Validators} from '@angular/forms';

import {AALFixedInputCompositeFormControlComponent} from './fixed-input-composite-form-control.component';

describe('FixedInputFormControlComponent', () => {
  let component: AALFixedInputCompositeFormControlComponent;
  let fixture: ComponentFixture<AALFixedInputCompositeFormControlComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [AALFixedInputCompositeFormControlComponent]
    }).compileComponents().then(() => {
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALFixedInputCompositeFormControlComponent);
    component = fixture.componentInstance;
    component.control = new UntypedFormControl('actual val', Validators.compose([
      Validators.required
    ]));
    component.secondaryControl = new UntypedFormControl('actual val', Validators.compose([]));
    component.help = new Info('Sample Title', 'Sample Help Message', '', '', null);
    component.options = [
      {name: 'abc', label: 'Abc', sequence: 1, isDescriptionAvailable: true},
      {name: 'xyz', label: 'Xyz', sequence: 2, isDescriptionAvailable: false}
    ];
    fixture.detectChanges();
  });

  afterEach(() => {
    jasmine.clock().uninstall();
  });


  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set row layout', () => {
    component.options = [
      {name: 'abc', label: 'Abc'},
      {name: 'xyz', label: 'Xyz'},
      {name: 'xyz', label: 'Xyz'}
    ];
    component.layout = undefined;
    component.setLayout();
    expect(component.layout).toBe('row');
  });

  it('should set column layout', () => {
    component.options = [
      {name: 'abc', label: 'Abc'},
      {name: 'xyz', label: 'Xyz'},
      {name: 'xyz', label: 'Xyz'},
      {name: 'xyz', label: 'Xyz'}
    ];
    component.layout = undefined;
    component.setLayout();
    expect(component.layout).toBe('column');
  });

  it('should check if secondary control is applicable when single option selected', () => {
    component.control.setValue('option2');
    component.valuesWhereSecondaryControlIsApplicable = ['option2', 'option3'];
    component.onClick();
    expect(component.showSecondaryControlElement).toBe(true);
    expect(component.showConfirmationToolbar).toBe(true);
  });

  it('should check if secondary control is not applicable on click when single option selected', () => {
    component.control.setValue('option1');
    component.valuesWhereSecondaryControlIsApplicable = ['option2', 'option3'];
    component.onClick();
    expect(component.showSecondaryControlElement).toBe(false);
    expect(component.showConfirmationToolbar).toBe(false);
  });

  it('should check if secondary control is applicable when Multi selected', () => {
    component.control.setValue(['option2', 'option3']);
    component.valuesWhereSecondaryControlIsApplicable = ['option2', 'option3'];
    component.onClick();
    expect(component.showSecondaryControlElement).toBe(true);
    expect(component.showConfirmationToolbar).toBe(true);
  });

  it('should check if secondary control is not applicable on click when Multi selected', () => {
    component.control.setValue(['option1', 'option3']);
    component.valuesWhereSecondaryControlIsApplicable = ['option2'];
    component.onClick();
    expect(component.showSecondaryControlElement).toBe(false);
    expect(component.showConfirmationToolbar).toBe(false);
  });

  it('should check if secondary control is Required when Multiple changes Rejected', () => {
    enum Modes {
      EDIT = 'EDIT',
      READ = 'READ'
    }
    spyOn(AALFixedInputFormControlComponent.prototype, 'triggerAcceptChanges');
    component.control.setValue(['option2', 'option3']);
    component.valuesWhereSecondaryControlIsApplicable = ['option2', 'option3'];
    component.mode = Modes.READ;
    component.triggerAcceptChanges();
    expect(AALFixedInputFormControlComponent.prototype.triggerAcceptChanges).toHaveBeenCalled();
  });

  it('should check if secondary control is Required when single changes accepted', () => {
    spyOn(component, 'triggerAcceptChanges').and.callThrough();
    component.control.setValue('option2');
    component.valuesWhereSecondaryControlIsMandatory = ['option3'];
    component.triggerAcceptChanges();
    expect(component.triggerAcceptChanges).toHaveBeenCalled();
  });
  it('should call onChanges function', () => {
    spyOn(component, 'onChange').and.callThrough();
    component.onChange(new Event(''));
    expect(component.onChange).toHaveBeenCalled();
  });

  it('should revert the secondary control when change happens', () => {
    component.control.setValue(['option1']);
    component.secondaryControlElement = {
      triggerAcceptChanges: () => {},
      setFocusInInput: () => {}
    };
    const spy = spyOn(component.secondaryControlElement, 'triggerAcceptChanges');
    component.valuesWhereSecondaryControlIsApplicable = ['option2'];
    component.showSecondaryControlElement = true;
    component.onChange(new Event(''));
    expect(spy).toHaveBeenCalled();
  });

  it('should call onSecondaryAcceptChanges function', () => {
    component.control.setValue(['option2', 'option3']);
    component.valuesWhereSecondaryControlIsMandatory = ['option3'];
    spyOn(component.acceptSecondaryControlChanges, 'emit');
    component.onSecondaryAcceptChanges({value: 'test', oldValue: 'old', ID: '123'});
    expect(component.acceptSecondaryControlChanges.emit).toHaveBeenCalled();
  });

  it('should call onSecondaryRejectChanges function', () => {
    component.oldValue = 'old value';
    spyOn(component.rejectSecondaryControlChanges, 'emit');
    component.onSecondaryRejectChanges(new Event('click'));
    expect(component.rejectSecondaryControlChanges.emit).toHaveBeenCalled();
  });

  it('should accept changes for resetControl function', () => {
    component.control = new UntypedFormControl('');
    component.control.setValue('');
    component.resetControl();
    expect(component.showSecondaryControlElement ).toBe(false);
  });

  it('should call function triggerRejectChanges in updatePlaceholder for compositeControlPlaceholder', () => {
    component.placeholder = 'sample placeholder text';
    component.triggerRejectChanges();
    expect(component.compositeControlPlaceholder).toBe('sample placeholder text');
  });

  it('should call function triggerRejectChanges in updatePlaceholder for compositeControlPlaceholder', () => {
    component.secondaryControlPlaceholder = 'sample placeholder text';
    component.triggerRejectChanges();
    expect(component.compositeControlPlaceholder ).toBe('sample placeholder text');
  });

  it('should call function triggerRejectChanges in updateHelp for compositeControlHelp', () => {
    component.help = '';
    component.secondaryControlHelp = new Info('help title', 'help message', '', '', '');
    component.triggerRejectChanges();
    expect(component.compositeControlHelp.title).toBe('help message');
  });

  it('should call function triggerRejectChanges in updateHelp for compositeControlHelp', () => {
    component.secondaryControlHelp = new Info('help title', 'help message', '', '', '');
    component.triggerRejectChanges();
    expect(component.compositeControlHelp.message).toContain('Sample Title');
  });

  it('should call function triggerRejectChanges in updateHelp for compositeControlHelp placeholder ', () => {
    component.secondaryControlPlaceholder = 'secondary placeholder';
    component.placeholder = 'placeholder';
    component.triggerRejectChanges();
    expect(component.compositeControlPlaceholder).toBe('placeholder, secondary placeholder');
  });

  it('should call validator function getApplicableValidators', () => {
    component.control = new UntypedFormControl('', Validators.required);
    component.control.setValue(1234);
    component.secondaryControlMaxLength = 1234;
    component.secondaryControlMinLength = 1234;
    const returnValue = component.getApplicableValidators();
    expect(returnValue.length).toBe(2);
  });
  it ('should save the secondary control old value when it has error', () => {
    component.secondaryControl = new UntypedFormControl('');
    component.secondaryControl.setValue('description');
    component.secondaryControlAlert = new Info('error message ', null, null, null, InfoLevels.ERROR);
    expect(component.secondaryControlOldValue).toBe(null);
  });

  it('should revert control to oldValue, when resetControl is triggered and control value is invalid', () => {
    component.secondaryControl.setValue('Test');
    component.secondaryControlElement = {
      triggerAcceptChanges: () => {},
      setFocusInInput: () => {}
    };
    component.control.setValidators(Validators.required);
    component.resetControl();
    expect(component.control.value).toEqual('actual val');
  });

  it('should emit acceptChanges when, onChange is triggered, only control value has changed and combineValueChangeEvents is set', () => {
    const spy = spyOn(component.acceptChanges, 'emit');
    component.control.setValue('option 1');
    component.combineValueChangeEvents = true;
    component.onChange({} as Event);
    expect(spy).toHaveBeenCalled();
  });

  it('should set controlValueChanged when, triggerAcceptChanges is triggered and isSecondaryControlRequiredForSelectedValue is true', () => {
    component.valuesWhereSecondaryControlIsMandatory = ['option 2'];
    component.valuesWhereSecondaryControlIsApplicable = ['option 2', 'option 3'];
    component.control.setValue('option 2');
    component.combineValueChangeEvents = true;
    component.onChange({} as Event);
    expect(component.controlValueChanged).toEqual(true);
  });

  it('should emit combined acceptChanges event when, onSecondaryAcceptChanges is triggered, both control and secondaryControl values have changed and combineValueChangeEvents is set', () => {
    const spy = spyOn(component.acceptChanges, 'emit');
    component.ID = 'control';
    component.control.setValue('option 2');
    component.valuesWhereSecondaryControlIsMandatory = ['option 2'];
    component.valuesWhereSecondaryControlIsApplicable = ['option 2', 'option 3'];
    component.combineValueChangeEvents = true;
    component.onSecondaryAcceptChanges({ID: 'secondaryControl', value: 't1', oldValue: 't2'});
    expect(spy).toHaveBeenCalledWith({ control: new AcceptedChange('control', 'option 2', 'actual val'), secondaryControl: new AcceptedChange('secondaryControl', 't1', 't2')});
  });

  it('should emit acceptChanges event when, onSecondaryAcceptChanges is triggered, secondaryControl value has changed and combineValueChangeEvents is set', () => {
    const spy = spyOn(component.acceptChanges, 'emit');
    component.combineValueChangeEvents = true;
    component.onSecondaryAcceptChanges({ID: 'secondaryControl', value: 't1', oldValue: 't2'});
    expect(spy).toHaveBeenCalledWith(new AcceptedChange('secondaryControl', 't1', 't2'));
  });

  it('should emit acceptChanges event when, onSecondaryAcceptChanges is triggered, control value has changed and combineValueChangeEvents is set', () => {
    const spy = spyOn(component.acceptChanges, 'emit');
    component.ID = 'control';
    component.control.setValue('option 2');
    component.valuesWhereSecondaryControlIsMandatory = ['option 2'];
    component.valuesWhereSecondaryControlIsApplicable = ['option 2', 'option 3'];
    component.combineValueChangeEvents = true;
    component.onSecondaryAcceptChanges();
    expect(spy).toHaveBeenCalledWith(new AcceptedChange('control', 'option 2', 'actual val'));
  });

  it('should emit rejectChanges event when, onSecondaryRejectChanges is triggered and secondaryControl rejectChanges was emitted', () => {
    const spy = spyOn(component.rejectChanges, 'emit');
    component.combineValueChangeEvents = true;
    component.onSecondaryRejectChanges(new Event(''));
    expect(spy).toHaveBeenCalledWith(new Event(''));
  });

  it('should emit acceptChanges event when, onSecondaryRejectChanges is triggered and control value has changed', () => {
    const spy = spyOn(component.acceptChanges, 'emit');
    component.ID = 'control';
    component.control.setValue('option 2');
    component.status = Statuses.ACCEPTED;
    component.combineValueChangeEvents = true;
    component.onSecondaryRejectChanges();
    expect(spy).toHaveBeenCalledWith(new AcceptedChange('control', 'option 2', 'actual val'));
  });

  it('should revert control value when, onSecondaryRejectChanges is triggered and controlValueChanged is set', () => {
    component.oldValue = 'old';
    component.control.setValue('option 2');
    component.controlValueChanged = true;
    component.onSecondaryRejectChanges();
    expect(component.control.value).toEqual('old');
  });

  it('should set secondaryControl value when, secondaryControlAlert is set', () => {
    component.secondaryControlOldValue = 'old';
    component.secondaryControlAlert = new Info('test');
    expect(component.secondaryControl.value).toEqual('old');
  });

  it('should call triggerRejectChanges when, controlTabbedOut is triggered & either the control or secondary control is invalid', () => {
    component.secondaryControl = new UntypedFormControl(null, [Validators.required]);
    const spy = spyOn(component, 'triggerRejectChanges');
    component.controlTabbedOut();
    expect(spy).toHaveBeenCalled();
  });

  it('should emit acceptChanges with both control & secondaryControl values when, controlTabbedOut is triggered, combineValueChangeEvents is true & both control & secondaryControl values changed', () => {
    component.oldValue = 'test';
    component.secondaryControlOldValue = 'secondary';
    component.combineValueChangeEvents = true;
    const spy = spyOn(component.acceptChanges, 'emit');
    component.controlTabbedOut();
    expect(spy).toHaveBeenCalled();
  });

  it('should call parent triggerAcceptChanges when, controlTabbedOut is triggered, combineValueChangeEvents is true & only control value changed', () => {
    component.oldValue = 'test';
    component.secondaryControlOldValue = 'actual val';
    component.combineValueChangeEvents = true;
    const spy = spyOn(AALFixedInputFormControlComponent.prototype, 'triggerAcceptChanges');
    component.controlTabbedOut();
    expect(spy).toHaveBeenCalled();
  });

  it('should emit acceptChanges with secondaryControl value when, controlTabbedOut is triggered, combineValueChangeEvents is true & only secondaryControl value changed', () => {
    component.oldValue = 'actual val';
    component.secondaryControlOldValue = 'secondary';
    component.combineValueChangeEvents = true;
    const spy = spyOn(component.acceptChanges, 'emit');
    component.controlTabbedOut();
    expect(spy).toHaveBeenCalled();
  });

  it('should call parent triggerAcceptChanges & secondaryControl triggerAcceptChanges when, controlTabbedOut is triggered, combineValueChangeEvents is false & both control & secondaryControl values changed', () => {
    component.oldValue = 'test';
    component.secondaryControlOldValue = 'secondary';
    component.combineValueChangeEvents = false;
    component.secondaryControlElement = {
      triggerAcceptChanges: () => {},
      setFocusInInput: () => {}
    };
    const spy = spyOn(AALFixedInputFormControlComponent.prototype, 'triggerAcceptChanges');
    component.controlTabbedOut();
    expect(spy).toHaveBeenCalled();
  });

  it('should call parent triggerAcceptChanges when, controlTabbedOut is triggered, combineValueChangeEvents is false and only control value changed', () => {
    component.oldValue = 'test';
    component.secondaryControlOldValue = 'actual val';
    component.combineValueChangeEvents = false;
    const spy = spyOn(AALFixedInputFormControlComponent.prototype, 'triggerAcceptChanges');
    component.controlTabbedOut();
    expect(spy).toHaveBeenCalled();
  });

  it('should call secondaryControl triggerAcceptChanges when, controlTabbedOut is triggered, combineValueChangeEvents is false & only secondaryControl value has changed', () => {
    component.oldValue = 'actual val';
    component.secondaryControlOldValue = 'secondary';
    component.combineValueChangeEvents = false;
    component.secondaryControlElement = {
      triggerAcceptChanges: () => {},
      setFocusInInput: () => {}
    };
    const spy = spyOn(component.secondaryControlElement, 'triggerAcceptChanges');
    component.controlTabbedOut();
    expect(spy).toHaveBeenCalled();
  });
});
