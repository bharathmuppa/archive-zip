import {AfterViewInit, Component, Input, OnInit, Renderer2} from '@angular/core';
import {AALUtil, HistoryService} from '@asml-angular/common';
import {AALDatePickerWeekComponent} from '../date-picker-week/date-picker-week.component';
import {UntypedFormControl} from '@angular/forms';
import {formatDate} from '@angular/common';

@Component({
  selector: 'aal-date-picker-select',
  templateUrl: './date-picker-select.component.html',
  styleUrls: ['./date-picker-select.component.scss']
})
export class AALDatePickerSelectComponent extends AALDatePickerWeekComponent implements OnInit, AfterViewInit {
  beginDate: Date;
  selectedValue: any;
  dateRangeFormat: string;
  isSelectedOptionAvailable: boolean;
  onChangeDateDisableOptionAvailable: boolean;
  @Input()
  type: string;

  get control() {
    return this.frmControl;
  }

  @Input()
  set control(val: UntypedFormControl) {
    this.frmControl = val;
    if (val) {
      this.oldValue = (typeof val.value === 'object' ? JSON.parse(JSON.stringify(val.value)) : val.value);
    }
    if (!val.value) {
      this.selectedValue = null;
    }
  }

  constructor(renderer: Renderer2, historyService: HistoryService) {
    super(renderer, historyService);
  }

  ngOnInit() {
    if (this.control && this.control.value) {
      if (this.type === 'range' && this.control.value) {
        this.datePickerSelection = this.control.value;
        const controlEndDate = (this.control.value.end) ? new Date(this.control.value.end) : new Date();
        this.selectedValue = controlEndDate;
        this.isSelectedOptionAvailable = false;
        this.onChangeDateDisableOptionAvailable = false;
      } else {
        this.selectedValue = AALUtil.setDateDefaultTime(this.control.value);
        if (!this.listValueSelected) {
          this.datePickerSelection = this.selectedValue;
        }
      }
    }
    super.ngOnInit();
  }

  ngAfterViewInit() {
    if (this.type === 'range' && this.control && this.control.value) {
      const controlEndDate = (this.control.value.end) ? new Date(this.control.value.end) : new Date();
      const endDate = this.endDateForm.find(item => (item.date.getDate() === controlEndDate.getDate() && item.date.getMonth() === controlEndDate.getMonth() && item.date.getFullYear() === controlEndDate.getFullYear()));
      if (endDate) {
        this.onChangeDateDisableOptionAvailable = true;
        this.isSelectedOptionAvailable = true;
        this.selectedValue = endDate.date;
      } else {
        this.isSelectedOptionAvailable = false;
        this.selectedValue = this.control.value;
      }
    }
  }

  onChange($event?: Event) {
    if (this.type === 'range' && this.control.value) {
      const isoDateObject = {
        begin: AALUtil.getDateInISOFormat(this.control.value.begin),
        end: AALUtil.getDateInISOFormat(this.control.value.end)
      };
      this.control.setValue(isoDateObject);
    } else {
      this.control.setValue(AALUtil.getDateInISOFormat(this.control.value));
    }
    this.onChangeDateDisableOptionAvailable = true;
    super.onChange($event);
  }

  changeDateFormat(event, dateType) {
    if (event.value) {
      if (this.type === 'range' && !(event.value.begin) && dateType === 'noStartEnd') {
        this.control.setValue({
          begin: this.isPastDateRange ? event.value : this.today,
          end: this.isPastDateRange ? this.today : event.value
        });
        this.datePickerSelection = this.control.value;
        const endDate = this.endDateForm.find(item => (item.date.getDate() === event.value.getDate() && item.date.getMonth() === event.value.getMonth() && item.date.getFullYear() === event.value.getFullYear()));
        this.selectedValue = endDate.date;
      } else {
        if (dateType === 'start') {
          this.beginDate = event.value;
        } else if (dateType === 'end') {
          this.control.setValue({
            begin: this.beginDate,
            end: event.value
          });
          this.selectedValue = this.control.value;
          this.datePickerSelection = this.control.value;
        } else {
          this.control.setValue(event.value);
          this.selectedValue = this.control.value;
          this.datePickerSelection = this.control.value;
        }
        const format = 'MMM dd, YYYY';
        const locale = 'en-US';
        if (this.datePickerSelection.begin) {
          this.dateRangeFormat = formatDate(this.datePickerSelection.begin, format, locale) + ' — ' +
            formatDate(this.datePickerSelection.end, format, locale);
        }
      }
    } else {
      this.control.setValue('');
    }
  }

  onClick(): void {
    super.setModeToEdit();
    if (this.type === 'range') {
      setTimeout(() => {
        if (this.selectField && this.selectField.trigger) {
          this.selectField.trigger.nativeElement.click();
        }
      }, 100);
    }
  }
}
