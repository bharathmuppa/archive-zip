import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import {AALCommonComponentsModule, AALUtil} from '@asml-angular/common';
import {UntypedFormControl, Validators} from '@angular/forms';
import {CommonModule} from '@angular/common';
import {MatDatepickerModule} from '@angular/material/datepicker';
import {ElementRef} from '@angular/core';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';

import {SharedMaterialModule} from '../shared/shared-material.module';
import {SharedFormModule} from '../shared/shared-form.module';
import {SharedModule} from '../shared/shared.module';
import {SharedFlexLayoutModule} from '../shared/shared-flex-layout.module';
import {AALDatePickerSelectComponent} from './date-picker-select.component';
import {AALDatePickerWeekComponent} from '../date-picker-week/date-picker-week.component';

describe('AALDatePickerSelectComponent', () => {
  let component: AALDatePickerSelectComponent;
  let fixture: ComponentFixture<AALDatePickerSelectComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ AALDatePickerSelectComponent ],
      imports: [CommonModule,
        SharedMaterialModule,
        SharedFormModule,
        AALCommonComponentsModule,
        SharedModule,
        SharedFlexLayoutModule,
        MatDatepickerModule,
        BrowserAnimationsModule]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALDatePickerSelectComponent);
    component = fixture.componentInstance;
    component.control = new UntypedFormControl(new Date(), Validators.compose([
      Validators.required
    ]));
    fixture.detectChanges();
    jasmine.clock().uninstall();
  });

  it('should create ', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize component (ngOnInit) and default date selected should to current date', () => {
    const today = new Date();
    component.control.setValue(today);
    component.ngOnInit();
    expect(component.datePickerSelection).toEqual(AALUtil.setDateDefaultTime(today));
  });

  it('should set isSelectedOptionAvailable as false, when ngAfterViewInit is triggered and endDate does not exist', () => {
    const today = new Date();
    component.control.setValue(today);
    component.type = 'range';
    component.ngAfterViewInit();
    expect(component.isSelectedOptionAvailable).toEqual(false);
  });

  it('should set isSelectedOptionAvailable as true, when ngAfterViewInit is triggered and endDate exists', () => {
    const today = new Date(2021, 6, 17);
    component.control.setValue({end: today});
    component.type = 'range';
    component.endDateForm = [{date: today, name: ''}];
    component.ngAfterViewInit();
    expect(component.isSelectedOptionAvailable).toEqual(true);
  });

  it('should set selectedValue, when changeDateFormat trigger with dateType as noStartEnd', () => {
    component.type = 'range';
    component.today = new Date(2021, 6);
    component.endDateForm = [{date: new Date(2021, 6), name: ''}];
    component.changeDateFormat({
      value: new Date(2021, 6)
    }, 'noStartEnd');
    expect(component.selectedValue).toEqual(new Date(2021, 6));
  });

  it('should set beginDate, when changeDateFormat trigger with dateType as start', () => {
    component.type = 'range';
    component.changeDateFormat({
      value: new Date(2021, 6)
    }, 'start');
    expect(component.beginDate).toEqual(new Date(2021, 6));
  });

  it('should set datePickerSelection, when changeDateFormat trigger with dateType as end', () => {
    component.type = 'range';
    component.beginDate = new Date(2021, 6);
    component.changeDateFormat({
      value: new Date(2021, 7)
    }, 'end');
    expect(component.datePickerSelection).toEqual({begin: new Date(2021, 6), end: new Date(2021, 7)});
  });

  it('should set control value, when changeDateFormat trigger with dateType as noStartEnd', () => {
    component.changeDateFormat({
      value: new Date(2021, 7)
    }, 'noStartEnd');
    expect(component.control.value).toEqual(new Date(2021, 7));
  });

  it('should set null value to control when ChangeDateFormat is trigger', () => {
    component.changeDateFormat({}, 'start');
    fixture.detectChanges();
    expect(component.control.value).toEqual('');
  });

  it('should verify selectedValue when control is set with valid Date Object for Begin and End', () => {
    component.type = 'range';
    component.control.setValue({begin: new Date(), end: new Date()});
    component.ngOnInit();
    expect(new Date(component.selectedValue).getDate()).toBe(new Date().getDate());
  });

  it('should call onChange of super Component', () => {
    spyOn(AALDatePickerWeekComponent.prototype, 'onChange');
    component.type = 'range';
    component.control.setValue({begin: new Date(), end: new Date()});
    component.onChange(new Event(''));
    expect(new Date(component.control.value.begin).getDate()).toBe(new Date().getDate());
    expect(AALDatePickerWeekComponent.prototype.onChange).toHaveBeenCalled();
  });

  it('should set control current date when type is null when onChange is trigger', () => {
    component.type = '';
    component.onChange(new Event(''));
    expect(new Date(component.control.value).getDate()).toBe(new Date().getDate());
  });

  it('should set current date when type is set when ChangeDateFormat is trigger', () => {
      component.type = 'range';
      component.today = new Date();
      const event = {value: new Date()};
      component.changeDateFormat(event, 'start');
      expect(new Date(component.selectedValue).getDate()).toBe(new Date().getDate());
  });

  it('should open optionsPanel, when onClick is triggered', () => {
    component.type = 'range';
    component.selectField = {
      trigger: new ElementRef<any>({
        click: () => {
        }
      })
    };
    const spy = spyOn(component.selectField.trigger.nativeElement, 'click').and.callFake(() => {
    });
    jasmine.clock().install();
    component.onClick();
    jasmine.clock().tick(300);
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
    jasmine.clock().uninstall();
  });
});
