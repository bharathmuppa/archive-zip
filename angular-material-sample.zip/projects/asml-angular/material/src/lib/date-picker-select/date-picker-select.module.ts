import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {AALDatePickerSelectComponent} from './date-picker-select.component';
import {AALCommonComponentsModule, AALCommonModule} from '@asml-angular/common';
import {MatDatepickerModule} from '@angular/material/datepicker';
import {MatNativeDateModule} from '@angular/material/core';
import {AALDatePickerWeekModule} from '../date-picker-week/date-picker-week.module';
import {FlexLayoutModule} from '@angular/flex-layout';
import {AALOverlayCardHelpModule} from '../overlay-card-help/overlay-card-help.module';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import {MatInputModule} from '@angular/material/input';
import {MatSelectModule} from '@angular/material/select';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {MatTooltipModule} from '@angular/material/tooltip';
import {AALOverlayCardErrorModule} from '../overlay-card-alert/overlay-card-alert.module';

@NgModule({
  declarations: [AALDatePickerSelectComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    AALCommonModule,
    AALCommonComponentsModule,
    AALOverlayCardErrorModule,
    AALOverlayCardHelpModule,
    MatDatepickerModule,
    MatInputModule,
    MatNativeDateModule,
    MatProgressSpinnerModule,
    MatTooltipModule,
    MatSelectModule,
    AALDatePickerWeekModule,
    FlexLayoutModule
  ],
  exports: [AALDatePickerSelectComponent]
})
export class AALDatePickerSelectModule {
}
