/*
 * Public API Surface of material
 */

export * from './input-number.component';
export * from './input-number.module';
