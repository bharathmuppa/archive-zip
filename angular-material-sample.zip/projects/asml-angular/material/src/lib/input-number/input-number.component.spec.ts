import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import {CommonModule} from '@angular/common';
import {UntypedFormControl, Validators} from '@angular/forms';
import {AALInputFormControlComponent} from '@asml-angular/common';

import {SharedMaterialModule} from '../shared/shared-material.module';
import {SharedFormModule} from '../shared/shared-form.module';
import {SharedFlexLayoutModule} from '../shared/shared-flex-layout.module';
import {SharedModule} from '../shared/shared.module';
import {AALInputNumberComponent} from './input-number.component';
import createSpyObj = jasmine.createSpyObj;

describe('AALInputNumberComponent', () => {
  let component: AALInputNumberComponent;
  let fixture: ComponentFixture<AALInputNumberComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [AALInputNumberComponent],
      imports: [CommonModule,
        SharedMaterialModule,
        SharedFormModule,
        SharedModule,
        SharedFlexLayoutModule],
    }).compileComponents().then(() => {
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALInputNumberComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    component.control = new UntypedFormControl('actualVal', Validators.compose([]));
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize regex when we have input pattern', () => {
    component.validationPattern = '^\d{1,5}$';
    component.ngOnInit();
    expect(component.regex).toEqual(/^d{1,5}$/);
  });

  it('should not initialize validation regex when there is no input pattern', () => {
    component.validationPattern = '';
    expect(component.regex).toEqual(/^-?\d+$/);
  });

  it('should initialize regex when we have fraction digits with negative numbers', () => {
    component.fractionDigits = 2;
    component.allowNegative = true;
    component.ngOnInit();
    expect(component.regex).toEqual(new RegExp('^\\s*-?\\s*(?=.*[0-9])\\d*(?:\\.\\d{1,2})?\\s*$'));
  });

  it('should initialize regex when we have fraction digits with positive numbers', () => {
    component.fractionDigits = 2;
    component.allowNegative = false;
    component.ngOnInit();
    expect(component.regex).toEqual(new RegExp('^\\s*(?=.*[0-9])\\d*(?:\\.\\d{1,2})?\\s*$'));
  });

  it('should initialize regex when no fractions and negative numbers', () => {
    component.fractionDigits = 0;
    component.allowNegative = true;
    component.ngOnInit();
    expect(component.regex).toEqual(new RegExp('^-?\\d+$'));
  });

  it('should initialize regex when no fractions and positive numbers', () => {
    component.fractionDigits = 0;
    component.allowNegative = false;
    component.ngOnInit();
    expect(component.regex).toEqual(new RegExp('^\\d+$'));
  });

  it('should be able to get validation messages when no fractions and negative numbers', () => {
    component.fractionDigits = 0;
    component.allowNegative = true;
    const validatorMessage = component.getValidatorMessage('PATTERN');
    expect(validatorMessage).toBe('Use Only Numbers');
  });

  it('should be able to get validation messages when no fractions and positive', () => {
    component.fractionDigits = 0;
    component.allowNegative = false;
    const validatorMessage = component.getValidatorMessage('PATTERN');
    expect(validatorMessage).toBe('Use Only Numbers');
  });

  it('should be able to get validation messages when fractions and negative', () => {
    component.fractionDigits = 2;
    component.allowNegative = true;
    const validatorMessage = component.getValidatorMessage('PATTERN');
    expect(validatorMessage).toBe('Use Only Numbers (And One Dot)');
  });

  it('should be able to get validation messages when fractions and positive', () => {
    component.fractionDigits = 2;
    component.allowNegative = false;
    const validatorMessage = component.getValidatorMessage('PATTERN');
    expect(validatorMessage).toBe('Use Only Numbers (And One Dot)');
  });

  it('should be able to get custom validation messages when fractions and positive are set', () => {
    component.fractionDigits = 2;
    component.allowNegative = false;
    component.customValidationMessage = 'In-Valid Number enter'
    const validatorMessage = component.getValidatorMessage('PATTERN');
    expect(validatorMessage).toBe('In-Valid Number enter');
  });

  it('should be able to get validation messages from super class', () => {
    component.fractionDigits = 2;
    component.allowNegative = false;
    spyOn(AALInputFormControlComponent.prototype, 'getValidatorMessage').and.returnValue('Sample');
    const validatorMessage = component.getValidatorMessage('');
    expect(validatorMessage).toContain('Sample');
  });


  it('should call (onBlur) function', () => {
    spyOn(AALInputFormControlComponent.prototype, 'onBlur');
    component.control = new UntypedFormControl('', Validators.required);
    const event = createSpyObj('relatedTarget', ['mat-option']);
    component.onBlur(new Event(event));
    expect(AALInputFormControlComponent.prototype.onBlur).toHaveBeenCalled();
  });

  it('should call triggerAcceptChanges of super Component', () => {
    spyOn(AALInputFormControlComponent.prototype, 'triggerAcceptChanges').and.callThrough();
    component.control.setValue('1234');
    component.triggerAcceptChanges();
    expect(AALInputFormControlComponent.prototype.triggerAcceptChanges).toHaveBeenCalled();
  });

  it('should return nothing when value is set from history ', () => {
    component.control = new UntypedFormControl('sample data', Validators.required);
    const matOption = document.createElement('mat-option');
    matOption.classList.add('mat-select');
    const event = new FocusEvent('focus', {relatedTarget: matOption});
    const returnValue = component.onBlur(event);
    expect(returnValue).toBe(undefined);
  });

  it('should not allow value which are not allowed', () => {
    component.control = new UntypedFormControl('', Validators.required);
    const event = new KeyboardEvent('keydown', {
      key: 'e'
    });
    component.onKeyDown(event);
    expect(component.control.value).toEqual('');
  });

  it('should call super onBlur function when disableAcceptChangesOnBlur is set to false', () => {
    spyOn(AALInputFormControlComponent.prototype, 'onBlur');
    component.control = new UntypedFormControl('', Validators.required);
    component.disableAcceptChangesOnBlur = false;
    const event = createSpyObj('relatedTarget', ['']);
    component.onBlur(new Event(event));
    expect(AALInputFormControlComponent.prototype.onBlur).toHaveBeenCalled();
  });
});
