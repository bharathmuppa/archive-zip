import {Component, Input, OnInit} from '@angular/core';
import {CommonMaterialComponentErrorStateMatcher} from '../shared/common-material-component.error-state-matcher';
import {AALInputFormControlComponent, HistoryService} from '@asml-angular/common';

@Component({
  selector: 'aal-input-number',
  templateUrl: './input-number.component.html',
  styleUrls: ['./input-number.component.scss']
})
export class AALInputNumberComponent extends AALInputFormControlComponent implements OnInit {
  @Input()
  prefix: string;
  @Input()
  suffix: string;
  @Input()
  fractionDigits: number;
  @Input()
  allowNegative: boolean;
  @Input()
  allowSpecialCharacters: boolean;
  @Input()
  set validationPattern(value: string) {
    if (value) {
      this.regex = new RegExp(value);
      this.validationRegex = value;
    }
  }
  @Input()
  hideError: boolean;
  @Input()
  disableAcceptChangesOnBlur: boolean;
  @Input()
  customValidationMessage: string;
  regex: RegExp;
  errorStateMatcher = new CommonMaterialComponentErrorStateMatcher();
  invalidChars = [
    '-',
    '+',
    'e',
  ];
  private validationRegex: string;

  constructor(historyService: HistoryService) {
    super(historyService);
    this.fractionDigits = this.fractionDigits || 0;
    this.allowNegative = (this.allowNegative === null || this.allowNegative === undefined) ?
      true : this.allowNegative;
  }

  ngOnInit() {
    if (this.validationRegex) {
      this.regex = new RegExp(this.validationRegex);
    } else {
      if (this.fractionDigits === 0) {
        this.regex = this.allowNegative ? /^-?\d+$/ : /^\d+$/;
      } else { // (this.fractionDigits > 0
        const tempStrAllowNegative = `^\\s*-?\\s*(?=.*[0-9])\\d*(?:\\.\\d{1,${this.fractionDigits}})?\\s*$`;
        const tempStrAllowPositive = `^\\s*(?=.*[0-9])\\d*(?:\\.\\d{1,${this.fractionDigits}})?\\s*$`;
        this.regex = this.allowNegative ? new RegExp(tempStrAllowNegative) : new RegExp(tempStrAllowPositive);
      }
    }
    super.ngOnInit();
  }

  getValidatorMessage(validatorKey: string): string {
    if (validatorKey.toUpperCase() === 'PATTERN') {
      let message = '';
      if (this.fractionDigits === 0) {
        message = 'Use Only Numbers';
      } else { // (this.fractionDigits > 0
        message = 'Use Only Numbers (And One Dot)';
      }
      if(this.customValidationMessage) {
        return this.customValidationMessage;
      } else {
        return message;
      }
    } else {
      if(this.customValidationMessage) {
        return this.customValidationMessage;
      } else {
        return super.getValidatorMessage(validatorKey);
      }
    }
  }

  onBlur($event?: Event) {
    /* For composite controls, when any value is selected, the focus shits to the input element. Here we are writing conditions for the scenarios when the blur event of the input control must not be called. Add the class 'skip-input-blur-event' to achieve this */
    if ($event instanceof FocusEvent && $event.relatedTarget
      && ($event.relatedTarget['classList'].contains('mat-select') || $event.relatedTarget['id'].includes(this.hyphenatedID) ||
        $event.relatedTarget['parentElement'].classList.contains('skip-input-blur-event'))) {
      // do nothing
      return;
    }
    const isAcceptChangesNotNeeded = !this.confirmToolBarNotApplicable && this.disableAcceptChangesOnBlur;
    if(!isAcceptChangesNotNeeded){
      super.onBlur($event);
    }
  }

  triggerAcceptChanges() {
    super.triggerAcceptChanges();
  }

  onKeyDown(event: KeyboardEvent): void {
    // block special character from input field unless explicitly asked for
    if (this.invalidChars.includes(event.key) && !this.allowSpecialCharacters) {
      event.preventDefault();
    }
  }
}
