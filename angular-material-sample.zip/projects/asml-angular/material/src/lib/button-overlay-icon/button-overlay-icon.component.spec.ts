import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { AALButtonOverlayIconComponent } from './button-overlay-icon.component';
import { CommonModule } from '@angular/common';
import { SharedMaterialModule } from '../shared/shared-material.module';
import { SharedFormModule } from '../shared/shared-form.module';
import { AALCommonComponentsModule } from '@asml-angular/common';
import { SharedModule } from '../shared/shared.module';
import { SharedFlexLayoutModule } from '../shared/shared-flex-layout.module';
import { AALListItemModule } from '../list-item/list-item.module';
import { MatBadgeModule } from '@angular/material/badge';

describe('ButtonOverlayIconComponent', () => {
  let component: AALButtonOverlayIconComponent;
  let fixture: ComponentFixture<AALButtonOverlayIconComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [AALButtonOverlayIconComponent],
      imports: [
        CommonModule,
        SharedMaterialModule,
        SharedFormModule,
        AALCommonComponentsModule,
        SharedModule,
        SharedFlexLayoutModule,
        AALListItemModule,
        MatBadgeModule
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALButtonOverlayIconComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should emit on click of button', () => {
    spyOn(component.submitClick, 'emit');
    const event = new MouseEvent('click');
    component.onsubmit(event);
    fixture.detectChanges();
    expect(component.submitClick.emit).toHaveBeenCalled();
  });
});
