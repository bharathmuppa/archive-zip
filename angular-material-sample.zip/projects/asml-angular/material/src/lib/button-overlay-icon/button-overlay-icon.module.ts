import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AALCommonComponentsModule } from '@asml-angular/common';
import { AALButtonOverlayIconComponent } from './button-overlay-icon.component';
import {AALListItemModule} from '../list-item/list-item.module';
import {MatBadgeModule} from '@angular/material/badge';
import {MatMenuModule} from '@angular/material/menu';
import {MatDividerModule} from '@angular/material/divider';
import {MatIconModule} from '@angular/material/icon';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatTooltipModule} from '@angular/material/tooltip';
import {FlexLayoutModule} from '@angular/flex-layout';
import {MatButtonModule} from '@angular/material/button';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';

@NgModule({
  declarations: [AALButtonOverlayIconComponent],
  imports: [
    CommonModule,
    AALCommonComponentsModule,
    AALListItemModule,
    MatButtonModule,
    MatMenuModule,
    MatDividerModule,
    MatIconModule,
    MatToolbarModule,
    MatTooltipModule,
    MatBadgeModule,
    FlexLayoutModule,
    FormsModule,
    ReactiveFormsModule,
  ],
  exports: [AALButtonOverlayIconComponent]
})
export class AALButtonOverlayIconModule { }
