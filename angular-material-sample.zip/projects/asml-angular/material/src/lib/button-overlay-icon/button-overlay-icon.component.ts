import {Component, Input, Output, EventEmitter, TemplateRef} from '@angular/core';
import {AALCommonButtonComponent} from '@asml-angular/common';
import {ListItemConfiguration} from '../shared/list-item-configuration.model';

@Component({
  selector: 'aal-button-overlay-icon',
  templateUrl: './button-overlay-icon.component.html',
  styleUrls: ['./button-overlay-icon.component.scss']
})
export class AALButtonOverlayIconComponent extends AALCommonButtonComponent {

  @Input()
  headerIcon: string;
  @Input()
  headerTitle: any;
  @Input()
  buttonText: any;
  @Input()
  listItemDetails: ListItemConfiguration[];
  @Input()
  defaultItemIcon: string;
  @Input()
  menuContentRef: TemplateRef<any>;
  @Input()
  defaultItemImageURL: string;
  @Input()
  defaultSvgIcon: string;
  @Input()
  titleTemplateRef: TemplateRef<any>;
  @Input()
  mainDescriptionTemplateRef: TemplateRef<any>;
  @Input()
  subDescriptionTemplateRef: TemplateRef<any>;
  @Output()
  submitClick: EventEmitter<string> = new EventEmitter<string>();

  onsubmit($event) {
    this.submitClick.emit();
  }
}
