import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {AALExpansionPanelComponent} from './expansion-panel.component';
import {AALCommonComponentsModule} from "@asml-angular/common";
import {AALOverlayCardHelpModule} from "../overlay-card-help/overlay-card-help.module";
import {AALOverlayCardErrorModule} from "../overlay-card-alert/overlay-card-alert.module";
import {AALToolbarConfirmModule} from "../toolbar-confirm/toolbar-confirm.module";
import {MatExpansionModule} from '@angular/material/expansion';
import {FlexLayoutModule} from '@angular/flex-layout';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import {MatTooltipModule} from '@angular/material/tooltip';
import {MatButtonModule} from '@angular/material/button';

@NgModule({
  declarations: [AALExpansionPanelComponent],
  imports: [
    CommonModule,
    AALCommonComponentsModule,
    AALOverlayCardHelpModule,
    AALOverlayCardErrorModule,
    AALToolbarConfirmModule,
    MatButtonModule,
    MatExpansionModule,
    MatProgressSpinnerModule,
    MatTooltipModule,
    FlexLayoutModule
  ],
  exports: [AALExpansionPanelComponent]
})
export class AALExpansionPanelModule {
}
