import { Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { MatExpansionPanel } from '@angular/material/expansion';
import { Info, InfoLevels } from '@asml-angular/common';

@Component({
  selector: 'aal-expansion-panel',
  templateUrl: './expansion-panel.component.html',
  styleUrls: ['./expansion-panel.component.scss']
})
export class AALExpansionPanelComponent implements OnInit {
  @Input()
  header: string;
  @Input()
  isExpanded: boolean;
  @Input()
  headerCost?: string;
  @Input()
  headerHelp: Info | string;
  @Input()
  buttonLabel: string;
  @Input()
  showButton: boolean;
  @Input()
  buttonTooltip: string;
  @Input()
  disableButton: boolean;
  @Input()
  expansionDisabled: boolean;
  @Input()
  set headerError(value: Info | string) {
    if (value) {
      this.headerErrorDetails = value;
      this.headerErrorTitleColor = this.getColor();
    } else {
      this.headerErrorDetails = '';
      this.headerErrorTitleColor = '';
    }
  }
  @Input()
  error: Info | string;
  @Input()
  hideHeaderHelp?: boolean;
  @Input()
  isDataLoading: boolean;
  @Input()
  headerCaption: string;
  @Output()
  buttonClick: EventEmitter<void> = new EventEmitter<void>();
  headerErrorDetails: Info | string;
  headerErrorTitleColor: string;
  @Output()
  expansionPanelToggleState: EventEmitter<boolean> = new EventEmitter<boolean>();
  @ViewChild(MatExpansionPanel) expansionPanel: MatExpansionPanel;

  ngOnInit() {
    if (this.headerHelp && typeof this.headerHelp === 'string') {
      this.headerHelp = new Info(this.headerHelp);
    }
    if (this.error && typeof this.error === 'string') {
      this.error = new Info(this.error);
    }
  }

  onButtonClick($event): void {
    this.buttonClick.emit();
    $event.stopPropagation();
  }

  onExpansionPanelToggle() {
    if (this.expansionDisabled) {
      return;
    }
    this.isExpanded = !this.isExpanded;
    if (this.isExpanded) {
      this.expansionPanel.open();
      this.expansionPanelToggleState.emit(true);
    }
    else {
      this.expansionPanel.close();
      this.expansionPanelToggleState.emit(false);
    }
  }

  getColor(): string {
    if (typeof this.headerErrorDetails !== 'string' && this.headerErrorDetails.level === InfoLevels.ERROR) {
      return '#e00';
    } else {
      return '#f0ab00';
    }
  }

}
