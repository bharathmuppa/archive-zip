import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import {AALExpansionPanelComponent} from './expansion-panel.component';
import {CommonModule} from '@angular/common';
import {SharedMaterialModule} from '../shared/shared-material.module';
import {SharedFormModule} from '../shared/shared-form.module';
import {SharedModule} from '../shared/shared.module';
import {AALCommonComponentsModule, Info} from '@asml-angular/common';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';

describe('AALExpansionPanelComponent', () => {
  let component: AALExpansionPanelComponent;
  let fixture: ComponentFixture<AALExpansionPanelComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [AALExpansionPanelComponent],
      imports: [CommonModule,
        SharedMaterialModule,
        SharedFormModule,
        SharedModule,
        AALCommonComponentsModule,
        BrowserAnimationsModule]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALExpansionPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should match object headerHelp info onInIt', () => {
    component.headerHelp = 'test header help string';
    component.ngOnInit();
    expect(component.headerHelp).toEqual(jasmine.objectContaining({
      message: 'test header help string'
    }));
  });

  it('should match object error info onInIt', () => {
    component.error = 'test error string';
    component.ngOnInit();
    expect(component.error).toEqual(jasmine.objectContaining({
      message: 'test error string'
    }));
  });

  it('should emit buttonClick, when onButtonClick is triggered', () => {
    spyOn(component.buttonClick, 'emit');
    component.onButtonClick({stopPropagation() {}});
    expect(component.buttonClick.emit).toHaveBeenCalled();
  });

  it('should set header error details, when header error is set', () => {
    component.headerError = new Info('Missing fields error Detected', 'Missing Fields', '', '', 'ERROR');
    expect(component.headerErrorTitleColor).toEqual('#e00');
  });

  it('should set header error details, when header warning is set', () => {
    component.headerError = new Info('Missing fields error Detected', 'Missing Fields', '', '', 'WARN');
    expect(component.headerErrorTitleColor).toEqual('#f0ab00');
  });

  it('should not set header error details, when headerError is empty', () => {
    component.headerError = '';
    expect(component.headerErrorTitleColor).toEqual('');
  });

  it('should emit expansionPanelToggleState as false, when onExpansionPanelToggle is clicked and isExpanded is set to true', () => {
    const spy = spyOn(component.expansionPanelToggleState, 'emit');
    component.expansionDisabled = false;
    component.isExpanded = true;
    component.onExpansionPanelToggle();
    expect(spy).toHaveBeenCalledWith(false);

  });

  it('should emit expansionPanelToggleState as true, when onExpansionPanelToggle is clicked and isExpanded is set to false', () => {
    const spy = spyOn(component.expansionPanelToggleState, 'emit');
    component.expansionDisabled = false;
    component.isExpanded = false;
    component.onExpansionPanelToggle();
    expect(spy).toHaveBeenCalledWith(true);
  });

  it('should not emit expansionPanelToggleState, when onExpansionPanelToggle is clicked and expansionDisabled is set to true', () => {
    const spy = spyOn(component.expansionPanelToggleState, 'emit');
    component.expansionDisabled = true;
    component.onExpansionPanelToggle();
    expect(spy).toHaveBeenCalledTimes(0);
  });

});
