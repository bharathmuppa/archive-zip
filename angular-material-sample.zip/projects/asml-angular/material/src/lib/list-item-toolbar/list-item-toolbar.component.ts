import {Component, EventEmitter, Input, OnInit, Output, TemplateRef} from '@angular/core';

@Component({
  selector: 'aal-list-item-toolbar',
  templateUrl: './list-item-toolbar.component.html',
  styleUrls: ['./list-item-toolbar.component.scss']
})
export class AALListItemToolbarComponent implements OnInit {
  @Input()
  ID: string;
  @Input()
  isClickable: boolean;
  @Input()
  item: any;
  @Input()
  icon: string;
  @Input()
  isBusy: boolean;
  @Input()
  imageURL: string;
  @Input()
  svgIcon: string;
  @Input()
  title: string;
  @Input()
  iconTooltip: string;
  @Input()
  description: string;
  @Input()
  titleTemplateRef: TemplateRef<any>;
  @Input()
  descriptionTemplateRef: TemplateRef<any>;
  @Output() onClick = new EventEmitter<string>();

  constructor() {
  }

  ngOnInit() {
  }

  onToolbarClick(): void {
    this.onClick.emit(this.ID);
  }

  getTooltipContent(element: any, data: string): string {
    if (element) {
      return element.offsetWidth < element.scrollWidth ? data : '';
    }
    return '';
  }

}
