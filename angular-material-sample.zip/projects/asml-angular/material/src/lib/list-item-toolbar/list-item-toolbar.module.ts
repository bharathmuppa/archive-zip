import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AALListItemToolbarComponent } from './list-item-toolbar.component';
import {MatTooltipModule} from '@angular/material/tooltip';
import {MatIconModule} from '@angular/material/icon';
import {FlexLayoutModule} from '@angular/flex-layout';

@NgModule({
  declarations: [AALListItemToolbarComponent],
  imports: [
    CommonModule,
    MatIconModule,
    MatTooltipModule,
    FlexLayoutModule
  ],
  exports: [AALListItemToolbarComponent]
})
export class AALListItemToolbarModule { }
