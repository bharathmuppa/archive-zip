import {ComponentFixture, TestBed, waitForAsync} from '@angular/core/testing';

import {AALListItemToolbarComponent} from './list-item-toolbar.component';
import {CommonModule} from '@angular/common';
import {SharedMaterialModule} from '../shared/shared-material.module';
import {SharedFormModule} from '../shared/shared-form.module';
import {AALCommonComponentsModule} from '@asml-angular/common';
import {SharedModule} from '../shared/shared.module';
import {SharedFlexLayoutModule} from '../shared/shared-flex-layout.module';
import {MatBadgeModule} from '@angular/material/badge';
import {NO_ERRORS_SCHEMA} from '@angular/core';

describe('AALListItemToolbarComponent', () => {
  let component: AALListItemToolbarComponent;
  let fixture: ComponentFixture<AALListItemToolbarComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [AALListItemToolbarComponent],
      schemas: [NO_ERRORS_SCHEMA],
      imports: [
        CommonModule,
        SharedMaterialModule,
        SharedFormModule,
        AALCommonComponentsModule,
        SharedModule,
        SharedFlexLayoutModule,
        MatBadgeModule
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALListItemToolbarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should emit onClick when onToolbarClick is clicked', () => {
    spyOn(component.onClick, 'emit');
    component.ID = 'test';
    component.onToolbarClick();
    expect(component.onClick.emit).toHaveBeenCalledWith('test');
  });
  it('should return data when offsetWidth is less than scrollWidth', () => {
    const returnValue = component.getTooltipContent({offsetWidth: 5, scrollWidth: 6}, 'data');
    expect(returnValue).toBe('data');
  });
  it('should return empty when offsetWidth is greater than scrollWidth', () => {
    const returnValue = component.getTooltipContent({offsetWidth: 6, scrollWidth: 5}, 'data');
    expect(returnValue).toBe('');
  });
  it('should return empty when offsetWidth and scrollWidth are null', () => {
    const returnValue = component.getTooltipContent(null, 'data');
    expect(returnValue).toBe('');
  });
});
