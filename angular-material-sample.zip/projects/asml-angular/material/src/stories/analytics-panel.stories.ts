import { Meta, StoryObj} from '@storybook/angular';
import {AALAnalyticsPanelComponent} from '../lib/analytics-panel/analytics-panel.component';


const meta: Meta<AALAnalyticsPanelComponent> = {
  title: 'Mirai/AnalyticsPanel',
  component: AALAnalyticsPanelComponent,
  excludeStories: /.*Data$/,
  tags: ['autodocs'],
  render: (args: AALAnalyticsPanelComponent) => ({
    props: {
      ...args,
    },
  }),
};

export default meta;
type Story = StoryObj<AALAnalyticsPanelComponent>;

export const Default: Story = {
  args: {
    item: {},

  },
};
