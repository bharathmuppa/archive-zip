import { Component, OnInit } from '@angular/core';
import {NotificationAnalyticsData} from '../../../../asml-angular/material/src/lib/analytics-panel/analytics-panel.model';

@Component({
  selector: 'aal-analytics-panel-test',
  templateUrl: './analytics-panel-test.component.html',
  styleUrls: ['./analytics-panel-test.component.css']
})
export class AnalyticsPanelTestComponent implements OnInit {
  panelData: NotificationAnalyticsData[];
  panelDataMultiple: NotificationAnalyticsData[];
  panelDataMultipleWithIcon: NotificationAnalyticsData[];
  constructor() { }

  ngOnInit(): void {
    this.panelData = [
    {
      "notificationType":"STATUSCHANGE",
      "notificationCount":100,
      "notificationTypeLabel":"Panel 1",
      "additionalData": {
        'count1': 1,
        'count2': 1,
        'count3': 1
      }
    },
    {
      "notificationType":"ACTION",
      "notificationCount":20,
      "notificationTypeLabel":"Panel 2",
      "additionalData": {
        'count1': 1,
        'count2': 1,
        'count3': 1
      }
    },
    {
      "notificationType":"ANNOUNCEMENT",
      "notificationCount":150,
      "notificationTypeLabel":"Panel 3",
      "additionalData": {
        'count1': 1,
        'count2': 1,
        'count3': 1
      }
    },
    {
      "notificationType":"MYTEAM",
      "notificationCount":200,
      "notificationTypeLabel":"Panel 4",
      "additionalData": {
        'count1': 1,
        'count2': 1,
        'count3': 1
      }
    },
    {
      "notificationType":"OTHERTYPE",
      "notificationCount":125,
      "notificationTypeLabel":"Panel 5",
      "additionalData": {
        'count1': 1,
        'count2': 1,
        'count3': 1
      }
    }
  ];


    this.panelDataMultiple = [
      {
        "notificationType":"STATUSCHANGE",
        "notificationCount":100,
        "notificationTypeLabel":"Panel 1"
      },
      {
        "notificationType":"ACTION",
        "notificationCount":20,
        "notificationTypeLabel":"Panel 2"
      },
      {
        "notificationType":"ANNOUNCEMENT",
        "notificationCount":150,
        "notificationTypeLabel":"Panel 3"
      },
      {
        "notificationType":"MYTEAM",
        "notificationCount":200,
        "notificationTypeLabel":"Panel 4"
      },
      {
        "notificationType":"OTHERTYPE",
        "notificationCount":125,
        "notificationTypeLabel":"Panel 5"
      }
    ];

    this.panelDataMultipleWithIcon = [
          {
              "notificationType":"STATUSCHANGE",
              "notificationCount":100,
              "notificationTypeLabel":"Panel 1",
              "cardStyleClassName":"green-color",
              "icon": "add_task"
          },
          {
              "notificationType":"ACTION",
              "notificationCount":20,
              "notificationTypeLabel":"Panel 2",
              "cardStyleClassName":"green-color",
              "icon": "add_task"
          },
          {
              "notificationType":"ANNOUNCEMENT",
              "notificationCount":150,
              "notificationTypeLabel":"Panel 3",
              "cardStyleClassName":"green-color",
              "icon": "add_task"
          }
      ];
  }

}
