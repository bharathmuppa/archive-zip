import {Component, OnInit} from '@angular/core';
import {MatDialog, MatDialogRef} from "@angular/material/dialog";
import {NavigationConfirmationDialogComponent} from "../../../../asml-angular/material/src/lib/navigation-confirmation-dialog/navigation-confirmation-dialog.component";

@Component({
  selector: 'aal-button-contained-test',
  templateUrl: './button-contained-test.component.html',
  styleUrls: ['./button-contained-test.component.scss']
})
export class AALButtonContainedTestComponent implements OnInit {
  constructor(public dialog: MatDialog) {
  }

  ngOnInit() {
  }

  buttonClick(): void {
    console.log('button click');
  }

  openDialog() {
    let dialogRef: MatDialogRef<NavigationConfirmationDialogComponent>;
    dialogRef = this.dialog.open(NavigationConfirmationDialogComponent, {
      width: '50rem',
      data: {
        isCaseObject: false
      }
    });

    dialogRef.afterClosed().subscribe(confirm => {
      if (confirm) {
        console.log('Confirm')
      }
    });
  }
}
