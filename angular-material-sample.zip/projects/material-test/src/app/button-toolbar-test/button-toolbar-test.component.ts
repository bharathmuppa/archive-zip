import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'aal-button-toolbar-test',
  templateUrl: './button-toolbar-test.component.html',
  styleUrls: ['./button-toolbar-test.component.scss']
})
export class AALButtonToolbarTestComponent implements OnInit {
  toolbarConfig: any[];

  constructor() {
  }

  ngOnInit() {
    this.toolbarConfig = [
      {
        name: 'action button',
        tooltip: 'its an action button',
        type: 'contained',
        color: 'accent',
        hasSeparatorAfter: true
      },
      {
        hasBadge: true,
        badgeData: '10',
        icon: 'home',
        tooltip: 'badge icon button',
        type: 'icon',
        hasSeparatorAfter: true
      },
      {
        name: 'action button1',
        tooltip: 'its an action button1',
        type: 'contained',
        color: 'accent'
      }
    ];
  }

}
