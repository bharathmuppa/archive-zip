import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'aal-button-test',
  templateUrl: './button-test.component.html',
  styleUrls: ['./button-test.component.scss']
})
export class AALButtonTestComponent implements OnInit {
  buttonConfig: any;
  buttonConfigIcon: any;

  constructor() {
  }

  ngOnInit() {
    this.buttonConfig = {
      name: 'action button', tooltip: 'its an action button', type: 'contained'
    };
    this.buttonConfigIcon = {
      hasBadge: true, badgeData: '10', icon: 'home', tooltip: 'badge icon button', type: 'icon'
    };
  }

  buttonClick(): void {
    console.log('button click');
  }
}
