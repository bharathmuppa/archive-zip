import { Component, OnInit } from '@angular/core';
import {Info, Mode, Modes} from '@asml-angular/common';
import {UntypedFormBuilder, UntypedFormControl, Validators} from '@angular/forms';

@Component({
  selector: 'aal-date-picker-select-test',
  templateUrl: './date-picker-select-test.component.html',
  styleUrls: ['./date-picker-select-test.component.scss']
})
export class AALDatePickerSelectTestComponent implements OnInit {

  mode: Mode;
  control: UntypedFormControl;
  showSpinner: boolean;
  errorAlert: Info;
  warnAlert: Info;
  help: Info;
  modes = Modes;

  constructor(private readonly fb: UntypedFormBuilder) {
  }

  ngOnInit() {
    const newValue = new Date('Mon Apr 19 2021 19:08:42 GMT+0530 (India Standard Time)');
    this.control = this.fb.control(null, Validators.required);
  }

  onAcceptChanges($event) {
    console.log($event);
  }

  onRejectChanges($event) {
    console.log($event);
  }

}
