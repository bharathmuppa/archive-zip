import { Component } from '@angular/core';

@Component({
  selector: 'aal-button-outlined-test',
  templateUrl: './button-outlined-test.component.html',
  styleUrls: ['./button-outlined-test.component.scss']
})
export class AALButtonOutlinedTestComponent {


  buttonClick(): void {
    console.log('button click');
  }
}
