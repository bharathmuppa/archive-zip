import {Component, OnInit} from '@angular/core';
import {UntypedFormControl, Validators} from '@angular/forms';
import {Info, Modes} from '@asml-angular/common';

@Component({
  selector: 'aal-input-number-test',
  templateUrl: './input-number-test.component.html',
  styleUrls: ['./input-number-test.component.scss']
})
export class AALInputNumberTestComponent implements OnInit {
  control1: UntypedFormControl;
  control2: UntypedFormControl;
  control3: UntypedFormControl;
  control4: UntypedFormControl;
  alert: Info;
  help: Info;
  modes = Modes;

  constructor() {
  }

  ngOnInit() {
    this.control1 = new UntypedFormControl(null, Validators.required);
    this.control2 = new UntypedFormControl(null, Validators.required);
    this.control3 = new UntypedFormControl(0, Validators.required);
    this.control4 = new UntypedFormControl(0, Validators.required);

    const errorTitle = 'Error Title';
    const errorMessage = 'This is error message with <a target="_blank" href="https://www.google.com">link </a>';
    const errorAnimation = 'https://media.giphy.com/media/1BcfGzv2jCvRl2E4yo/giphy.gif';
    const errorThumbnail = 'https://upload.wikimedia.org/wikipedia/en/6/6c/ASML_Holding_N.V._logo.svg';
    const errorLevel = 'ERROR';
    this.alert = new Info(errorTitle, errorMessage, errorAnimation, errorThumbnail, errorLevel);

    const helpTitle = 'Help Title';
    const helpMessage = 'This is help message with <a target="_blank" href="https://www.google.com">link </a>';
    const helpAnimation = 'https://media.giphy.com/media/1BcfGzv2jCvRl2E4yo/giphy.gif';
    const helpThumbnail = 'https://upload.wikimedia.org/wikipedia/en/6/6c/ASML_Holding_N.V._logo.svg';
    this.help = new Info(helpTitle, helpMessage, helpAnimation, helpThumbnail, null);
  }

  onAcceptChanges($event) {
    console.log($event);
  }

  onRejectChanges($event) {
    console.log($event);
  }

}
