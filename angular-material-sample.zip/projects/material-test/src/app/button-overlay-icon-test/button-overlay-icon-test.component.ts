import { Component, OnInit } from '@angular/core';
import {
  ActionButtonConfiguration,
  ExpansionPanelItemConfiguration
} from '../../../../asml-angular/material/src/lib/expansion-panel-list/expansion-panel-list.model';
import { ListItemConfiguration } from '../../../../asml-angular/material/src/lib/shared/list-item-configuration.model';


@Component({
  selector: 'aal-button-overlay-icon-test',
  templateUrl: './button-overlay-icon-test.component.html',
  styleUrls: ['./button-overlay-icon-test.component.scss']
})
export class AALButtonOverlayIconTestComponent implements OnInit {
  headerIcon: string;
  headerTitle: string;
  listDetails;

  ngOnInit() {
    this.headerIcon = 'group';
    this.headerTitle = 'myTeam';

    this.listDetails =
      [
        ({
          ID: 'ID1',
          title: 'Fazal Shaik',
          mainDescription: 'Change Specialist',
          subDescription: 'IT O&I Service Integration',
          icon: 'group',
          isClickable: true,
          actionButtonConfiguration: ({
            actionButtonIcon: 'delete',
            actionButtonText: 'buttonText1',
            actionButtonType: 'icon',
            actionButtonTooltip: 'action button tooltip1',
            showActionButton: false,
            action: 'delete'
          }) as ActionButtonConfiguration
        }) as ListItemConfiguration,
        ({
          ID: 'ID2',
          title: 'Suresh Upthula',
          mainDescription: 'Change Specialist',
          subDescription: 'IT O&I Service Integration',
          icon: 'group',
          isClickable: true,
          actionButtonConfiguration: ({
            actionButtonIcon: 'delete',
            actionButtonText: 'buttonText2',
            actionButtonType: 'icon',
            actionButtonTooltip: 'action button tooltip2',
            showActionButton: false,
            action: 'delete'
          }) as ActionButtonConfiguration
        }) as ListItemConfiguration,
        ({
          ID: 'ID3',
          title: 'Rayyan',
          mainDescription: 'Change Specialist',
          subDescription: 'IT O&I Service Integration',
          icon: 'group',
          isClickable: false,
          actionButtonConfiguration: ({
            actionButtonIcon: 'delete',
            actionButtonText: 'buttonText3',
            actionButtonType: 'icon',
            actionButtonTooltip: 'action button tooltip3',
            showActionButton: false,
            action: 'delete'
          }) as ActionButtonConfiguration
        }) as ListItemConfiguration
      ];
  }

  buttonClick() {
    console.log("Overlay button clicked");
  }
}

