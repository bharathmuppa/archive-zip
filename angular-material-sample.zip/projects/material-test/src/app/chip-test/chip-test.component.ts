import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'aal-chip-test',
  templateUrl: './chip-test.component.html',
  styleUrls: ['./chip-test.component.scss']
})
export class AALChipTestComponent implements OnInit {
  imageURL: string;
  icon: string;
  constructor() { }

  ngOnInit() {
    this.icon = 'calendar_today';
    this.imageURL = 'https://people.asml.com/_layouts/15/userphoto.aspx?size=M&accountname=asml%2Dcom%5Canikumar';
  }
  onRemove(data) {
    console.log('On Remove called');
  }
  onChipClick(data) {
    console.log('on Chip Clicked called');
  }
}
