import {Component, OnInit} from '@angular/core';
import {UntypedFormBuilder, UntypedFormControl, Validators} from '@angular/forms';
import {Info, Mode, Modes} from '@asml-angular/common';

@Component({
  selector: 'aal-collapsible-panel-test',
  templateUrl: './collapsible-panel-test.component.html',
  styleUrls: ['./collapsible-panel-test.component.css']
})

export class AALCollapsiblePanelTestComponent implements OnInit {
  mode: Mode;
  control: UntypedFormControl;
  showSpinner: boolean;
  errorAlert: Info;
  warnAlert: Info;
  help: Info;
  modes = Modes;
  
  constructor(private readonly fb: UntypedFormBuilder) {
  }


  ngOnInit() {
    this.control = this.fb.control('', Validators.required);
    const errorTitle = 'Error Title';
    const errorMessage = 'This is error message with <a target="_blank" href="https://www.google.com">link </a>';
    const errorAnimation = 'https://media.giphy.com/media/1BcfGzv2jCvRl2E4yo/giphy.gif';
    const errorThumbnail = 'https://upload.wikimedia.org/wikipedia/en/6/6c/ASML_Holding_N.V._logo.svg';
    const errorLevel = 'ERROR';
    this.errorAlert = new Info(errorTitle, errorMessage, errorAnimation, errorThumbnail, errorLevel);

    const helpTitle = 'Help Title';
    const helpMessage = 'This is help message with <a target="_blank" href="https://www.google.com">link </a>';
    const helpAnimation = 'https://media.giphy.com/media/1BcfGzv2jCvRl2E4yo/giphy.gif';
    const helpThumbnail = 'https://upload.wikimedia.org/wikipedia/en/6/6c/ASML_Holding_N.V._logo.svg';
    this.help = new Info(helpTitle, helpMessage, helpAnimation, helpThumbnail, null);

    const warnTitle = 'Error Title';
    const warnMessage = 'You are not authorized in myChange  to see this field. ' +
      '<a target="_blank" href="https://www.google.com">Get access here.</a>';
    const warnLevel = 'WARN';
    this.warnAlert = new Info(warnTitle, warnMessage, null, null, warnLevel);
  }

  collapsibleButton($event){
    console.log("collapsibleButton click triggered--"+$event);
  }

  onAcceptChanges($event) {
    console.log($event);
  }

  onRejectChanges($event) {
    console.log($event);
  }
  
}
