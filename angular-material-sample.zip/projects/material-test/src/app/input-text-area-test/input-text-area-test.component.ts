import {Component, OnInit} from '@angular/core';
import {UntypedFormBuilder, UntypedFormControl, Validators} from '@angular/forms';
import {Info, Mode, Modes} from '@asml-angular/common';

@Component({
  selector: 'aal-input-text-area-test',
  templateUrl: './input-text-area-test.component.html',
  styleUrls: ['./input-text-area-test.component.scss']
})
export class AALInputTextAreaTestComponent implements OnInit {
  mode: Mode;
  control: UntypedFormControl;
  control1: UntypedFormControl;
  errorAlert: Info;
  help: Info;
  modes = Modes;
  alwaysEditModeControl: UntypedFormControl;

  constructor(private readonly fb: UntypedFormBuilder) {
  }

  ngOnInit() {
    this.control = this.fb.control(null, [Validators.required, Validators.maxLength(100)]);
    this.control1 = this.fb.control(null, [Validators.required, Validators.maxLength(100)]);
    const errorTitle = 'Error Title';
    const errorMessage = 'This is error message with <a target="_blank" href="https://www.google.com">link </a>';
    const errorAnimation = 'https://media.giphy.com/media/1BcfGzv2jCvRl2E4yo/giphy.gif';
    const errorThumbnail = 'https://upload.wikimedia.org/wikipedia/en/6/6c/ASML_Holding_N.V._logo.svg';
    const errorLevel = 'ERROR';
    this.errorAlert = new Info(errorTitle, errorMessage, errorAnimation, errorThumbnail, errorLevel);

    const helpTitle = 'Help Title';
    const helpMessage = 'This is help message with <a target="_blank" href="https://www.google.com">link </a>';
    const helpAnimation = 'https://media.giphy.com/media/1BcfGzv2jCvRl2E4yo/giphy.gif';
    const helpThumbnail = 'https://upload.wikimedia.org/wikipedia/en/6/6c/ASML_Holding_N.V._logo.svg';
    this.help = new Info(helpTitle, helpMessage, helpAnimation, helpThumbnail, null);

    this.alwaysEditModeControl = this.fb.control('', [Validators.required, Validators.maxLength(256)]);
  }

  onAcceptChanges($event) {
    console.log($event);
  }

  onRejectChanges($event) {
    console.log($event);
  }

  pressAcceptEvent($event) {
    console.log('test222');
    console.log($event);
  }

  pressRejectEvent($event) {
    console.log('test111');
    console.log($event);
  }
}
