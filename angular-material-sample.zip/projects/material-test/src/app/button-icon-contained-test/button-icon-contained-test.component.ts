import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'aal-button-icon-contained-test',
  templateUrl: './button-icon-contained-test.component.html',
  styleUrls: ['./button-icon-contained-test.component.scss']
})
export class AALButtonIconContainedTestComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  buttonClick(): void {
    console.log('button click');
  }
}
