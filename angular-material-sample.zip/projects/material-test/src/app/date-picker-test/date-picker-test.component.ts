import {Component, OnInit} from '@angular/core';
import {Info, Mode, Modes} from '@asml-angular/common';
import {UntypedFormBuilder, UntypedFormControl, Validators} from '@angular/forms';

@Component({
  selector: 'aal-date-picker-test',
  templateUrl: './date-picker-test.component.html',
  styleUrls: ['./date-picker-test.component.scss']
})
export class AALDatePickerTestComponent implements OnInit {

  mode: Mode;
  control: UntypedFormControl;
  showSpinner: boolean;
  errorAlert: Info;
  warnAlert: Info;
  help: Info;
  modes = Modes;
  minDate: Date;

  constructor(private readonly fb: UntypedFormBuilder) {
  }

  ngOnInit() {
    this.minDate = new Date();
    this.control = this.fb.control('', Validators.required);
  }

  onAcceptChanges($event) {
    console.log($event);
  }

  onRejectChanges($event) {
    console.log($event);
  }

}
