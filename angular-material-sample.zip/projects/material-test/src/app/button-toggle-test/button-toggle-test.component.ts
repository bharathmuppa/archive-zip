import {Component, OnInit} from '@angular/core';
import {UntypedFormBuilder, UntypedFormControl, Validators} from '@angular/forms';
import {Info, Mode, Modes} from '@asml-angular/common';


@Component({
  selector: 'aal-button-toggle-test',
  templateUrl: './button-toggle-test.component.html',
  styleUrls: ['./button-toggle-test.component.scss']
})
export class AALButtonToggleTestComponent implements OnInit {
  mode: Mode;
  objectFormControl: UntypedFormControl;
  stringFormControl: UntypedFormControl;
  alert: Info;
  help: Info;
  objectOptions: any[];
  stringOptions: string[];
  disabledOptionsList: string[];

  constructor(private readonly fb: UntypedFormBuilder) {
    this.objectFormControl = this.fb.control('');
    this.stringFormControl = this.fb.control('', [Validators.required]);
  }

  ngOnInit() {
    this.objectOptions = [
      {name: 'option1', description: 'description1', tooltip: 'This is option 1'},
      {name: 'option2', description: 'description2', tooltip: 'This is option 2'},
      {name: 'option3', description: 'description3', tooltip: 'This is option 3'}
    ];
    this.stringOptions = ['str option1', 'coption1', 'coption2'];
    this.disabledOptionsList = ['str option2'];

    this.mode = Modes.READ;

    const errorTitle = 'Error Title';
    const errorMessage = 'This is error message with <a target="_blank" href="https://www.google.com">link </a>';
    const errorAnimation = 'https://media.giphy.com/media/1BcfGzv2jCvRl2E4yo/giphy.gif';
    const errorThumbnail = 'https://upload.wikimedia.org/wikipedia/en/6/6c/ASML_Holding_N.V._logo.svg';
    const errorLevel = 'ERROR';
    this.alert = new Info(errorTitle, errorMessage, errorAnimation, errorThumbnail, errorLevel);

    const helpTitle = 'Help Title';
    const helpMessage = 'This is help message with <a target="_blank" href="https://www.google.com">link </a>';
    const helpAnimation = 'https://media.giphy.com/media/1BcfGzv2jCvRl2E4yo/giphy.gif';
    const helpThumbnail = 'https://upload.wikimedia.org/wikipedia/en/6/6c/ASML_Holding_N.V._logo.svg';
    this.help = new Info(helpTitle, helpMessage, helpAnimation, helpThumbnail, null);

  }

  onAcceptChanges($event) {
    console.log($event);
  }

  onRejectChanges($event) {
    console.log($event);
  }
}
