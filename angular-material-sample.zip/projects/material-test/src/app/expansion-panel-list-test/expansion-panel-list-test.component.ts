import {Component, OnInit} from '@angular/core';
import {
  ActionButtonConfiguration,
  EmptyStateData,
  ExpansionPanelItemConfiguration
} from '../../../../asml-angular/material/src/lib/expansion-panel-list/expansion-panel-list.model';
import {Info} from '@asml-angular/common';

@Component({
  selector: 'aal-expansion-panel-list-test',
  templateUrl: './expansion-panel-list-test.component.html',
  styleUrls: ['./expansion-panel-list-test.component.scss']
})
export class AALExpansionPanelListTestComponent implements OnInit {
  expansionPanelItemConfigurationList: ExpansionPanelItemConfiguration[];
  expansionPanelItemConfigurationListWithOutHelp: ExpansionPanelItemConfiguration[];
  expansionPanelItemConfigurationOverviewCardList: ExpansionPanelItemConfiguration[];
  help: Info;
  emptyStateData: EmptyStateData;
  errorAlert: Info | string;

  constructor() {
  }

  ngOnInit() {
    this.help = new Info('help text message', 'help text title', '', '', '');

    const errorTitle = 'Error Title';
    const errorMessage = 'This is error message with <a target="_blank" href="https://www.google.com">link </a>';
    const errorAnimation = 'https://media.giphy.com/media/1BcfGzv2jCvRl2E4yo/giphy.gif';
    const errorThumbnail = 'https://upload.wikimedia.org/wikipedia/en/6/6c/ASML_Holding_N.V._logo.svg';
    const errorLevel = 'ERROR';
    this.errorAlert = 'Sample error';

    this.expansionPanelItemConfigurationList = [
      ({
        ID: 'ID1',
        title: 'title1',
        mainDescription: 'item main description1',
        line1: 'item sub description1',
        icon: 'group',
        isClickable: true,
        isBusy: true,
        help: new Info('some item level help'),
        showActionButtonOnFocus: true,
        actionButtonConfiguration: ({
          actionButtonIcon: 'delete',
          actionButtonText: 'buttonText1',
          actionButtonType: 'icon',
          actionButtonTooltip: 'action button tooltip1',
          showActionButton: true,
          action: 'delete'
        }) as ActionButtonConfiguration
      }) as ExpansionPanelItemConfiguration,
      ({
        ID: 'ID2',
        title: 'title2',
        mainDescription: 'item main description2 rrrrrrrrrrrrrrrrr rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr rrrrrrrrrrrrr rrrrrrrrrrrrrrrrr rrrrrrrrrrrrrrrrrrrrrr rrrrrrrrrrrrr rrrrrrrrrrrr rrrrrrrrrrrrrr 123456781234567812345678',
        line1: 'item sub description2 rrrrrrrrrrrr rrrrrrrrrrrrrrrrrrrrr rrrrrrrrrrrrrrrrr rrrrrrrrrrrrrrrrr rrrrrrrrrrrrrrrrrr rrrrrrrrrrrrrrrrrrrrrrrrrr',
        icon: 'group',
        isClickable: true,
        help: new Info('some item level help'),
        error: new Info('some item level error'),
        actionButtonConfiguration: ({
          actionButtonIcon: 'delete',
          actionButtonText: 'buttonText2',
          actionButtonType: 'icon',
          actionButtonTooltip: 'action button tooltip2',
          showActionButton: true,
          action: 'delete'
        }) as ActionButtonConfiguration
      }) as ExpansionPanelItemConfiguration,
      ({
        ID: 'ID3',
        title: 'title3',
        mainDescription: 'item main description3',
        line1: 'item sub description3',
        icon: 'group',
        isClickable: false,
        actionButtonConfiguration: ({
          actionButtonIcon: 'delete',
          actionButtonText: 'buttonText3',
          actionButtonType: 'icon',
          actionButtonTooltip: 'action button tooltip3',
          showActionButton: true,
          action: 'delete'
        }) as ActionButtonConfiguration
      }) as ExpansionPanelItemConfiguration
    ];

    this.expansionPanelItemConfigurationListWithOutHelp = [
      ({
        ID: 'ID11',
        title: 'title11',
        mainDescription: 'item main description11',
        line1: 'item sub description11',
        icon: 'group',
        isClickable: true,
        isBusy: true,
        showActionButtonOnFocus: true,
        actionButtonConfiguration: ({
          actionButtonIcon: 'delete',
          actionButtonText: 'buttonText11',
          actionButtonType: 'icon',
          actionButtonTooltip: 'action button tooltip11',
          showActionButton: true,
          action: 'delete'
        }) as ActionButtonConfiguration
      }) as ExpansionPanelItemConfiguration,
      ({
        ID: 'ID22',
        title: 'title22',
        mainDescription: 'item main description22',
        line1: 'item sub description22rrr',
        icon: 'group',
        isClickable: true,
        error: new Info('some item level error'),
        actionButtonConfiguration: ({
          actionButtonIcon: 'delete',
          actionButtonText: 'buttonText22',
          actionButtonType: 'icon',
          actionButtonTooltip: 'action button tooltip2',
          showActionButton: true,
          action: 'delete'
        }) as ActionButtonConfiguration
      }) as ExpansionPanelItemConfiguration,
      ({
        ID: 'ID33',
        title: 'title33',
        mainDescription: 'item main description33',
        line1: 'item sub description33',
        icon: 'group',
        isClickable: false,
        actionButtonConfiguration: ({
          actionButtonIcon: 'delete',
          actionButtonText: 'buttonText33',
          actionButtonType: 'icon',
          actionButtonTooltip: 'action button tooltip33',
          showActionButton: true,
          action: 'delete'
        }) as ActionButtonConfiguration
      }) as ExpansionPanelItemConfiguration
    ];

    this.expansionPanelItemConfigurationOverviewCardList = [
      ({
        ID: 'ID11',
        title: 'Review 1',
        mainDescription: '2020-04-30T10:00:00Z',
        line1: 'Open',
        icon: 'group',
        isClickable: true,
        isBusy: true,
        showActionButtonOnFocus: true,
      }) as ExpansionPanelItemConfiguration,
      ({
        ID: 'ID22',
        title: 'Review 2',
        mainDescription: '2020-04-30T10:00:00Z',
        line1: 'Closed',
        icon: 'group',
        isClickable: true,
        error: new Info('some item level error'),
      }) as ExpansionPanelItemConfiguration,
      ({
        ID: 'ID33',
        title: 'Review 3',
        mainDescription: '2020-04-30T10:00:00Z',
        line1: 'Released',
        icon: 'group',
        isClickable: false,
      }) as ExpansionPanelItemConfiguration
    ];

    this.emptyStateData = {
      title: 'empty state title',
      subTitle: 'empty state subTitle',
      description: 'empty state description',
      icon: 'list'
    };

  }

  addItem(): void {
    console.log('AALExpansionPanelListTestComponent: add Item event');
  }

  onActionSubmit($event): void {
    console.log('AALExpansionPanelListTestComponent: action data');
    console.log($event);
  }

  onItemClick($event): void {
    console.log('AALExpansionPanelListTestComponent: item click ID-' + $event);
  }

  delete($event) {
    event.stopPropagation();
    console.log('Delete clicked');
  }
}
