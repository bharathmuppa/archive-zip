import {Injectable} from '@angular/core';
import {ValidatorFn, Validators} from '@angular/forms';

@Injectable({
  providedIn: 'root'
})
export class FormTestValidationBuilderService {

  // TODO consider using type for magic string for validator names
  // type Easing = "ease-in" | "ease-out" | "ease-in-out";

  constructor() {
  }

  public getChangeRequestTypeValidatorFns(): ValidatorFn[] {
    // TODO depending upon object type (CR, CN, RP etc) and other properties (example status),  return all applicable validators
    // TODO extend service parameters to have details of validation per object status (to start with) and extensible to other properties
    const validatorFns: ValidatorFn[] = [];
    validatorFns.push(Validators.maxLength(5));
    return validatorFns;
  }
}
