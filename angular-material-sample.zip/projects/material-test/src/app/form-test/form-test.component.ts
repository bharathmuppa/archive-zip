import {Component, OnInit} from '@angular/core';
import {UntypedFormGroup} from '@angular/forms';
import {FormTestFormBuilderService} from './form-test-form-builder.service';
import {FormTestConfigurationBuilderService} from './form-test-configuration-builder.service';
import {FormTestConfigurationModel} from './form-test-configuration.model';
import {FormTestValidationBuilderService} from './form-test-validation-builder.service';
import {FormTestService} from './form-test.service';
import {CaseObject, ChangeRequest} from '../shared/models/mc.model';

@Component({
  selector: 'aal-form-test',
  templateUrl: './form-test.component.html',
  styleUrls: ['./form-test.component.scss']
})
export class FormTestComponent implements OnInit {
  changeRequest: ChangeRequest;
  caseObject: CaseObject;
  formTestForm: UntypedFormGroup;
  formTestControlConfiguration: FormTestConfigurationModel;

  constructor(private readonly fbs: FormTestFormBuilderService,
              private readonly fcbs: FormTestConfigurationBuilderService,
              private readonly fvbs: FormTestValidationBuilderService,
              private readonly fts: FormTestService) {
  }

  ngOnInit() {
    this.fts.getChangeRequest$(new CaseObject('624720', null, '')).subscribe((changeRequest) => {
      this.changeRequest = changeRequest;
      this.caseObject = new CaseObject(changeRequest.ID, changeRequest.revision, 'ChangeRequest');
      this.formTestForm = this.fbs.getFormTestForm(changeRequest);
      this.formTestControlConfiguration = this.fcbs.getFormTestConfiguration();
      this.formTestForm.get('changeRequestType').setValidators(this.fvbs.getChangeRequestTypeValidatorFns());
    });
  }
}
