import {Injectable} from '@angular/core';
import {UntypedFormBuilder, UntypedFormGroup} from '@angular/forms';
import {ChangeRequest} from '../shared/models/mc.model';


@Injectable({
  providedIn: 'root'
})
export class FormTestFormBuilderService {

  constructor(private fb: UntypedFormBuilder) {
  }

  public getFormTestForm(changeRequest?: ChangeRequest): UntypedFormGroup {
    return this.fb.group({
      generalInformation: this.fb.group({
        title: [changeRequest.generalInformation.title || ''],
        state: [changeRequest.generalInformation.state || ''],
        status: [changeRequest.generalInformation.status || '']
      }),
      changeRequestType: [changeRequest.changeRequestType || ''],
      implementationPriority: [changeRequest.implementationPriority || '']
    });
  }
}

