import {ControlConfigurationModel} from '../shared/models/control-configuration.model';

export class FormTestConfigurationModel {
  generalInformation?: FormTestGeneralInformationControlConfigurationModel;
  changeRequestType?: ControlConfigurationModel;
  implementationPriority?: ControlConfigurationModel;
}


export class FormTestGeneralInformationControlConfigurationModel {
  title?: ControlConfigurationModel;
  state?: ControlConfigurationModel;
  status?: ControlConfigurationModel;
}
