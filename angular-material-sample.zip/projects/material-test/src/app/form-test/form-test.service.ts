import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {environment} from '../../environments/environment';
import {CaseObject, ChangeRequest} from '../shared/models/mc.model';
import {Observable} from 'rxjs';
import {map} from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class FormTestService {

  rootServiceUrl: string;

  constructor(private readonly http: HttpClient) {
    this.rootServiceUrl = `${environment.rootURL}mc${environment.version}`;
  }

  getChangeRequest$(caseObject: CaseObject): Observable<ChangeRequest> {
    const url = `${this.rootServiceUrl}/change-requests/${caseObject.ID}`;
    return this.http.get(url).pipe(map(res => {
      return (res && res['ChangeRequestElement'] ? res['ChangeRequestElement'] : {}) as ChangeRequest;
    }));
    /*    const changeRequest: ChangeRequest = new ChangeRequest();
        changeRequest.ID = '21111';
        changeRequest.generalInformation.title = 'some itle';
        changeRequest.generalInformation.state = 'DEFINE';
        changeRequest.generalInformation.status = 'DRAFT';
        changeRequest.changeRequestType = 'ND';
        changeRequest.implementationPriority = 3;
        return of(changeRequest);*/
  }
}
