import {Injectable} from '@angular/core';
import {ControlConfigurationModel} from '../shared/models/control-configuration.model';
import {
  FormTestConfigurationModel,
  FormTestGeneralInformationControlConfigurationModel
} from './form-test-configuration.model';
import {Info} from '@asml-angular/common';


@Injectable({
  providedIn: 'root'
})
export class FormTestConfigurationBuilderService {


  constructor() {
  }

  public getFormTestConfiguration(): FormTestConfigurationModel {
    const formTestControlConfigurationModel = new FormTestConfigurationModel();
    formTestControlConfigurationModel.generalInformation = new FormTestGeneralInformationControlConfigurationModel();
    formTestControlConfigurationModel.generalInformation.title =
      new ControlConfigurationModel('generalInformation.title', false, 'Title', 'Title',
        new Info('This is help about title', '', '', '', ''), null, 'READ', 50);
    formTestControlConfigurationModel.generalInformation.state =
      new ControlConfigurationModel('generalInformation.state', false, 'State', 'State',
        new Info('This is help about state', '', '', '', ''), null, 'READ', 50);
    formTestControlConfigurationModel.generalInformation.status =
      new ControlConfigurationModel('generalInformation.status', false, 'Status', 'Status',
        new Info('This is help about status', '', '', '', ''), null, 'READ', 50);
    formTestControlConfigurationModel.changeRequestType =
      new ControlConfigurationModel('changeRequestType', true, 'Type', 'Type',
        new Info('This is help about type', '', '', '', ''), null, 'READ', 5);
    formTestControlConfigurationModel.implementationPriority =
      new ControlConfigurationModel('implementationPriority', false, 'Implementation Priority', 'Implementation Priority',
        new Info('This is help about implementation priority', '', '', '', ''), null, 'READ', 50);
    return formTestControlConfigurationModel;
  }
}
