import {Component, Input} from '@angular/core';
import {UntypedFormControl} from '@angular/forms';
import {ControlConfigurationModel} from '../../shared/models/control-configuration.model';
import {UpdateFieldService} from '../../shared/services/update-field.service';
import {AcceptedChange, RejectedChange} from '@asml-angular/common';
import {CaseObject} from '../../shared/models/mc.model';
import {FieldElement, UpdateFieldRequest, UpdateFieldResponse} from '../../shared/models/field-element.model';

@Component({
  selector: 'aal-mc-input-text',
  templateUrl: './mc-input-text.component.html',
  styleUrls: ['./mc-input-text.component.scss']
})
export class MCInputTextComponent {
  @Input()
  control: UntypedFormControl;
  @Input()
  controlConfiguration: ControlConfigurationModel;
  @Input()
  caseObject: CaseObject;
  @Input()
  maxLength: number;
  isBusy: boolean;
  serverError: string;

  constructor(private readonly updateFieldService: UpdateFieldService) {
  }

  onAcceptChanges($event: AcceptedChange) {
    this.isBusy = true;
    const fieldElement = new FieldElement($event.ID, $event.oldValue, $event.value);
    const updateFieldRequest = new UpdateFieldRequest([fieldElement], null);

    this.updateFieldService.updateField$(this.caseObject, updateFieldRequest).subscribe((response: UpdateFieldResponse) => {
      if (response && response.FieldElement) {
        const fieldElementResponse: FieldElement = response.FieldElement.find(value => value.ID === this.controlConfiguration.ID);
        if (fieldElementResponse.response.status === 'ERROR') {
          this.serverError = fieldElementResponse.response.details;
        }
      } else {
        this.serverError = 'something wen wrong in mychange, log an incident';
      }
      this.isBusy = false;
    });
  }

  onRejectChanges($event: RejectedChange) {
  }
}
