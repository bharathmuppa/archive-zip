import {Component, OnInit} from '@angular/core';
import {UntypedFormBuilder, UntypedFormControl, Validators} from '@angular/forms';
import {Info, Mode, Modes} from '@asml-angular/common';

@Component({
  selector: 'aal-button-toggle-input-test',
  templateUrl: './button-toggle-input-test.component.html',
  styleUrls: ['./button-toggle-input-test.component.scss']
})
export class AALButtonToggleInputTestComponent implements OnInit {
  mode: Mode;
  objectFormControl: UntypedFormControl;
  objectFormSecondaryControl: UntypedFormControl;
  stringFormControl: UntypedFormControl;
  stringFormSecondaryControl: UntypedFormControl;
  alert: Info;
  help: Info;
  secondaryHelp: Info;
  objectOptions: any[];
  objectSecondaryApplicableOptions: any[];
  stringOptions: string[];
  stringSecondaryApplicableOptions: string[];
  stringSecondaryRequiredOptions: string[];
  objectSecondaryRequiredOptions: string[];

  constructor(private readonly fb: UntypedFormBuilder) {
    this.objectFormControl = this.fb.control('');
    this.stringFormControl = this.fb.control('', [Validators.required]);
    this.objectFormSecondaryControl = this.fb.control('');
    this.stringFormSecondaryControl = this.fb.control('');
  }

  ngOnInit() {
    this.objectOptions = [
      {name: 'option1', description: 'description1'},
      {name: 'option2', description: 'description2'},
      {name: 'option3', description: 'description3'}
    ];
    this.objectSecondaryApplicableOptions = ['option2', 'option3'];
    this.objectSecondaryRequiredOptions = ['option2'];
    this.stringOptions = ['option1', 'option2', 'option3'];
    this.stringSecondaryApplicableOptions = ['option2', 'option3'];
    this.stringSecondaryRequiredOptions = ['option2'];

    this.mode = Modes.READ;

    const errorTitle = 'Error Title';
    const errorMessage = 'This is error message with <a target="_blank" href="https://www.google.com">link </a>';
    const errorAnimation = 'https://media.giphy.com/media/1BcfGzv2jCvRl2E4yo/giphy.gif';
    const errorThumbnail = 'https://upload.wikimedia.org/wikipedia/en/6/6c/ASML_Holding_N.V._logo.svg';
    const errorLevel = 'ERROR';
    this.alert = new Info(errorTitle, errorMessage, errorAnimation, errorThumbnail, errorLevel);

    const helpTitle = 'Help Title';
    const helpMessage = 'This is help message with <a target="_blank" href="https://www.google.com">link </a>';
    const helpAnimation = 'https://media.giphy.com/media/1BcfGzv2jCvRl2E4yo/giphy.gif';
    const helpThumbnail = 'https://upload.wikimedia.org/wikipedia/en/6/6c/ASML_Holding_N.V._logo.svg';
    this.help = new Info(helpMessage, helpTitle, helpAnimation, helpThumbnail, null);

    const secondaryHelpTitle = 'Help Title';
    const secondaryHelpMessage = 'This is help message with <a target="_blank" href="https://www.google.com">link </a>';
    const secondaryHelpAnimation = 'https://media.giphy.com/media/1BcfGzv2jCvRl2E4yo/giphy.gif';
    const secondaryHelpThumbnail = 'https://upload.wikimedia.org/wikipedia/en/6/6c/ASML_Holding_N.V._logo.svg';
    this.secondaryHelp = new Info(secondaryHelpMessage, secondaryHelpTitle, secondaryHelpAnimation, secondaryHelpThumbnail, null);

  }

  onAcceptChanges($event) {
    console.log($event);
  }

  onRejectChanges($event) {
    console.log($event);
  }

  onRevertedChanges($event) {
    console.log('reverted');
    console.log($event);
  }
}
