import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'aal-button-icon-test',
  templateUrl: './button-icon-test.component.html',
  styleUrls: ['./button-icon-test.component.scss']
})
export class AALButtonIconTestComponent implements OnInit {

  constructor() {
  }

  ngOnInit() {
  }

  buttonClick(): void {
    console.log('icon button clicked');
  }
}
