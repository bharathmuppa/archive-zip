import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'aal-date-picker-week-test',
  templateUrl: './date-picker-week-test.component.html',
  styleUrls: ['./date-picker-week-test.component.scss']
})
export class AALDatePickerWeekTestComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
