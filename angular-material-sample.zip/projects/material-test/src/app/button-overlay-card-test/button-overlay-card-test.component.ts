import {Component, Input, OnInit} from '@angular/core';
import {
  ActionButtonConfiguration,
  EmptyStateData
} from '../../../../asml-angular/material/src/lib/expansion-panel-list/expansion-panel-list.model';
import {ListItemConfiguration} from '../../../../asml-angular/material/src/lib/shared/list-item-configuration.model';
import {Info} from '@asml-angular/common';


@Component({
  selector: 'aal-button-overlay-card-test',
  templateUrl: './button-overlay-card-test.component.html',
  styleUrls: ['./button-overlay-card-test.component.scss']
})
export class AALButtonOverlayCardTestComponent implements OnInit {
  help: Info;
  headerIcon: string;
  headerTitle: string;
  showCategories: boolean;
  listDetails;
  listDetails1;
  noData;
  categoryDetails: any[];
  categoryDetails1;
  categoryDetails2;
  emptyStateData: EmptyStateData;
  ngOnInit() {
    this.help = new Info('Sample Title', 'Sample Help Message', '', '', null);
    this.headerIcon = 'group';
    this.headerTitle = 'myTeam';
    this.showCategories = true;
    this.listDetails1 = [{case: {ID: '400939-01', revision: 'AA', type: 'Change Request'}},
      {case: {ID: '400939-02', revision: 'BB', type: 'Change Notice'}},
      {case: {ID: '400939-02', revision: 'BB', type: 'Change Notice'}},
      {case: {ID: '400939-02', revision: 'BB', type: 'Change Notice'}},
      {case: {ID: '400939-03', revision: 'CC', type: 'Release Package'}}];
    this.categoryDetails = [
      {
        section: 'UNCATEGORIZED',
        agendaItemDetails: [
          {
            ID: '3690',
            label: '200636',
            labelCaption: 'Approved',
            icon: 'group',
            separator: 'interpunct',
            mainDescription: 'Pellicle 1234 need to be done before implementation',
            subDescription: '13:00 (5m)',
            subDescriptionCaption: 'Wilco Smit (WISM)',
          },
          {
            ID: '3690',
            label: '200636',
            labelCaption: 'Rejected',
            icon: 'group',
            separator: 'interpunct',
            mainDescription: 'Unamplified leakage PEM needs another review',
            subDescription: '13:00 (5m)',
            subDescriptionCaption: 'Wilco Smit (WISM)'
          }
        ]
      },
      {
        section: 'Relevant for Team 299282',
        agendaItemDetails: [
          {
            ID: '3690',
            label: '200636',
            labelCaption: 'Approved',
            icon: 'group',
            separator: 'interpunct',
            mainDescription: 'Pellicle 1234 need to be done before implementation',
            subDescription: '13:00 (5m)',
            subDescriptionCaption: 'Wilco Smit (WISM)'
          },
          {
            ID: '3690',
            label: '200636',
            labelCaption: 'Rejected',
            icon: 'group',
            separator: 'interpunct',
            mainDescription: 'Unamplified leakage PEM needs another review',
            subDescription: '13:00 (5m)',
            subDescriptionCaption: 'Wilco Smit (WISM)'
          }
        ]
      },
      {
        section: 'Section for Team 344',
        agendaItemDetails: [
          {
            ID: '3690',
            label: '200636',
            labelCaption: 'Approved',
            icon: 'group',
            separator: 'interpunct',
            mainDescription: 'Pellicle 1234 need to be done before implementation',
            subDescription: '13:00 (5m)',
            subDescriptionCaption: 'Wilco Smit (WISM)'
          }
        ]
      }
    ];
    this.listDetails = [
      ({
        ID: 'ID1',
        title: 'Fazal Shaik',
        mainDescription: 'Change Specialist',
        subDescription: 'IT O&I Service Integration',
        icon: 'group',
        isClickable: true,
        actionButtonConfiguration: ({
          actionButtonIcon: 'delete',
          actionButtonText: 'buttonText1',
          actionButtonType: 'icon',
          actionButtonTooltip: 'action button tooltip1',
          showActionButton: false,
          action: 'delete'
        }) as ActionButtonConfiguration
      }) as ListItemConfiguration,
      ({
        ID: 'ID11',
        title: 'Fazal Shaik',
        mainDescription: 'Change Specialist2',
        subDescription: 'IT O&I Service Integration',
        icon: 'group',
        isClickable: true,
        actionButtonConfiguration: ({
          actionButtonIcon: 'delete',
          actionButtonText: 'buttonText1',
          actionButtonType: 'icon',
          actionButtonTooltip: 'action button tooltip1',
          showActionButton: false,
          action: 'delete'
        }) as ActionButtonConfiguration
      }) as ListItemConfiguration,
      ({
        ID: 'ID2',
        title: 'Suresh Upthula',
        mainDescription: 'Change Specialist',
        subDescription: 'IT O&I Service Integration',
        icon: 'group',
        isClickable: true,
        actionButtonConfiguration: ({
          actionButtonIcon: 'delete',
          actionButtonText: 'buttonText2',
          actionButtonType: 'icon',
          actionButtonTooltip: 'action button tooltip2',
          showActionButton: false,
          action: 'delete'
        }) as ActionButtonConfiguration
      }) as ListItemConfiguration,
      ({
        ID: 'ID3',
        title: 'Rayyan',
        mainDescription: 'Change Specialist',
        subDescription: 'IT O&I Service Integration',
        icon: 'group',
        isClickable: false,
        actionButtonConfiguration: ({
          actionButtonIcon: 'delete',
          actionButtonText: 'buttonText3',
          actionButtonType: 'icon',
          actionButtonTooltip: 'action button tooltip3',
          showActionButton: false,
          action: 'delete'
        }) as ActionButtonConfiguration
      }) as ListItemConfiguration
    ];
    this.noData = {
    };

    this.categoryDetails1 = {
      'TotalItems': 3,
      'category': [
        {
          'section_name': 'Section 1',
          'item_key': [
            {
              ID: '3690',
              label: '200636',
              labelCaption: 'Approved',
              icon: 'group',
              separator: 'interpunct',
              mainDescription: 'Pellicle 1234 need to be done before implementation',
              subDescription: '13:00 (5m)',
              subDescriptionCaption: 'Wilco Smit (WISM)',
            },
            {
              ID: '3690',
              label: '200636',
              labelCaption: 'Rejected',
              icon: 'group',
              separator: 'interpunct',
              mainDescription: 'Unamplified leakage PEM needs another review',
              subDescription: '13:00 (5m)',
              subDescriptionCaption: 'Wilco Smit (WISM)'
            }
          ]
        }
      ]
    };

    this.categoryDetails2 = {
      'TotalItems': 3,
      'category': [
        {
          'section_name': 'Section 1',
          'item_key': ['abc', 'def', 'xyz']
        },
        {
          'section_name': 'Section 2',
          'item_key': ['abc', 'def', 'xyz']
        }
      ]
    };

    this.emptyStateData = {
      title: 'No Items',
      subTitle: 'All items Will Appear Here',
      icon: 'list'
    };
  }

  buttonClick() {
    console.log('Overlay button clicked');
  }
}
