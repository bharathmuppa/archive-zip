import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'aal-button-text-test',
  templateUrl: './button-text-test.component.html',
  styleUrls: ['./button-text-test.component.scss']
})
export class AALButtonTextTestComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
