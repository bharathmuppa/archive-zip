import {Component, OnInit} from '@angular/core';
import {SortingConfiguration} from '../../../../asml-angular/material/src/lib/shared/list-item-configuration.model';

@Component({
  selector: 'aal-button-overlay-tabbed-test',
  templateUrl: './button-overlay-tabbed-test.component.html',
  styleUrls: ['./button-overlay-tabbed-test.component.scss']
})
export class AALButtonOverlayTabbedTestComponent implements OnInit {
  headerTabbedIcon: string;
  headerTabbedTitle: string;
  overlayData;
  data;
  overviewListActiveSort: string;
  sortingConfiguration;
  selectedIndex: number;
  largeAmountsLength: number;
  panelCloseOnItemClick: boolean;


  ngOnInit() {
    this.headerTabbedIcon = 'calendar_today';
    this.headerTabbedTitle = 'Tabbed Button';
    this.selectedIndex = 1;
    this.largeAmountsLength = 1;
    this.overlayData = {
    "TotalItems":"5",
    "categories":[
        {
        "name":"Online",
        "totalAgendaItems":5,
        "sub-categories":[
            {
            "name":"UNCATEGORIZED",
            "items":[
                {
                "ID":"4156",
                "section":"UNCATEGORIZED",
                "link":{
                  "ID":"581064",
                  "type":"ChangeRequest",
                  "title":"2nd May CR",
                  "status":"APPROVED"
                  },
                "plannedDuration":"PT20M",
                "presenter":{
                  "userID":"smahamma",
                  "fullName":"Sirajuddin Rayyan Mahammad",
                  "email":"sirajuddinrayyan.mahammad@asml.qas",
                  "abbreviation":"SIRM",
                  "departmentName":"IT BAS CC Corporate BPI & Automation"
                  },
                "startDateTime":"2019-06-27T07:30:00Z",
                "agendaSequenceNumber":2,
                "isAOB":false,
                "purpose":"DECISION"
                },
                {
                "ID":"4162",
                "section":"UNCATEGORIZED",
                "link":{
                  "ID":"400180",
                  "type":"ChangeNotice",
                  "title":"New CR",
                  "status":"DRAFT"
                  },
                  'plannedDuration': 'PT0S',
                  'startDateTime': '2019-06-27T07:30:00Z',
                  'agendaSequenceNumber': 5,
                  'isAOB': false,
                  'purpose': 'DECISION'
                }
              ]
            },
            {
              'name': 'Section 3',
              'items': [
                {
                  'ID': '4157',
                  'section': 'Section 3',
                  'link': {
                    'ID': '577854',
                    'type': 'ChangeRequest',
                    'title': 'New saSsSsS',
                    'status': 'APPROVED'
                  },
                  'plannedDuration': 'PT30M',
                  'presenter': {
                    'userID': 'smahamma',
                    'fullName': 'Sirajuddin Rayyan Mahammad',
                    'email': 'sirajuddinrayyan.mahammad@asml.qas',
                    'abbreviation': 'SIRM',
                    'departmentName': 'IT BAS CC Corporate BPI & Automation'
                  },
                  'startDateTime': '2019-06-27T07:30:00Z',
                  'agendaSequenceNumber': 3,
                  'isAOB': false
                },
                {
                  'ID': '4160',
                  'section': 'Section 3',
                  'link': {
                    'ID': '636276',
                    'type': 'ChangeRequest',
                    'title': 'New CR',
                    'status': 'APPROVED'
                  },
                  'plannedDuration': 'PT30M',
                  'presenter': {
                    'userID': 'ptummala',
                    'fullName': 'Parameswari Tummala',
                    'email': 'parameswari.tummala@asml.qas',
                    'abbreviation': 'PTUM',
                    'departmentName': 'IT BAS CC Corporate BPI & Automation'
                  },
                  'startDateTime': '2019-06-27T07:30:00Z',
                  'agendaSequenceNumber': 4,
                  'isAOB': false
                }
              ]
            },
            {
              'name': 'Section 1',
              'items': [
                {
                  'ID': '4161',
                  'section': 'Section 1',
                  'link': {
                    'ID': '597114',
                    'type': 'ChangeRequest',
                    'title': 'New CR',
                    'status': 'APPROVED'
                  },
                  'plannedDuration': 'PT0S',
                  'startDateTime': '2019-06-27T07:30:00Z',
                  'agendaSequenceNumber': 1,
                  'isAOB': false,
                  'purpose': 'DECISION'
                }
              ]
            }
          ]
        },
        {
          'name': 'Offline',
          'totalAgendaItems': 0
        }
      ]
    };

    this.data = {
      'TotalItems': '7',
      'categories': [
        {
          'name': 'CR',
          'totalItems': '1',
          'sub-categories': [
            {
              'items': [
                {
                  'link': {
                    'ID': '555384',
                    'revision': 'AA',
                    'type': 'ChangeRequest',
                    'title': 'title title title title title title title title title titletitle title title title title title title title title title'
                  }
                }
              ]
            }
          ]
        },
        {
          'name': 'CN',
          'totalItems': '1',
          'sub-categories': [
            {
              'items': [
                {
                  'link': {
                    'ID': '400161',
                    'revision': 'AA',
                    'type': 'ChangeNotice',
                    'title': 'New CN 25April'
                  }
                }
              ]
            }
          ]
        },
        {
          'name': 'AG',
          'totalItems': '26',
          'sub-categories': [
            {
              'items': [
                {
                  'link': {
                    'ID': '3246',
                    'type': 'Agenda',
                    'title': 'Canceled: CCB for mychange demo(Copy)'
                  }
                },
                {
                  'link': {
                    'ID': '3226',
                    'type': 'Agenda',
                    'title': 'Canceled: CCB for mychange demo(Copy)'
                  }
                },
                {
                  'link': {
                    'ID': '3106',
                    'type': 'Agenda',
                    'title': 'Hand-in your laptop: LT406389 for Windows 10 rollout(Copy)'
                  }
                },
                {
                  'link': {
                    'ID': '3105',
                    'type': 'Agenda',
                    'title': 'Hand-in your laptop: LT406389 for Windows 10 rollout(Copy)'
                  }
                },
                {
                  'link': {
                    'ID': '3104',
                    'type': 'Agenda',
                    'title': 'Canceled: CCB for mychange demo(Copy)'
                  }
                },
                {
                  'link': {
                    'ID': '3103',
                    'type': 'Agenda',
                    'title': 'myChange Daily Standup(Copy)'
                  }
                },
                {
                  'link': {
                    'ID': '2881',
                    'type': 'Agenda',
                    'title': 'CCB for mychange demo(Copy)'
                  }
                },
                {
                  'link': {
                    'ID': '2880',
                    'type': 'Agenda',
                    'title': 'CCB for mychange demo(Copy)'
                  }
                },
                {
                  'link': {
                    'ID': '2860',
                    'type': 'Agenda',
                    'title': 'SI_24June'
                  }
                },
                {
                  'link': {
                    'ID': '2828',
                    'type': 'Agenda',
                    'title': 'Hand-in your laptop: LT406389 for Windows 10 rollout'
                  }
                },
                {
                  'link': {
                    'ID': '2827',
                    'type': 'Agenda',
                    'title': 'ONE CM Coffee Corner (weekly)'
                  }
                },
                {
                  'link': {
                    'ID': '2826',
                    'type': 'Agenda',
                    'title': 'test678'
                  }
                },
                {
                  'link': {
                    'ID': '2823',
                    'type': 'Agenda',
                    'title': '19th June DEV'
                  }
                },
                {
                  'link': {
                    'ID': '2820',
                    'type': 'Agenda',
                    'title': 'New CB Agenda'
                  }
                },
                {
                  'link': {
                    'ID': '2819',
                    'type': 'Agenda',
                    'title': 'CCB for mychange demo(Copy)'
                  }
                },
                {
                  'link': {
                    'ID': '2804',
                    'type': 'Agenda',
                    'title': 'Release 2.11 Document management call'
                  }
                },
                {
                  'link': {
                    'ID': '2801',
                    'type': 'Agenda',
                    'title': 'myChange Daily Standup'
                  }
                },
                {
                  'link': {
                    'ID': '2780',
                    'type': 'Agenda',
                    'title': 'Internal Sync Up Call'
                  }
                },
                {
                  'link': {
                    'ID': '2770',
                    'type': 'Agenda',
                    'title': 'New CB Agenda'
                  }
                },
                {
                  'link': {
                    'ID': '2763',
                    'type': 'Agenda',
                    'title': 'Internal Sync Up Call'
                  }
                },
                {
                  'link': {
                    'ID': '2762',
                    'type': 'Agenda',
                    'title': 'test Lion'
                  }
                },
                {
                  'link': {
                    'ID': '2740',
                    'type': 'Agenda',
                    'title': 'New CB Agenda'
                  }
                },
                {
                  'link': {
                    'ID': '2175',
                    'type': 'Agenda',
                    'title': 'New CB Agenda'
                  }
                },
                {
                  'link': {
                    'ID': '2096',
                    'type': 'Agenda',
                    'title': 'CCB Dirk'
                  }
                },
                {
                  'link': {
                    'ID': '2061',
                    'type': 'Agenda',
                    'title': 'CCB Dirk'
                  }
                },
                {
                  'link': {
                    'ID': '2060',
                    'type': 'Agenda',
                    'title': 'New CB Agenda New CB Agenda New CB Agenda'
                  }
                }
              ]
            }
          ]
        },
        {
          'name': 'AI',
          'totalItems': '26',
          'sub-categories': [
            {
              'items': [
                {
                  'link': {
                    'ID': '4655',
                    'type': 'AgendaItem',
                    'title': 'title title title title title title title title title titletitle title title title title title title title title title'
                  }
                },
                {
                  'link': {
                    'ID': '4599',
                    'type': 'AgendaItem',
                    'title': 'title title title title title title title title title titletitle title title title title title title title title title'
                  }
                },
                {
                  'link': {
                    'ID': '4563',
                    'type': 'AgendaItem',
                    'title': 'title title title title title title title title title titletitle title title title title title title title title title'
                  }
                },
                {
                  'link': {
                    'ID': '4511',
                    'type': 'AgendaItem',
                    'title': 'title title title title title title title title title titletitle title title title title title title title title title'
                  }
                },
                {
                  'link': {
                    'ID': '4493',
                    'type': 'AgendaItem',
                    'title': 'title title title title title title title title title titletitle title title title title title title title title title'
                  }
                },
                {
                  'link': {
                    'ID': '4475',
                    'type': 'AgendaItem',
                    'title': 'title title title title title title title title title titletitle title title title title title title title title title'
                  }
                },
                {
                  'link': {
                    'ID': '4463',
                    'type': 'AgendaItem',
                    'title': 'title title title title title title title title title titletitle title title title title title title title title title'
                  }
                },
                {
                  'link': {
                    'ID': '4456',
                    'type': 'AgendaItem',
                    'title': 'title title title title title title title title title titletitle title title title title title title title title title'
                  }
                },
                {
                  'link': {
                    'ID': '4195',
                    'type': 'AgendaItem',
                    'title': 'title title title title title title title title title titletitle title title title title title title title title title'
                  }
                },
                {
                  'link': {
                    'ID': '4188',
                    'type': 'AgendaItem',
                    'title': 'title title title title title title title title title titletitle title title title title title title title title title'
                  }
                },
                {
                  'link': {
                    'ID': '4119',
                    'type': 'AgendaItem',
                    'title': 'title title title title title title title title title titletitle title title title title title title title title title'
                  }
                },
                {
                  'link': {
                    'ID': '4114',
                    'type': 'AgendaItem',
                    'title': 'title title title title title title title title title titletitle title title title title title title title title title'
                  }
                },
                {
                  'link': {
                    'ID': '4054',
                    'type': 'AgendaItem',
                    'title': 'title title title title title title title title title titletitle title title title title title title title title title'
                  }
                },
                {
                  'link': {
                    'ID': '4039',
                    'type': 'AgendaItem',
                    'title': 'title title title title title title title title title titletitle title title title title title title title title title'
                  }
                },
                {
                  'link': {
                    'ID': '4026',
                    'type': 'AgendaItem',
                    'title': 'title title title title title title title title title titletitle title title title title title title title title title'
                  }
                },
                {
                  'link': {
                    'ID': '3976',
                    'type': 'AgendaItem',
                    'title': 'title title title title title title title title title titletitle title title title title title title title title title'
                  }
                },
                {
                  'link': {
                    'ID': '3947',
                    'type': 'AgendaItem',
                    'title': 'MULTIPLE AIR ISSUES - To introduce performance test (Calibration) stand @ supplier (Neways) for [OADB MK3]'
                  }
                },
                {
                  'link': {
                    'ID': '3945',
                    'type': 'AgendaItem',
                    'title': 'title title title title title title title title title titletitle title title title title title title title title title'
                  }
                },
                {
                  'link': {
                    'ID': '3929',
                    'type': 'AgendaItem',
                    'title': 'title title title title title title title title title titletitle title title title title title title title title title'
                  }
                },
                {
                  'link': {
                    'ID': '3913',
                    'type': 'AgendaItem',
                    'title': 'title title title title title title title title title titletitle title title title title title title title title title'
                  }
                },
                {
                  'link': {
                    'ID': '3898',
                    'type': 'AgendaItem',
                    'title': 'title title title title title title title title title titletitle title title title title title title title title title'
                  }
                },
                {
                  'link': {
                    'ID': '3815',
                    'type': 'AgendaItem',
                    'title': 'title title title title title title title title title titletitle title title title title title title title title title'
                  }
                },
                {
                  'link': {
                    'ID': '3801',
                    'type': 'AgendaItem',
                    'title': 'title title title title title title title title title titletitle title title title title title title title title title'
                  }
                },
                {
                  'link': {
                    'ID': '3754',
                    'type': 'AgendaItem',
                    'title': 'title title title title title title title title title titletitle title title title title title title title title title'
                  }
                },
                {
                  'link': {
                    'ID': '3741',
                    'type': 'AgendaItem',
                    'title': 'title title title title title title title title title titletitle title title title title title title title title title'
                  }
                },
                {
                  'link': {
                    'ID': '3738',
                    'type': 'AgendaItem',
                    'title': 'title title title title title title title title title titletitle title title title title title title title title title'
                  }
                }
              ]
            }
          ]
        },
        {
          'name': 'RP',
          'totalItems': '11',
          'sub-categories': [
            {
              'items': [
                {
                  'link': {
                    'ID': '400161-01',
                    'revision': 'AA',
                    'type': 'ReleasePackage',
                    'title': 'New RP'
                  }
                },
                {
                  'link': {
                    'ID': '400161-02',
                    'revision': 'AA',
                    'type': 'ReleasePackage',
                    'title': 'New CR'
                  }
                },
                {
                  'link': {
                    'ID': '400161-03',
                    'revision': 'AA',
                    'type': 'ReleasePackage',
                    'title': 'New CR'
                  }
                },
                {
                  'link': {
                    'ID': '400161-04',
                    'revision': 'AA',
                    'type': 'ReleasePackage',
                    'title': 'New CR'
                  }
                },
                {
                  'link': {
                    'ID': '400161-05',
                    'revision': 'AA',
                    'type': 'ReleasePackage',
                    'title': 'New CR'
                  }
                },
                {
                  'link': {
                    'ID': '400161-06',
                    'revision': 'AA',
                    'type': 'ReleasePackage',
                    'title': 'New CR'
                  }
                },
                {
                  'link': {
                    'ID': '400161-07',
                    'revision': 'AA',
                    'type': 'ReleasePackage',
                    'title': 'New CR'
                  }
                },
                {
                  'link': {
                    'ID': '400161-08',
                    'revision': 'AA',
                    'type': 'ReleasePackage',
                    'title': 'New CR1111111'
                  }
                },
                {
                  'link': {
                    'ID': '400161-09',
                    'revision': 'AA',
                    'type': 'ReleasePackage',
                    'title': 'New CR'
                  }
                },
                {
                  'link': {
                    'ID': '400161-10',
                    'revision': 'AA',
                    'type': 'ReleasePackage',
                    'title': 'New CR'
                  }
                },
                {
                  'link': {
                    'ID': '400161-11',
                    'revision': 'AA',
                    'type': 'ReleasePackage',
                    'title': 'New CR'
                  }
                }
              ]
            }
          ]
        },
        {
          'name': 'CP',
          'totalItems': '1',
          'sub-categories': [
            {
              'items': [
                {
                  'link': {
                    'ID': '400161',
                    'revision': 'AA',
                    'type': 'ChangeNotice',
                    'title': 'New CN 25April'
                  }
                }
              ]
            }
          ]
        },
        {
          'name': 'CD',
          'totalItems': '1',
          'sub-categories': [
            {
              'items': [
                {
                  'link': {
                    'ID': '400161',
                    'revision': 'AA',
                    'type': 'ChangeNotice',
                    'title': 'New CN 25April'
                  }
                }
              ]
            }
          ]
        }
      ]
    };

    this.overviewListActiveSort = 'ASC';
    this.sortingConfiguration = this.getCaseObjectSortingConfiguration('linkedItems');
  }

  getCaseObjectSortingConfiguration(caseObjectType): SortingConfiguration {
    switch (caseObjectType) {
      case 'changeRequest':
        return {
          title: 'Sort CRs on',
          sortingHeaders: [
            {label: 'Action due date', id: 'action.deadline'},
            {label: 'Prio (of CR)', id: 'priority'},
            {label: 'Creation date (of CR)', id: 'createdOn'},
            {label: 'Status of CR (\'Draft\' first)', id: 'status'}]
        };
      case 'changeNotice':
        return {
          title: 'Sort CNs on',
          sortingHeaders: [
            {label: 'Action due date', id: 'action.deadline'},
            {label: 'Prio (of CN)', id: 'priority'},
            {label: 'Creation date (of CN)', id: 'createdOn'},
            {label: 'Status of CN (\'Draft\' first)', id: 'status'}]
        };
      case 'releasePackage':
        return {
          title: 'Sort RPs on',
          sortingHeaders: [
            {label: 'Planned Release Date', id: 'plannedReleaseDate'},
            {label: 'Planned Effective Date', id: 'plannedEffectiveDate'},
            {label: 'Action due date', id: 'action.deadline'},
            {label: 'Open actions', id: 'openActionsCount'},
            {label: 'Creation date', id: 'createdOn'},
            {label: 'Status (\'new\' first)', id: 'status'}]
        };
      case 'linkedItems':
        return {
          title: 'Sort RPs on',
          sortingHeaders: [
            {label: 'RP ID', id: 'ID'},
            {label: 'PRD', id: 'plannedReleaseDate'}]
        };
      case 'agenda':
        return {
          title: 'Sort Agendas on',
          sortingHeaders: [
            {label: 'Title', id: 'generalInformation.title'},
            {label: 'Created By', id: 'generalInformation.createdBy.fullName'},
            {label: 'Meeting date', id: 'startDateTime'},
            {label: 'Status', id: 'generalInformation.status'},
            {label: 'Created On', id: 'generalInformation.createdOn'}
          ]
        };
    }
  }

  triggerOverviewListSortChange($event) {
    console.log('List Sort change' + $event);
  }

  selectedTabClick($event) {
    console.log($event);
  }

  showAllClick() {
    console.log('Show All');
    // this.showAllItems.emit();
  }

  onOverLayTabbedListItemClick($event) {
  console.log("OverlayTabbedCliekced="+$event);
  }

  panelClose() {
    this.panelCloseOnItemClick = !this.panelCloseOnItemClick;
  }

  onOverlayTabbedPanelOpen($event) {
    console.log('Overlay panel tabbed opened');
  }
}
