import {Component, OnInit} from '@angular/core';
import {UntypedFormControl, Validators} from '@angular/forms';
import {Info, Modes} from '@asml-angular/common';

@Component({
  selector: 'aal-input-duration-test',
  templateUrl: './input-duration-test.component.html',
  styleUrls: ['./input-duration-test.component.scss']
})
export class AALInputDurationTestComponent implements OnInit {
  formControl: UntypedFormControl;
  formControl2: UntypedFormControl;
  formControlTest: UntypedFormControl;
  alert: Info;
  help: Info;
  pattern: RegExp;
  modes = Modes;
  constructor() {
  }

  ngOnInit() {
   // this.pattern = /^\d(\d*)(yr|YR|Yr|yR)?\s*(\d*)(mo|MO|Mo|mO)?\s*(\d*)([dD]?)\s*(<![0-9])$|^[0-9]*$/;
   // this.pattern = /^\d+((\d*(\.\d)?\d?)(yr|YR|Yr|yR))?\s*((\d*)(mo|MO|Mo|mO))?\s*((\d*)[dD])?\s*(?![0-9])$|^\d+\.\d\d?$/;
    this.pattern = /^\d+((\d*(\.\d)?\d?)(yr|YR|Yr|yR))?\s*((\d*(\.\d)?\d?)(mo|MO|Mo|mO))?\s*((\d*)[dD])?\s*(?![0-9])$|^\d+\.\d\d?$/;
    /* ^\d(\d*)([hH]?)\s*(\d*)([mM]?)(?![0-9])$|^\d(\d*):([0-5][0-9]$)|
        this.formControl = new FormControl(String(moment.duration({
          hours: new Date().getHours(),
          minutes: new Date().getMinutes()
        })),  {updateOn: 'blur', validators: [Validators.required]});
    */

    this.formControl = new UntypedFormControl('PT0S');
    this.formControl2 = new UntypedFormControl('', [Validators.required]);

    const errorTitle = 'Error Title';
    const errorMessage = 'This is error message with <a target="_blank" href="https://www.google.com">link </a>';
    const errorAnimation = 'https://media.giphy.com/media/1BcfGzv2jCvRl2E4yo/giphy.gif';
    const errorThumbnail = 'https://upload.wikimedia.org/wikipedia/en/6/6c/ASML_Holding_N.V._logo.svg';
    const errorLevel = 'ERROR';
    this.alert = new Info(errorTitle, errorMessage, errorAnimation, errorThumbnail, errorLevel);

    const helpTitle = 'Help Title';
    const helpMessage = 'This is help message with <a target="_blank" href="https://www.google.com">link </a>';
    const helpAnimation = 'https://media.giphy.com/media/1BcfGzv2jCvRl2E4yo/giphy.gif';
    const helpThumbnail = 'https://upload.wikimedia.org/wikipedia/en/6/6c/ASML_Holding_N.V._logo.svg';
    this.help = new Info(helpTitle, helpMessage, helpAnimation, helpThumbnail, null);
  }

  onAcceptChanges($event) {
    console.log($event);
  }

  onRejectChanges($event) {
    console.log($event);
  }
}
