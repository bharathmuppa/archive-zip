import {Component, OnInit} from '@angular/core';
import {ListItemConfiguration, ImageShapes} from '../../../../asml-angular/material/src/lib/shared/list-item-configuration.model';


@Component({
  selector: 'aal-card-summary-test',
  templateUrl: './card-summary-test.component.html',
  styleUrls: ['./card-summary-test.component.scss']
})
export class AALCardSummaryTestComponent implements OnInit {
  cardSummaryData: ListItemConfiguration;
  cardSummaryData1: any;
  cardSummaryData2: any;
  cardSummaryData3: any;
  imageShapes: any;
  showActionButtonOnFocus: boolean;
  hasFocus: boolean;
  ngOnInit() {
    this.imageShapes = ImageShapes;
    this.showActionButtonOnFocus = true;
    this.cardSummaryData = {
      label: 'Change Specialist',
      labelCaption: '0014',
      mainDescription: 'Rayyan Siraj',
      mainDescriptionCaption: '1111',
      subDescription: 'Abcd',
      subDescriptionCaption: '1234',
      icon: '',
      imageView: 'circle',
      separator: 'parenthesis',
      imageURL: 'https://people.asml.com/_layouts/15/userphoto.aspx?size=M&accountname=asml%2Dcom%5Csmahamma'
    };
    this.cardSummaryData1 = {
      label: 'Decision',
      labelCaption: '0017',
      mainDescription: 'Fazal Shaik',
      mainDescriptionCaption: '2222',
      subDescription: 'Abcd',
      subDescriptionCaption: '1234',
      icon: 'group',
      imageView: '',
      separator: 'parenthesis',
      imageURL: ''
    };
    this.cardSummaryData2 = {
      label: 'Presenter',
      labelCaption: '0014',
      mainDescription: 'Anil Kumar',
      mainDescriptionCaption: '1212',
      subDescription: '',
      subDescriptionCaption: '',
      icon: '',
      imageView: 'full',
      separator: 'hyphen',
      imageURL: 'https://people.asml.com/_layouts/15/userphoto.aspx?size=M&accountname=asml%2Dcom%5Canikumar'
    };
    this.cardSummaryData3 = {
      label: 'Priority of Implementation',
      mainDescription: ' - ' + '<p>This is <b>High</b> Prio</p>'
    };
  }

  onLabelClick(label) {
    alert(label);
  }

}
