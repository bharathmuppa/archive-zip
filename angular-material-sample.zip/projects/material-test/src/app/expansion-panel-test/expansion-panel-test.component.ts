import { Component, OnInit } from '@angular/core';
import {Info} from '@asml-angular/common';

@Component({
  selector: 'aal-expansion-panel-test',
  templateUrl: './expansion-panel-test.component.html',
  styleUrls: ['./expansion-panel-test.component.scss']
})
export class AALExpansionPanelTestComponent implements OnInit {
  alert: Info;
  constructor() { }

  ngOnInit() {
    const errorTitle = 'Error Title';
    const errorMessage = 'This is error message with <a target="_blank" href="https://www.google.com">link </a>';
    const errorAnimation = 'https://media.giphy.com/media/1BcfGzv2jCvRl2E4yo/giphy.gif';
    const errorThumbnail = 'https://upload.wikimedia.org/wikipedia/en/6/6c/ASML_Holding_N.V._logo.svg';
    const errorLevel = 'ERROR';
    this.alert = new Info(errorTitle, errorMessage, errorAnimation, errorThumbnail, errorLevel);
  }

}
