import {Component, OnInit} from '@angular/core';
import {UntypedFormBuilder, UntypedFormControl, Validators} from '@angular/forms';
import {FilterService} from './auto-complete-test.service';
import {Modes} from '@asml-angular/common';
import {of} from "rxjs";

@Component({
  selector: 'aal-auto-complete-test',
  templateUrl: './auto-complete-test.component.html',
  styleUrls: ['./auto-complete-test.component.scss']
})
export class AALAutoCompleteTestComponent implements OnInit {
  control: UntypedFormControl;
  textControl: UntypedFormControl;
  testControl: UntypedFormControl;
  emptyControl: UntypedFormControl;
  modes = Modes;
  dataSource: any;
  dataSource2: any;
  dataSource4: any;
  dataSourceFC: any;
  controlFC: UntypedFormControl;
  multiAutoControl: UntypedFormControl;
  multiAutoControl2: UntypedFormControl;
  multiAutoControl3: UntypedFormControl;
  dataSource3: any;
  data: any;
  data1: any;
  autoCompleteMultiControl: UntypedFormControl;
  autoCompleteMultiData1: any;
  autoCompleteMultiData2: any;
  autoCompleteMultiData3: any;

  constructor(public readonly filterService: FilterService,
              private readonly formBuilder: UntypedFormBuilder) {
    this.data = {
      abbreviation: 'HKBI',
      departmentName: 'IT BAS CC Corporate BPI & Automation',
      email: 'harshit.kapoor@asml.net',
      fullName: 'Harshit Kapoor',
      photoURL: 'https://people1.asml.com/_layouts/15/userphoto.aspx?size=M&accountname=asml%2Dcom%5Chkapoor342',
      roles: ['changeSpecialist1'],
      userID: 'hkapoor'
    };
    this.data1 = {
      abbreviation: 'FAZS',
      departmentName: 'IT BAS CC Corporate BPI & Automation',
      email: 'fazal.shaik@asml.com',
      fullName: 'Fazal Shaik',
      photoURL: 'https://people.asml.com/_layouts/15/userphoto.aspx?size=M&accountname=asml%2Dcom%5Chkapoor',
      roles: ['changeSpecialist1'],
      userID: 'fshaik'
    };
    this.control = new UntypedFormControl(null, [Validators.required]);
    this.textControl = new UntypedFormControl('', Validators.required);
    this.testControl = new UntypedFormControl(this.data, Validators.required);
    this.emptyControl = new UntypedFormControl('', Validators.required);
    this.controlFC = new UntypedFormControl('');
    this.multiAutoControl = new UntypedFormControl(null, [Validators.required]);
    this.multiAutoControl2 = new UntypedFormControl([this.data, this.data1], [Validators.required]);
    this.multiAutoControl3 = new UntypedFormControl([]);
  }

  ngOnInit() {
    this.dataSource3 = ( () => of(["ABCD", "DSAS", "SSWS", "DSDS", "SASA"]));
    this.dataSource4 = ( () => of(["OP-00000172", "OP-00000101", "OP-00000189", "OP-00000173", "00000874"]));
    this.dataSource = this.filterService.getUsers$.bind(this.filterService);
    this.dataSource2 = ( () => of([{
      abbreviation: 'FAZS',
      departmentName: 'IT BAS CC Corporate BPI & Automation',
      email: 'fazal.shaik@asml.com',
      fullName: 'Fazal Shaik',
      photoURL: 'https://people.asml.com/_layouts/15/userphoto.aspx?size=M&accountname=asml%2Dcom%5Chkapoor123',
      roles: ['changeSpecialist1'],
      userID: 'fshaik',
      stream: 'A'
    },{
      abbreviation: 'FAZS',
      departmentName: 'IT BAS CC Corporate BPI & Automation',
      email: 'fazal.shaik@asml.com',
      fullName: 'Fazal Shaik',
      photoURL: 'https://people.asml.com/_layouts/15/userphoto.aspx?size=M&accountname=asml%2Dcom%5Chkapoor123',
      roles: ['changeSpecialist1'],
      userID: 'fshaik',
      stream: 'A'
    },{
      abbreviation: 'FAZS',
      departmentName: 'IT BAS CC Corporate BPI & Automation',
      email: 'fazal.shaik@asml.com',
      fullName: 'Fazal Shaik',
      photoURL: 'https://people.asml.com/_layouts/15/userphoto.aspx?size=M&accountname=asml%2Dcom%5Chkapoor123',
      roles: ['changeSpecialist1'],
      userID: 'fshaik',
      stream: 'H'
    },{
      abbreviation: 'FAZS',
      departmentName: 'IT BAS CC Corporate BPI & Automation',
      email: 'fazal.shaik@asml.com',
      fullName: 'Fazal Shaik',
      photoURL: 'https://people.asml.com/_layouts/15/userphoto.aspx?size=M&accountname=asml%2Dcom%5Chkapoor123',
      roles: ['changeSpecialist1'],
      userID: 'fshaik',
      stream: 'H'
    }]));
    this.dataSourceFC = this.filterService.getFCs.bind(this.filterService);

    this.autoCompleteMultiData1 = {
      abbreviation: 'NRSV',
      departmentName: 'IT myChange',
      email: 'ramasivavarma.nadimpalli@asml.com',
      fullName: 'Rama Siva Varma Nadimpalli',
      photoURL: 'https://people.asml.com/_layouts/15/userphoto.aspx?size=M&accountname=asml%2Dcom%5Crnadimpa',
      roles: ['changeSpecialist1'],
      userID: 'rnadimpa'
    };

    this.autoCompleteMultiData2 = {
      abbreviation: 'NRSV',
      departmentName: 'IT myChange',
      email: 'ramasivavarma.nadimpalli@asml.com',
      fullName: 'Rama Siva Varma Nadimpalli',
      photoURL: 'https://people.asml.com/_layouts/15/userphoto.aspx?size=M&accountname=asml%2Dcom%5Crnadimpa',
      roles: ['changeSpecialist1'],
      userID: 'rnadimpa'
    };

    this.autoCompleteMultiData3 = {
      abbreviation: 'NRSV',
      departmentName: 'IT myChange',
      email: 'ramasivavarma.nadimpalli@asml.com',
      fullName: 'Rama Siva Varma Nadimpalli',
      photoURL: 'https://people.asml.com/_layouts/15/userphoto.aspx?size=M&accountname=asml%2Dcom%5Crnadimpa',
      roles: ['changeSpecialist1'],
      userID: 'rnadimpa'
    };

    this.autoCompleteMultiControl = new UntypedFormControl([this.autoCompleteMultiData1, this.autoCompleteMultiData2, this.autoCompleteMultiData3], [Validators.required])
  }


  onAcceptChanges($event: Event) {
    console.log($event);
  }

  onRejectChanges($event: Event) {
    console.log($event);
  }
}
