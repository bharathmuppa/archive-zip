import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { Observable, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class FilterService {

  constructor(private readonly http: HttpClient) {
  }

  getUsers$(user: string): Observable<Array<any>> {
    if (user && user.length === 0) {
      return of([]);
    }
    const url = `${environment.rootURL}gds${environment.version}/users`;
    return this.http.get(`${url}?name=${user}`).pipe(
      map((request) => {
        return request ? (request['users'] ? request['users'] : []) : [];
      }, catchError(() => {
        return of([]);
      }))
    );
  }

  getFCs(input: string) {
    if (input && input.length === 0) {
      return of([]);
    }
    const url = `${environment.rootURL}cerberus${environment.version}/functional-clusters`;
    return this.http.get(`${url}?id=${input}`).pipe(
      map((request) => {
        return request ? (request['functionalClusters'] ? request['functionalClusters'] : []) : [];
      }, catchError(() => {
        return of([]);
      }))
    );
  }
}

