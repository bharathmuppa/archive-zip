import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {AppComponent} from './app.component';
import {AALInputTextTestComponent} from './input-text-test/input-text-test.component';
import {AALInputDurationTestComponent} from './input-duration-test/input-duration-test.component';
import {AALInputCurrencyTestComponent} from './input-currency-test/input-currency-test.component';
import {AALInputTimeTestComponent} from './input-time-test/input-time-test.component';
import {AALInputLinkTestComponent} from './input-link-test/input-link-test.component';
import {AALInputDurationModule} from '../../../asml-angular/material/src/lib/input-duration/input-duration.module';
import {AALInputCurrencyModule} from '../../../asml-angular/material/src/lib/input-currency/input-currency.module';
import {AALInputTextModule} from '../../../asml-angular/material/src/lib/input-text/input-text.module';
import {AALInputTimeModule} from '../../../asml-angular/material/src/lib/input-time/input-time.module';
import {AALInputLinkModule} from '../../../asml-angular/material/src/lib/input-link/input-link.module';
import {AALThemingTestComponent} from './theming-test/theming-test.component';
import {SharedFormModule} from '../../../asml-angular/material/src/lib/shared/shared-form.module';
import {SharedMaterialModule} from '../../../asml-angular/material/src/lib/shared/shared-material.module';
import {OverlayCardHelpTestComponent} from './overlay-card-help-test/overlay-card-help-test.component';
import {OverlayCardAlertTestComponent} from './overlay-card-alert-test/overlay-card-alert-test.component';
import {AALOverlayCardHelpModule} from '../../../asml-angular/material/src/lib/overlay-card-help/overlay-card-help.module';
import {AALOverlayCardErrorModule} from '../../../asml-angular/material/src/lib/overlay-card-alert/overlay-card-alert.module';
import {SharedFlexLayoutModule} from '../../../asml-angular/material/src/lib/shared/shared-flex-layout.module';
import {AALToolbarConfirmTestComponent} from './toolbar-confirm-test/toolbar-confirm-test.component';
import {AALToolbarConfirmModule} from '../../../asml-angular/material/src/lib/toolbar-confirm/toolbar-confirm.module';
import {FormTestComponent} from './form-test/form-test.component';
import {MCInputTextComponent} from './form-test/mc-input-text/mc-input-text.component';
import {HttpClientModule} from '@angular/common/http';
import {AALInputNumberTestComponent} from './input-number-test/input-number-test.component';
import {AALInputNumberModule} from '../../../asml-angular/material/src/lib/input-number/input-number.module';
import {AALSelectSingleTestComponent} from './select-single-test/select-single-test.component';
import {AALSelectSingleModule} from '../../../asml-angular/material/src/lib/select-single/select-single.module';
import {SelectMultipleTestComponent} from './select-multiple-test/select-multiple-test.component';
import {AALSelectMultipleModule} from '../../../asml-angular/material/src/lib/select-multiple/select-multiple.module';
import {AALInputTextAreaTestComponent} from './input-text-area-test/input-text-area-test.component';
import {AALInputTextAreaModule} from '../../../asml-angular/material/src/lib/input-text-area/input-text-area.module';
import {AALButtonRadioTestComponent} from './button-radio-test/button-radio-test.component';
import {AALButtonRadioModule} from '../../../asml-angular/material/src/lib/button-radio/button-radio.module';
import {AALButtonToggleTestComponent} from './button-toggle-test/button-toggle-test.component';
import {AALButtonToggleModule} from '../../../asml-angular/material/src/lib/button-toggle/button-toggle.module';
import {CommonModule} from '@angular/common';
import {AALButtonToggleInputModule} from '../../../asml-angular/material/src/lib/button-toggle-input/button-toggle-input.module';
import {AALButtonToggleInputTestComponent} from './button-toggle-input-test/button-toggle-input-test.component';
import {AALSelectMultipleInputModule} from '../../../asml-angular/material/src/lib/select-multiple-input/select-multiple-input.module';
import {AALSelectSingleInputModule} from '../../../asml-angular/material/src/lib/select-single-input/select-single-input.module';
import {AALSelectMultipleInputTestComponent} from './select-multiple-input-test/select-multiple-input-test.component';
import {AALSelectSingleInputTestComponent} from './select-single-input-test/select-single-input-test.component';
import {AALRichTextAreaModule} from '../../../asml-angular/material/src/lib/rich-text-area/rich-text-area.module';
import {AALRichTextAreaTestComponent} from './rich-text-area-test/rich-text-area-test.component';
import {AALAutoCompleteTestComponent} from './auto-complete-test/auto-complete-test.component';
import {AALAutoCompleteSingleModule} from '../../../asml-angular/material/src/lib/auto-complete-single/auto-complete-single.module';
import {AALAutoCompleteMultipleModule} from '../../../asml-angular/material/src/lib/auto-complete-multiple/auto-complete-multiple.module';
import {AALDatePickerModule} from '../../../asml-angular/material/src/lib/date-picker/date-picker.module';
import {AALDatePickerTestComponent} from './date-picker-test/date-picker-test.component';
import {AALDatePickerRangeTestComponent} from './date-picker-range-test/date-range-picker-test.component';
import {AALDatePickerRangeModule} from '../../../asml-angular/material/src/lib/date-picker-range/date-picker-range.module';
import {AALDatePickerSelectTestComponent} from './date-picker-select-test/date-picker-select-test.component';
import {AALDatePickerSelectModule} from '../../../asml-angular/material/src/lib/date-picker-select/date-picker-select.module';
import {AALExpansionPanelTestComponent} from './expansion-panel-test/expansion-panel-test.component';
import {AALExpansionPanelModule} from '../../../asml-angular/material/src/lib/expansion-panel/expansion-panel.module';
import {LightBoxTestComponent} from './light-box-test/light-box-test.component';
import {AALLightBoxComponent} from '../../../asml-angular/material/src/lib/light-box/light-box.component';
import {AALExpansionPanelListTestComponent} from './expansion-panel-list-test/expansion-panel-list-test.component';
import {AALExpansionPanelListModule} from '../../../asml-angular/material/src/lib/expansion-panel-list/expansion-panel-list.module';
import {AALListItemTestComponent} from './list-item-test/list-item-test.component';
import {AALListItemModule} from '../../../asml-angular/material/src/lib/list-item/list-item.module';
import {AALButtonIconTestComponent} from './button-icon-test/button-icon-test.component';
import {AALButtonIconModule} from '../../../asml-angular/material/src/lib/button-icon/button-icon.module';
import {AALButtonContainedTestComponent} from './button-contained-test/button-contained-test.component';
import {AALButtonContainedModule} from '../../../asml-angular/material/src/lib/button-contained/button-contained.module';
import {AALButtonDynamicTestComponent} from './button-dynamic-test/button-dynamic-test.component';
import {AALButtonDynamicModule} from '../../../asml-angular/material/src/lib/button-dynamic/button-dynamic.module';
import {AALButtonOutlinedTestComponent} from './button-outlined-test/button-outlined-test.component';
import {AALButtonOutlinedModule} from '../../../asml-angular/material/src/lib/button-outlined/button-outlined.module';
import {AALButtonTextTestComponent} from './button-text-test/button-text-test.component';
import {AALButtonTextModule} from '../../../asml-angular/material/src/lib/button-text/button-text.module';
import {AALButtonOverlayIconModule} from '../../../asml-angular/material/src/lib/button-overlay-icon/button-overlay-icon.module';
import {AALButtonOverlayIconTestComponent} from './button-overlay-icon-test/button-overlay-icon-test.component';
import {AALButtonOverlayCardModule} from '../../../asml-angular/material/src/lib/button-overlay-card/button-overlay-card.module';
import {AALButtonOverlayCardTestComponent} from './button-overlay-card-test/button-overlay-card-test.component';
import {EmptyStateTestComponent} from './empty-state-test/empty-state-test.component';
import {AALEmptyStateModule} from '../../../asml-angular/material/src/lib/empty-state/empty-state.module';
import {AALListItemToolbarTestComponent} from './list-item-toolbar-test/list-item-toolbar-test.component';
import {AALListItemToolbarModule} from '../../../asml-angular/material/src/lib/list-item-toolbar/list-item-toolbar.module';
import {AALButtonTestComponent} from './button-test/button-test.component';
import {AALButtonModule} from '../../../asml-angular/material/src/lib/button/button.module';
import {AALButtonToolbarTestComponent} from './button-toolbar-test/button-toolbar-test.component';
import {AALButtonToolbarModule} from '../../../asml-angular/material/src/lib/button-toolbar/button-toolbar.module';
import {AALExpansionPanelOverviewCardListModule} from '../../../asml-angular/material/src/lib/expansion-panel-overview-card-list/expansion-panel-overview-card-list.module';
import {AALWizardAssessmentTestComponent} from './wizard-assessment-test/wizard-assessment-test.component';
import {AALWizardAssessmentModule} from '../../../asml-angular/material/src/lib/wizard-assessment/wizard-assessment.module';
import {AALWizardAssessmentDialogComponent} from '../../../asml-angular/material/src/lib/wizard-assessment-dialog/wizard-assessment-dialog.component';
import {AALWizardAssessmentDialogModule} from '../../../asml-angular/material/src/lib/wizard-assessment-dialog/wizard-assessment-dialog.module';
import {AALWizardAssessmentDialogTest2Module} from './wizard-assessment-dialog-test-2/wizard-assessment-dialog-test-2.module';
import {AALWizardAssessmentDialogTest1Module} from './wizard-assessment-dialog-test-1/wizard-assessment-dialog-test-1.module';
import {AALButtonIconOutlinedModule} from '../../../asml-angular/material/src/lib/button-icon-outlined/button-icon-outlined.module';
import {AALButtonIconContainedTestComponent} from './button-icon-contained-test/button-icon-contained-test.component';
import {AALButtonIconContainedModule} from '../../../asml-angular/material/src/lib/button-icon-contained/button-icon-contained.module';
import {AALCollapsiblePanelTestComponent} from './collapsible-panel-test/collapsible-panel-test.component';
import {AALCollapsiblePanelModule} from '../../../asml-angular/material/src/lib/collapsible-panel/collapsible-panel.module';
import {AALCardSummaryModule} from '../../../asml-angular/material/src/lib/card-summary/card-summary.module';
import {AALCardSummaryTestComponent} from './card-summary-test/card-summary-test.component';
import {AALTextFieldModule} from '../../../asml-angular/material/src/lib/text-field/text-field.module';
import {AALButtonOverlayTabbedTestComponent} from './button-overlay-tabbed-test/button-overlay-tabbed-test.component';
import {AALButtonOverlayTabbedModule} from '../../../asml-angular/material/src/lib/button-overlay-tabbed/button-overlay-tabbed.module';
import {AALMenuSortTestComponent} from './menu-sort-test/menu-sort-test.component';
import {AALMenuSortModule} from '../../../asml-angular/material/src/lib/menu-sort/menu-sort.module';
import {AALInputTextSuffixModule} from '../../../asml-angular/material/src/lib/input-text-suffix/input-text-suffix.module';
import {AALAutoCompleteSingleCardModule} from '../../../asml-angular/material/src/lib/auto-complete-single-card/auto-complete-single-card.module';
import {LightBoxMultipleTestComponent} from './light-box-multiple-test/light-box-multiple-test.component';
import {ReactiveFormsModule} from '@angular/forms';
import {AALDatePickerWeekTestComponent} from './date-picker-week-test/date-picker-week-test.component';
import {AALDatePickerWeekModule} from '../../../asml-angular/material/src/lib/date-picker-week/date-picker-week.module';
import {AALChipTestComponent} from './chip-test/chip-test.component';
import {AALChipModule} from '../../../asml-angular/material/src/lib/chip/chip.module';
import {AALTextFieldTestComponent} from './text-field-test/text-field-test.component';
import {AALButtonRadioInputModule} from '../../../asml-angular/material/src/lib/button-radio-input/button-radio-input.module';
import {InputTextSuffixTestComponent} from './input-text-suffix-test/input-text-suffix-test.component';
import {AALEditableDivTextAreaModule} from '../../../asml-angular/material/src/lib/editable-div-text-area/editable-div-text-area.module';
import { AnalyticsPanelTestComponent } from './analytics-panel-test/analytics-panel-test.component';
import {AALAnalyticsPanelModule} from '../../../asml-angular/material/src/lib/analytics-panel/analytics-panel.module';
import {AutoCompleteFreeTextMultipleModule} from '../../../asml-angular/material/src/lib/auto-complete-free-text-multiple/auto-complete-free-text-multiple.module';
import {AALCheckboxTestComponent} from './checkbox-test/checkbox-test.component';
import {AALCheckBoxModule} from '../../../asml-angular/material/src/lib/checkbox/checkbox.module';
import {AALNavigationConfirmationDialogModule} from "../../../asml-angular/material/src/lib/navigation-confirmation-dialog/navigation-confirmation-dialog.module";
import { AALObjectInformationModule } from 'projects/asml-angular/material/src/lib/object-information/object-information.module';
import { AALObjectInformationTestComponent } from './object-information-test/object-information-test.component';

@NgModule({
    declarations: [
        AppComponent,
        AALInputTextTestComponent,
        AALInputNumberTestComponent,
        AALInputDurationTestComponent,
        AALInputCurrencyTestComponent,
        AALInputTimeTestComponent,
        AALInputLinkTestComponent,
        AALToolbarConfirmTestComponent,
        AALThemingTestComponent,
        OverlayCardHelpTestComponent,
        OverlayCardAlertTestComponent,
        AALButtonRadioTestComponent,
        FormTestComponent,
        MCInputTextComponent,
        SelectMultipleTestComponent,
        MCInputTextComponent,
        AALSelectSingleTestComponent,
        AALInputTextAreaTestComponent,
        AALSelectSingleTestComponent,
        AALButtonToggleTestComponent,
        AALButtonToggleInputTestComponent,
        AALSelectMultipleInputTestComponent,
        AALSelectSingleInputTestComponent,
        AALRichTextAreaTestComponent,
        AALSelectMultipleInputTestComponent,
        AALSelectSingleInputTestComponent,
        AALAutoCompleteTestComponent,
        AALRichTextAreaTestComponent,
        AALDatePickerTestComponent,
        AALDatePickerRangeTestComponent,
        AALDatePickerSelectTestComponent,
        AALExpansionPanelTestComponent,
        LightBoxTestComponent,
        AALExpansionPanelListTestComponent,
        InputTextSuffixTestComponent,
        AALListItemTestComponent,
        AALButtonIconTestComponent,
        AALButtonContainedTestComponent,
        AALButtonDynamicTestComponent,
        AALButtonOutlinedTestComponent,
        AALButtonTextTestComponent,
        AALButtonOverlayIconTestComponent,
        AALButtonOverlayCardTestComponent,
        EmptyStateTestComponent,
        AALListItemToolbarTestComponent,
        AALButtonTestComponent,
        AALButtonToolbarTestComponent,
        AALWizardAssessmentTestComponent,
        AALWizardAssessmentTestComponent,
        AALButtonIconContainedTestComponent,
        AALCollapsiblePanelTestComponent,
        AALCardSummaryTestComponent,
        AALTextFieldTestComponent,
        AALButtonOverlayTabbedTestComponent,
        AALMenuSortTestComponent,
        // InputTextSuffixTestComponent,
        LightBoxMultipleTestComponent,
        AALDatePickerWeekTestComponent,
        AALChipTestComponent,
        AnalyticsPanelTestComponent,
        AALCheckboxTestComponent,
        AALObjectInformationTestComponent
    ],
    imports: [
        BrowserModule,
        BrowserAnimationsModule,
        CommonModule,
        AALInputTextModule,
        AALInputTextAreaModule,
        AALEditableDivTextAreaModule,
        AALInputDurationModule,
        AALInputCurrencyModule,
        AALInputNumberModule,
        AALInputTimeModule,
        AALInputLinkModule,
        AALOverlayCardHelpModule,
        AALOverlayCardErrorModule,
        AALSelectMultipleModule,
        AALDatePickerRangeModule,
        SharedFormModule,
        SharedMaterialModule,
        SharedFlexLayoutModule,
        AALToolbarConfirmModule,
        HttpClientModule,
        AALSelectSingleModule,
        AALButtonRadioModule,
        AALButtonRadioInputModule,
        AALButtonToggleModule,
        AALButtonToggleInputModule,
        AALCheckBoxModule,
        AALSelectMultipleInputModule,
        AALSelectSingleInputModule,
        AALRichTextAreaModule,
        AALSelectSingleInputModule,
        AALSelectMultipleInputModule,
        AALAutoCompleteSingleModule,
        AALAutoCompleteMultipleModule,
        AutoCompleteFreeTextMultipleModule,
        AALRichTextAreaModule,
        AALDatePickerModule,
        AALDatePickerSelectModule,
        AALExpansionPanelModule,
        AALExpansionPanelListModule,
        AALExpansionPanelOverviewCardListModule,
        AALListItemModule,
        AALButtonIconModule,
        AALButtonContainedModule,
        AALEmptyStateModule,
        AALListItemToolbarModule,
        AALButtonModule,
        AALButtonToolbarModule,
        AALButtonDynamicModule,
        AALButtonOutlinedModule,
        AALButtonTextModule,
        AALButtonOverlayCardModule,
        AALButtonOverlayIconModule,
        AALWizardAssessmentModule,
        AALWizardAssessmentModule,
        AALWizardAssessmentDialogModule,
        AALWizardAssessmentDialogTest2Module,
        AALWizardAssessmentDialogTest1Module,
        AALButtonIconOutlinedModule,
        AALButtonIconContainedModule,
        AALCollapsiblePanelModule,
        AALButtonOverlayTabbedModule,
        AALMenuSortModule,
        AALCardSummaryModule,
        AALTextFieldModule,
        AALInputTextSuffixModule,
        AALAutoCompleteSingleCardModule,
        ReactiveFormsModule,
        AALDatePickerWeekModule,
        AALChipModule,
        AALAnalyticsPanelModule,
        AALEditableDivTextAreaModule,
        AALNavigationConfirmationDialogModule,
        AALObjectInformationModule
    ],
    providers: [],
    bootstrap: [AppComponent]
})
export class AppModule {
}
