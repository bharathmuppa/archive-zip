import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'aal-button-dynamic-test',
  templateUrl: './button-dynamic-test.component.html',
  styleUrls: ['./button-dynamic-test.component.scss']
})
export class AALButtonDynamicTestComponent implements OnInit {
  state = 'INITIAL';
  statesConfiguration;

  constructor() {
  }

  ngOnInit() {

    this.statesConfiguration = {
      'initial': {
        'icon': 'cloud_download',
        'tooltip': 'Create Delta 1 In Teamcenter, then Download Excel File',
        'toast': 'Delta 1 created in Teamcenter',
        'toastDuration' : 2000
      },
      'inprogress': {'icon': '', 'tooltip': 'Preparing To Download Excel File', 'toast': 'Download in progress', 'toastDuration' : 2000},
      'success': {'icon': 'check', 'tooltip': 'Successful', 'toast': 'Download Started. Check Your Downloads Folder', 'toastDuration' : 2000},
      'failure': {'icon': 'warning', 'tooltip': 'Failed', 'toast': 'Something went wrong', 'toastDuration' : 2000}
    };

  }


  dynamicButton(): void {
    setTimeout(() => {
      this.state = 'SUCCESS';
    }, 3000);
    setTimeout(() => {
      this.state = 'FAILURE';
    }, 5000);
  }
}
