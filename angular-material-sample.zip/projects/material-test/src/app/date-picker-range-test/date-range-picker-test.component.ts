import {Component, OnInit} from '@angular/core';
import {Info, Mode, Modes} from '@asml-angular/common';
import {UntypedFormBuilder, UntypedFormControl, Validators} from '@angular/forms';

@Component({
  selector: 'aal-date-picker-range-test',
  templateUrl: './date-picker-range-test.component.html',
  styleUrls: ['./date-picker-range-test.component.scss']
})
export class AALDatePickerRangeTestComponent implements OnInit {
  mode: Mode;
  control: UntypedFormControl;
  showSpinner: boolean;
  errorAlert: Info;
  warnAlert: Info;
  help: Info;
  modes = Modes;

  constructor(private readonly fb: UntypedFormBuilder) {
  }

  ngOnInit() {
    this.control = this.fb.control('', Validators.required);
  }

  onAcceptChanges($event) {
    console.log($event);
  }

  onRejectChanges($event) {
    console.log($event);
  }

}
