import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'aal-empty-state-test',
  templateUrl: './empty-state-test.component.html',
  styleUrls: ['./empty-state-test.component.scss']
})
export class EmptyStateTestComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
