# Contributing to ASML Angular Material

We would love for you to contribute to the ASML Angular Material library and help make it even better than it is today!
As a contributor, here are the guidelines we would like you to follow:

- [Question or Problem?](#question)
- [Issues and Bugs](#issue)
- [Feature Requests](#feature)
- [Submission Guidelines](#submit)

## <a name="question"></a> Got a Question or Problem?

Do not open issues for general support questions as we want to keep GitLab issues for bug reports and feature requests related discussions.
Instead, we recommend using [Stack Overflow](https://asml.stackenterprise.co/questions/tagged/768)  to ask support-related questions. In case, you don't have access to StackOverflow you can reach out to MIRAI team members for your queries.
When creating a new question on Stack Overflow, make sure to add the `aal` tag.


## <a name="bug"></a> Found a Bug?

If you find a bug in the source code, you can help us by [submitting an issue](#submit-issue) to our [GitLab Repository][gitlab].
Even better, you can [submit a Merge Request](#submit-mr) with a fix.

When creating a new issue in Gitlab for a bug report, please fill out the below-mentioned fields by following the guidelines specified for them :

### 1. Title: 
Specify a proper title that provides a gist of what the issue is.
### 2. Type: 
Select "Issue" from the drop-down menu
### 3. Description:
   Select the "Bug" option from the drop-down menu, this applies a template in the text-area for the description below.
   Fill all the sections populated in the description template by providing as much detail as possible so that there is all the information required for the reviewers to get a clear idea about the issue.

   * #### Summary:
      Summarize the issue in a brief but comprehensive manner

   * #### Steps To Reproduce:
      Describe how one can reproduce this issue, it would be of great help to attach screenshots/screen captures on how to reproduce the issue. This will prevent unnecessary back & forth discussions on how to consistently reproduce the bug.

   * #### Example Project:
      If possible, provide a link to the application which has this bug

   * #### Current Behaviour:
      Provide details about the current behaviour of the library, with respect to the issue in question

   * #### Expected Behaviour:
      Provide details about the expected behaviour of the library, what has to happen instead of the current behaviour
 
   * #### Relevant Logs/Screenshots:
      Attach all the necessary logs/screenshots that provide an in depth idea about the issue being faced currently

   * #### Possible Fixes:
      If you already know which piece of code is responsible for causing the issue, link the lines of code or provide a snapshot.
      Also, if you also know how to fix the issue, give a short proposal.

      
## <a name="feature"></a> Missing a Feature?
You can *request* a new feature by [submitting an issue](#submit-issue) to our GitLab Repository & selecting **Proposal** from the dropdown for the description field.
If you would like to *implement* a new feature, please consider the size of the change in order to determine the right steps to proceed & then [raise a merge request](#submit-mr):

* For a **Major Feature**, first open an issue and outline your proposal so that it can be discussed.
  This process allows us to better coordinate our efforts, prevent duplication of work, and help you to craft the change so that it is successfully accepted into the library.

  **Note**: Significantly refactoring a component, introducing a breaking change counts as a major feature.

* **Small Features** can be crafted and directly [submitted as a Pull Request](#submit-mr).

When creating a new issue in Gitlab for a bug report, please fill out the below-mentioned fields by following the guidelines specified for them :

### 1. Title:
   Specify a proper title that provides a gist of what is the new feature you want the library to implement.
### 2. Type:
   Select "Issue" from the drop-down menu
### 3. Description:
   Select the "Feature" option from the drop-down menu, this applies a template in the text-area for the description below.

   Fill all the sections populated in the description template by providing as much detail as possible so that there is all the information required for the reviewers to get a clear idea about the issue.
  * #### Problem To Solve:
    Provide a brief description about what problem do we solve?
   
    Try to define the **who/what/why** of the opportunity as a user story. For example, **"As a (who), I want (what), so I can (why/value)."**
  * #### Proposal:
    Describe how we are going to implement this new feature. 

    Try to fill this section with as much technical information as possible, by referencing lines of code to change/ Additional properties added to a file etc. This helps to provide a clear idea about the changes that reviewer/maintainer can expect to see when this feature is implemented
  * #### Acceptance Criteria:
    Describe the requirements that must be met to consider that the feature has been implemented correctly & the proposed solution is working as expected across all scenarios

You can refer to [this feature request](https://gitlab-iwf.asml.com/mirai/common/angular/material/-/issues/1) to get a better idea.

## <a name="submit"></a> Submission Guidelines


### <a name="submit-issue"></a> Submitting an Issue

Before you submit an issue, please search the issues list. An issue for your problem might already exist and the discussion might inform you of workarounds readily available.

We want to fix all the issues as soon as possible, but before fixing a bug, we need to reproduce and confirm it.
In order to reproduce bugs, we require that you provide a minimal reproduction.
Having a minimal reproducible scenario gives us a wealth of important information without going back and forth to you with additional questions.

A minimal reproduction allows us to quickly confirm a bug (or point out a coding problem) as well as confirm that we are fixing the right problem.

We require a minimal reproduction to save maintainers' time and ultimately be able to fix more bugs.

Unfortunately, we are not able to investigate / fix bugs without a minimal reproduction, so if we don't hear back from you, we are going to close an issue that doesn't have enough info to be reproduced.

You can file new issues(Bugs/ Feature requests) by selecting from our [new issue templates](https://gitlab-iwf.asml.com/mirai/common/angular/material/-/issues/new) and filling out the issue template which best fits your needs.

Refer to the guidelines mentioned above for [creating a bug report](#bug) or [creating a new feature request](#feature) 


### <a name="submit-mr"></a> Submitting a Merge Request (MR)

Before you submit your Merge Request (PR) consider the following guidelines:

1. Search [GitLab](https://gitlab-iwf.asml.com/mirai/common/angular/material/-/merge_requests) for an open or closed MR that relates to your submission.
   You don't want to duplicate existing efforts.

2. Be sure that an issue describes the problem you're fixing, or documents the design for the feature you'd like to add.
   Discussing the design upfront helps to ensure that we're ready to accept your work.

3. [Clone](https://gitlab-iwf.asml.com/mirai/common/angular/material.git) the `@asml-angular/material repo`.

4. In your cloned repository, create a new **versioned** branch (Ex: `1.2.3`) for your changes from `master`, we recommend that you don't create a feature branch (Ex: `my-feature`) as **only the versioned branches publish an RC version of the library** for every commit that you push to that particular branch.

   This makes it easier for you to test your changes in your application by just simply updating the package.json with appropriate RC version of the library & installing it. If you create a feature branch, you need to manually generate the build for the library & replace the files in your application to see the changes.

   Check the [releases](https://gitlab-iwf.asml.com/mirai/common/angular/material/-/releases) section of the repository to identify the latest version released & create the branch with the next version if it doesn't exist. In case there is already a branch with the next version, reach out to MIRAI ART members for further help.
      
   **Note: We follow the NPM semver for the versioning scheme of our library. Please do consider this and accordingly create your branches if the changes made in the branch is a Major, Minor or a BugFix/Patch**

5. Create your patch, **including appropriate test cases**.

6. Follow our [Coding Rules](https://wiki.asml.com/wiki/confluence/pages/viewpage.action?spaceKey=MIR&title=Frontend).

7. Run the full Angular test suite and ensure that all tests pass & follow the guidelines mentioned below: 

   1. When introducing a **new component** to the library, we look for **>=95% code coverage**.
   
   2. When introducing new changes to an already **existing component**, we look for **100% code coverage** for the changes being made i.e there should be no drop in the current code coverage of the component.
   
   3. **If we see a drop in coverage even though all the test cases are passing, we will not accept your Merge Request until the coverage delta is fixed.**

8. Commit your changes using a descriptive commit message

9. Push your branch to GitLab.

10. In GitLab, create a merge request from your branch to `master`.
  
    Please follow the below-mentioned guidelines when creating a new MR:

    * #### Title: 
       Set the title as the version of your branch/ Give a short & concise overview of your change. **Start the title of the merge request with `Draft:` to create a draft merge request**, this allows us to differentiate between the Merge requests which are ready to be merged & the ones which are Work In Progress. Once you think your changes are ready to be reviewed & merged, remove the `Draft:` from the title.
    
    * #### Description:
       From the dropdown choose **Angular** to apply the MR template & fill the following details accordingly:
      
       * #### Purpose:
         Briefly describe the changes that will be implemented when accepting this MR. Additionally, link necessary Gitlab issues and/or Jira tickets here. 
    
    * #### Leave Assignees, Reviewers, Milestones, Labels & Merge request options as is
    
    * #### Merge Request Options:
      Check the **Delete source branch when merge request is accepted** option
    
  * For each commit that you push to Gitlab, the library performs a detailed analysis of the code using sonarqube. The job "Quality Check" is the one which provides you information if there are any code-smells or bugs in your code. **Even though this phase is optional, we do check it before merging your changes to the master branch**, so please do ensure that the sonar analysis is successful & try to fix any issues reported by sonarqube.

### Addressing review feedback

If we ask for changes via code reviews then:

1. Make the required updates to the code.

2. Re-run the Angular test suites to ensure tests are still passing.

3. Create a fixup commit and push to your GitLab repository (this will update your Merge Request):

That's it! Thank you for your contribution!

### After your merge request is merged

After your merge request is merged, you can check the [releases](https://gitlab-iwf.asml.com/mirai/common/angular/material/-/releases) tab to see if the latest version of the library has been published & use the same.


[gitlab]: https://gitlab-iwf.asml.com/mirai/common/angular/material
[stackoverflow]: https://asml.stackenterprise.co/questions/tagged/768
