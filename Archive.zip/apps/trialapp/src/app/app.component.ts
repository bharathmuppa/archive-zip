import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';
import { NxWelcomeComponent } from './nx-welcome.component';
import {HeaderComponent} from "@trialws/shared/ui/header";
import {menuClicked} from "./+state/app.actions";
import {AppState} from "./+state/app.reducer";
import {Store} from "@ngrx/store";
import {selectMenuDrawerExpanded} from "./+state/app.selectors";
import {AsyncPipe} from "@angular/common";

@Component({
  standalone: true,
  imports: [NxWelcomeComponent, RouterModule, HeaderComponent, AsyncPipe],
  selector: 'trialws-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent {
  title = 'trialapp';
  protected readonly console = console;
  protected readonly menuClicked = menuClicked;
  menuDrawerExpanded$ = this.store.select(selectMenuDrawerExpanded);
  constructor(private store:Store<AppState>) {
    this.console.log('AppComponent constructor');
  }
  onMenuClicked() {
    console.log('menu clicked');
    this.store.dispatch(menuClicked());
  }
}
