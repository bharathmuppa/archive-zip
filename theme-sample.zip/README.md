# Theme

This repository is for ASML Angular Theme (used across ASML Angular library)

This repository contains the ASML theme related palettes & other reusable CSS helper classes.
You need to add this project to your application dependencies if you want to use the variables that define the ASML Angular Material theme

Previously all the helper classes & theming variables were present in ASML Angular Common & ASML Angular Material projects.
So if you wanted to use any of the predefined styles you had to add @asml-angular/common & @asml-angular/material to your project dependencies, even if you didn't want to use the custom components offered by those libraries.

This library (@asml-angular/theme) solves this issue now as all the theming variables & CSS helper classes have been added here.
So, you can add this library to your application dependencies to access them, instead of adding @asml-angular/material & @asml-angular/common to your dependencies.

Make sure to include _theming.scss file in angular.json in styles
```
styles: [
    {
        "input": "./node_modules/@asml-angular/theme/src/lib/themes/_theming.scss",
        "inject": true 
    }
]
```


If you want to include theme variable or Mixins within your scss/sass file use syntax as below
```
@use '@asml-angular/theme' as *; 
```

The theming library contains the following
* Constants for ASML standard color palette.
* Typography constants with different fonts.
* Custom classes for margin & padding.
* Elevations
* Styles to display image
* Styles to display an icon
* Styles for clickable content
* Helper clases with additional colors, background colors and styles.

If you need to use the custom ASML Angular components, then you need to import all the 3 libraries:
1. @asml-angular/theme
2. @asml-angular/common
3. @asml-angular/material

In case of any issues, please contact members from the MIRAI ART
