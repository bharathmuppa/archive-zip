export class ThemeService {
 // This class is used as entry point for ng-packager because it needs to have entry point.
}
