/**
 * This File is responsible for copying the necessary files to dist folder
 */
const fs = require('fs');
const Path = require("path");

copyReadMeFile();
copyChangeLog();

function copyReadMeFile() {
  fs.copyFile('README.md', Path.resolve('./dist/asml-angular/common/README.md'), (err) => {
    if (err) throw err;
    console.log('README.md  was copied to ' + Path.resolve('./projects/asml-angular/common/README.md'));
  });
}

function copyChangeLog() {
  fs.copyFile('CHANGELOG.md', Path.resolve('./dist/asml-angular/common/CHANGELOG.md'), (err) => {
    if (err) throw err;
    console.log('CHANGELOG.md  was copied to ' + Path.resolve('./projects/asml-angular/common/README.md'));
  });

}
