/**
 * This File is responsible for updating all the peer dependencies based on package json at root level
 */

const fs = require('fs');
const Path = require("path");

const sourcePackagesFile = './package.json';
const destinationPackageFile = './projects/asml-angular/common/package.json';

const sourcePackagesContent = require(Path.resolve(sourcePackagesFile));
const destinationPackagesContent = require(Path.resolve(destinationPackageFile));

if(!destinationPackagesContent.hasOwnProperty('peerDependencies'))
  destinationPackagesContent.peerDependencies = {};

const destinationPeerDependencies = destinationPackagesContent.peerDependencies;
const sourceDependencies = sourcePackagesContent.dependencies;

for(let dependency in sourceDependencies){
  destinationPeerDependencies[dependency] = sourceDependencies[dependency]
}


fs.writeFile(Path.resolve(destinationPackageFile), JSON.stringify(destinationPackagesContent, null,2), function writeJSON(err) {
  if (err) return console.log(err);
});
