import {AbstractControl, ValidationErrors, ValidatorFn} from '@angular/forms';
import {AALUtil} from './util';

// @dynamic
// noinspection JSUnusedGlobalSymbols
export class AALCustomValidators {
  // noinspection JSUnusedGlobalSymbols
  /**
   * @description
   * Validator that adds required validator conditionally by checking input control (mainControl) and mainControlValues
   * (mainControlValueList). If the mainControl has a value in the provided list (mainControlValueListToAddValidator)
   * then required validator will be added to the target control to which this validator configured.
   *
   */
  static conditionalRequired(mainControl: AbstractControl | string, mainControlValueList: any[]): ValidatorFn {
    return (control: AbstractControl): { [key: string]: any } | null => {
      if (typeof mainControl === 'string') {
        mainControl = control.parent.get(mainControl);
      }
      return mainControl && AALUtil.isValuePresentInList(mainControl.value, mainControlValueList) ? {required: true} : null;
    };
  }

  // noinspection JSUnusedGlobalSymbols
  /**
   * @description
   * Validator that checks the maxlength of the the control value after removing rich text content (HTML content).
   *
   */
  static richTextMaxlength(maxLength: number): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const temporalDivElement = document.createElement('div');
      temporalDivElement.innerHTML = control.value;
      const length: number = (temporalDivElement.textContent || temporalDivElement.innerText || '').trim().length;
      return length > maxLength ?
        {'maxlength': {'requiredLength': maxLength, 'actualLength': length}} :
        null;
    };
  }
}
