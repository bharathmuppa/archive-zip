export class AALUtil {
  static areEqual(obj1: any, obj2: any): boolean {
    if ((obj1 && !obj2) || (!obj1 && obj2) || (typeof obj1 !== typeof obj2)) {
      return false;
    } else if (typeof obj1 === 'string') {
      return obj1 === obj2;
    } else if (typeof obj1 === 'object') {
      return JSON.stringify(obj1) === JSON.stringify(obj2);
    } else {
      return false;
    }
  }

  static isValuePresentInList(value: any, list: any[]): boolean {
    if (!value || !list || !(list.length > 0)) {
      return false;
    }
    for (const item of list) {
      if (AALUtil.areEqual(value, item)) {
        return true;
      }
    }
    return false;
  }

  static getDateInISOFormat(date: Date | string): string {
    if (!date) {
      return '';
    }
    if (typeof date === 'string') {
      return date;
    }
    return AALUtil.getDateFromDateTime(date).split('T')[0] + 'T12:00:00Z';
  }

  static setDateDefaultTime(date: any): Date {
    if (typeof date !== 'string') {
      date = AALUtil.getDateFromDateTime(date) + 'T';
    }
    date = date.split('T')[0] + 'T12:00:00Z';
    return new Date(date);
  }

  static getDateFromDateTime(date: Date): string {
    const month = ('0' + (date.getMonth() + 1)).slice(-2);
    const dateString = ('0' + date.getDate()).slice(-2);
    const year = date.getFullYear();
    return year + '-' + month + '-' + dateString;
  }
}
