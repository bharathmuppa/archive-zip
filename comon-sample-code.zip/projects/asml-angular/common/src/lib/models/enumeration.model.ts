export enum Modes {EDIT = 'EDIT', READ = 'READ', PROTECTED = 'PROTECTED', PRIVATE = 'PRIVATE'}

export type Mode = Modes.EDIT | Modes.READ | Modes.PROTECTED | Modes.PRIVATE;

export enum Statuses {DRAFT = 'DRAFT', ACCEPTED = 'ACCEPTED', REJECTED = 'REJECTED'}

export type Status = Statuses.DRAFT | Statuses.ACCEPTED | Statuses.REJECTED;

export enum InfoLevels {ERROR = 'ERROR', WARN = 'WARN'}

export type InfoLevel = InfoLevels.ERROR | InfoLevels.WARN;

export type ButtonType = 'icon' | 'overlayIcon' | 'overlayCard' | 'dynamic' | 'contained' | 'outlined' | 'text' | 'menu' | 'chip';

export enum ButtonTypes {Icon = 'icon', OverlayIcon = 'overlayIcon', OverlayCard = 'overlayCard', Dynamic = 'dynamic', Contained = 'contained', Outlined = 'outlined', Text = 'text', Menu = 'menu', Chip = 'chip'}

export type IconSize = 'small' | 'medium' | 'large' | 'extraLarge';

export enum IconSizes {Small = 'small', Medium = 'medium', Large = 'large', ExtraLarge = 'extraLarge'}

export type ThemeColor = 'primary' | 'accent' | 'warn';

export enum ThemeColors {Primary = 'primary', Accent = 'accent', Warn = 'warn'}

export type BadgePosition =
  'before'
  | 'after'
  | 'above'
  | 'below'
  | 'before below'
  | 'before above'
  | 'after below'
  | 'after above';

export enum BadgePositions {
  Before = 'before', After = 'after', Above = 'above', Below = 'below', BeforeBelow = 'before below',
  BeforeAbove = 'before above', AfterBelow = 'after below', AfterAbove = 'after above'
}

export type BadgeSize = 'small' | 'medium' | 'large';

export enum BadgeSizes {Small = 'small', Medium = 'medium', Large = 'large'}

export enum FontTypes {Small = 'small', Regular = 'regular', Large = 'large'}
export enum LabelFontSizes {Small = '12px', Regular = '16px', Large = '20px'}
export enum SubLabelFontSizes {Small = '14px', Regular = '18px', Large = '24px'}
export enum ValueFontSizes {Small = '16px', Regular = '20px', Large = '28px'}

export type BadgeType = 'single' | 'double';
export enum BadgeTypes {Single = 'single', Double = 'double'}
export enum DurationTypes {Default = 'default', Period = 'period', Duration = 'duration'}
