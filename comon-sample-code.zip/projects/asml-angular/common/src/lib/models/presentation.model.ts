export class Info {
  title: string;
  message: string;
  animation: string;
  thumbnail: string;
  level: string;

  constructor(message: string, title?: string, animation?: string, thumbnail?: string, level?: string) {
    this.title = title;
    this.message = message;
    this.animation = animation;
    this.thumbnail = thumbnail;
    this.level = level;
  }
}

export class ValidatorMessage {
  message: string;
}

export interface EndDateForm {
  [key: string]: EndDate;
}

export interface EndDate {
  name: string;
  date: Date;
}
