import {Directive, ElementRef, EventEmitter, NgZone, OnInit, Output} from '@angular/core';

@Directive({
  selector: '[aalDragDropFile]'
})
export class AALDragDropFileDirective implements OnInit {
  @Output() readonly dragenterFn: EventEmitter<any> = new EventEmitter();
  @Output() readonly dragoverFn: EventEmitter<any> = new EventEmitter();
  @Output() readonly dropFn: EventEmitter<any> = new EventEmitter();
  @Output() readonly dragleaveFn: EventEmitter<any> = new EventEmitter();
  @Output() readonly dragendFn: EventEmitter<any> = new EventEmitter();


  constructor(private readonly el: ElementRef,
              private readonly zone: NgZone) {
  }

  ngOnInit() {
    this.zone.runOutsideAngular(() => {
      this.el.nativeElement.addEventListener(
        'drop', this.onDrop.bind(this)
      );
      this.el.nativeElement.addEventListener(
        'dragend', this.onDragEnd.bind(this)
      );
      this.el.nativeElement.addEventListener(
        'dragover', this.onDragOver.bind(this)
      );
      this.el.nativeElement.addEventListener(
        'dragenter', this.onDragEnter.bind(this)
      );
      this.el.nativeElement.addEventListener(
        'dragleave', this.onDragLeave.bind(this)
      );
    });
  }

  private onDrop($event: Event) {
    if (this.dropFn) {
      this.dropFn.emit($event);
    }
    $event.preventDefault();
    return false;
  }

  private onDragEnd($event: Event) {
    if (this.dragendFn) {
      this.dragendFn.emit($event);
    }
    $event.preventDefault();
    return false;
  }

  private onDragOver($event: Event) {
    if (this.dragoverFn) {
      this.dragoverFn.emit($event);
    }
    $event.preventDefault();
    return false;
  }

  private onDragEnter($event: Event) {
    if (this.dragenterFn) {
      this.dragenterFn.emit($event);
    }
  }

  private onDragLeave($event: Event) {
    if (this.dragleaveFn) {
      this.dragleaveFn.emit($event);
    }
  }
}

