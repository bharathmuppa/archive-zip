import {AALToggleFullScreenDirective} from './toggle-full-screen.directive';
import {Component, DebugElement} from '@angular/core';
import {ComponentFixture, TestBed} from '@angular/core/testing';
import {FormControl, FormsModule, ReactiveFormsModule} from '@angular/forms';
import {By} from '@angular/platform-browser';

@Component({
  template: `
      <div>
          <button id="myButton" aalToggleFullScreen (toggleButtonEvent)="onToggle()"></button>
      </div>`
})
class TestComponent {
  fullscreenMode: boolean;

  constructor() {
  }

  onToggle() {
    this.fullscreenMode = !this.fullscreenMode;
  }
}

describe('AALToggleFullScreenDirective', () => {
  let component: TestComponent;
  let fixture: ComponentFixture<TestComponent>;
  let debugElement: DebugElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [
        TestComponent,
        AALToggleFullScreenDirective
      ],
      imports: [
        FormsModule,
        ReactiveFormsModule
      ]
    }).compileComponents();
    fixture = TestBed.createComponent(TestComponent);
    debugElement = fixture.debugElement.query(By.directive(AALToggleFullScreenDirective));
    component = fixture.componentInstance;
    component.fullscreenMode = false;
    // fixture.detectChanges();
  });

  it('should create', () => {
    const dir = new AALToggleFullScreenDirective(null, null);
    expect(dir).toBeTruthy();
  });


  it('should enter full screen', () => {
    component.fullscreenMode = true;
    fixture.detectChanges();
    debugElement.nativeElement.dispatchEvent(new MouseEvent('click', {}));
    fixture.detectChanges();
    expect(component.fullscreenMode).toBeTruthy();
  });

  it('should exit full screen', () => {
    spyOn(document, 'addEventListener').and.callFake((type, callback) => {
      callback();
    });
    const spy = spyOn(document, 'exitFullscreen').and.returnValue(Promise.resolve());
    debugElement.nativeElement.dispatchEvent(new MouseEvent('click', {}));
    fixture.detectChanges();
    expect(component.fullscreenMode).toBeFalsy();
  });

  afterEach(() => {
    TestBed.resetTestingModule();
  });
});
