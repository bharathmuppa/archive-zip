import {AALDragDropFileDirective} from './drag-drop-file.directive';
import {waitForAsync, ComponentFixture, TestBed} from '@angular/core/testing';
import {Component, DebugElement, ElementRef, EventEmitter, Renderer2, Type, ViewChild} from '@angular/core';

describe('AALDragDropFileDirective', () => {
  let directive: AALDragDropFileDirective;
  let fixture: ComponentFixture<DragDropComponentTestComponent>;
  let newComponent: DragDropComponentTestComponent;
  let mockNgZone;

  beforeEach(waitForAsync(() => {
    mockNgZone = jasmine.createSpyObj('mockNgZone', ['run', 'runOutsideAngular']);
    mockNgZone.run.and.callFake(fn => fn());
    mockNgZone.runOutsideAngular.and.callFake(fn => fn());

    TestBed.configureTestingModule({
      declarations: [AALDragDropFileDirective],
      providers: [Renderer2]
    }).compileComponents().then(() => {
      directive = new AALDragDropFileDirective(newComponent.dragDropDirective, mockNgZone);
    });
    fixture = TestBed.createComponent(DragDropComponentTestComponent);
    newComponent = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create an instance', () => {
    directive = new AALDragDropFileDirective(newComponent.dragDropDirective,  mockNgZone);
    expect(directive).toBeTruthy();
  });

  it('should emit onDrop event on Init', () => {
    directive = new AALDragDropFileDirective(newComponent.dragDropDirective, mockNgZone);
    directive.ngOnInit();
    expect(newComponent.dragDropDirective.nativeElement.dispatchEvent(new Event('drop'))).toBeTruthy();
  });

  it('should emit onDragEnd event on Init', () => {
    directive = new AALDragDropFileDirective(newComponent.dragDropDirective, mockNgZone);
    directive.ngOnInit();
    expect(newComponent.dragDropDirective.nativeElement.dispatchEvent(new Event('dragend'))).toBeTruthy();
  });

  it('should emit onDragOver event on Init', () => {
    directive = new AALDragDropFileDirective(newComponent.dragDropDirective, mockNgZone);
    directive.ngOnInit();
    expect(newComponent.dragDropDirective.nativeElement.dispatchEvent(new Event('dragover'))).toBeTruthy();
  });

  it('should emit onDragEnter event on Init', () => {
    directive = new AALDragDropFileDirective(newComponent.dragDropDirective, mockNgZone);
    directive.ngOnInit();
    expect(newComponent.dragDropDirective.nativeElement.dispatchEvent(new Event('dragenter'))).toBeTruthy();
  });

  it('should emit onDragLeave event on Init', () => {
    directive = new AALDragDropFileDirective(newComponent.dragDropDirective, mockNgZone);
    directive.ngOnInit();
    expect(newComponent.dragDropDirective.nativeElement.dispatchEvent(new Event('dragleave'))).toBeTruthy();
  });

});
@Component({
  selector: 'aal-drag-drop-selector',
  template: `
        <div aalDragDropFile #dragdrop (dragendFn)="onDragendFn()" (dropFn)="onDropFn()" (dragoverFn)="onDragoverFn()"
             (dragenterFn)="onDragenterFn() "(dragleaveFn)="onDragleaveFn()">Sample text</div>
    `
})
export class DragDropComponentTestComponent {
  @ViewChild('dragdrop') dragDropDirective: ElementRef ;

  onDragendFn() {
    console.log('on Drag end');
  }
  onDropFn() {
    console.log('on Drop');
  }
  onDragoverFn() {
    console.log('on Drag over');
  }
  onDragenterFn() {
    console.log('on Drag enter');
  }
  onDragleaveFn() {
    console.log('on Drag Leave');
  }
}
