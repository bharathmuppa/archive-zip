import {
  Directive,
  ElementRef,
  EventEmitter,
  HostListener,
  Inject,
  OnDestroy,
  OnInit,
  Output
} from '@angular/core';
import {DOCUMENT} from '@angular/common';


@Directive({
  selector: '[aalToggleFullScreen]'
})
export class AALToggleFullScreenDirective implements OnInit, OnDestroy {
  exitFullScreenClicked: boolean;
  @Output() readonly toggleButtonEvent: EventEmitter<any> = new EventEmitter();

  constructor(private readonly el: ElementRef, @Inject(DOCUMENT) private document: any) {
  }

  @HostListener('click', ['$event.target'])
  async onClick() {
    await this.toggleFullScreen();
  }

  ngOnInit() {
    this.exitFullScreenClicked = false;
    document.addEventListener('fullscreenchange', this.exitHandler.bind(this));
    document.addEventListener('webkitfullscreenchange', this.exitHandler.bind(this));
    document.addEventListener('mozfullscreenchange', this.exitHandler.bind(this));
    document.addEventListener('MSFullscreenChange', this.exitHandler.bind(this));
  }

  ngOnDestroy() {
    this.exitFullScreenClicked = false;
    document.removeEventListener('fullscreenchange', this.exitHandler.bind(this));
    document.removeEventListener('webkitfullscreenchange', this.exitHandler.bind(this));
    document.removeEventListener('mozfullscreenchange', this.exitHandler.bind(this));
    document.removeEventListener('MSFullscreenChange', this.exitHandler.bind(this));
  }

  // Function to capture ESC event while in full screen mode
  exitHandler() {
    // noinspection TsLint
    if (!document['fullscreenElement'] && !document['webkitIsFullScreen'] &&
      !document['mozFullScreen'] && !document['msFullscreenElement'] && !this.exitFullScreenClicked) {
      this.toggleButtonEvent.emit();
    }
  }

  async toggleFullScreen() {
    // noinspection TsLint
    if (document['fullscreenElement'] ||
      document['webkitFullscreenElement'] ||
      document['mozFullScreenElement'] ||
      document['msFullscreenElement']) {
      this.exitFullScreenClicked = true;
      // noinspection TsLint
      const methodToBeInvoked = document.exitFullscreen || document['mozCancelFullScreen'] || document['webkitExitFullscreen'] ||
        document['msExitFullscreen'];
      if (methodToBeInvoked) {
        await methodToBeInvoked.call(document);
      }
    } else {
      this.exitFullScreenClicked = false;
      const elem = this.el.nativeElement.closest('body');
      // noinspection TsLint
      const methodToBeInvoked =  elem.requestFullscreen || elem['webkitRequestFullScreen'] || elem['mozRequestFullscreen'] || elem['msRequestFullscreen'];
      if (methodToBeInvoked) {
        await methodToBeInvoked.call(elem);
      }
    }
    this.toggleButtonEvent.emit();
  }
}
