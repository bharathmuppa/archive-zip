import {Directive, HostListener, Input} from '@angular/core';


@Directive({
  selector: '[aalValidateInput]'
})
export class AALValidateInputDirective {
  @Input() regex: string;

  constructor() {
  }

  @HostListener('keydown', ['$event']) onInputHandler(event) {

    if (this.regex) {
      let keyCode = event.key;
      if ([46, 8, 9, 27, 13, 110, 190].indexOf(keyCode) !== -1 || ([65, 67, 86, 88].indexOf(keyCode) !== -1 && event.ctrlKey === true)
        || (keyCode >= 35 && keyCode <= 39)) {
        // let it happen, don't do anything
        return;
      }
      /*dont allow user to enter characters with shift pressed*/
      if (event.shiftKey === true) {
        event.preventDefault();
      }
      if ((keyCode >= 96) && (keyCode <= 105)) {
        // Numpad keys
        keyCode -= 48;
      }
      const ch = String.fromCharCode(keyCode);
      const regEx = new RegExp(this.regex);
      if (regEx.test(ch)) {
        return;
      } else {
        event.preventDefault();
      }
    }
  }
}
