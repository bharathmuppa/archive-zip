import {AALStyleInnerHTMLDirective} from './style-inner-html.directive';
import {Component, ElementRef, SimpleChange, ViewChild} from '@angular/core';
import {waitForAsync, ComponentFixture, TestBed} from '@angular/core/testing';

describe('AALStyleInnerHTMLDirective', () => {
  let directive: AALStyleInnerHTMLDirective;
  let fixture: ComponentFixture<StyleInnerHtmlComponentTestComponent>;
  let newComponent: StyleInnerHtmlComponentTestComponent;

  beforeEach(waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [AALStyleInnerHTMLDirective]
      }).compileComponents().then(() => {
        directive = new AALStyleInnerHTMLDirective(null);
      });
      fixture = TestBed.createComponent(StyleInnerHtmlComponentTestComponent);
      newComponent = fixture.componentInstance;
      fixture.detectChanges();
    }));

  it('should create an instance', () => {
      directive = new AALStyleInnerHTMLDirective(null);
      expect(directive).toBeTruthy();
  });

  it('should call onChange value', () => {
    const changeObject = {
      text: new SimpleChange(null, 'test1-test2', false)
    };
    directive.specialCharacter = '-';
    directive.customStyle = 'color:blue';
    directive.el = newComponent.styleInnerHtmlDirective;
    directive.ngOnChanges(changeObject);
    expect(directive.el.nativeElement.innerHTML).toBe('<span>test1</span><span style="color:blue">test2</span>');
  });

});


@Component({
  selector: 'aal-style-inner-html-selector',
  template: `
        <div aalDragDropFile #styleInnerHtml>Sample text</div>
    `
})
export class StyleInnerHtmlComponentTestComponent {
  @ViewChild('styleInnerHtml') styleInnerHtmlDirective: ElementRef ;
}
