import {AALTrimInputDirective} from './trim-input.directive';
import {Component, DebugElement, OnInit} from '@angular/core';
import {ComponentFixture, TestBed} from '@angular/core/testing';
import {FormBuilder, FormControl, FormsModule, ReactiveFormsModule} from '@angular/forms';
import {By} from '@angular/platform-browser';

@Component({
  template: ` <input id="myInput" type="text" [formControl]="testControl" aalTrimInput/>`
})
class TestComponent implements OnInit {
  testControl: FormControl;

  constructor(private formBuilder: FormBuilder) {
  }

  ngOnInit() {
    this.testControl = this.formBuilder.control(' test value ');
  }
}

describe('AALTrimInputDirective', () => {
  let component: TestComponent;
  let fixture: ComponentFixture<TestComponent>;
  let debugElement: DebugElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [
        TestComponent,
        AALTrimInputDirective
      ],
      imports: [
        FormsModule,
        ReactiveFormsModule
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TestComponent);
    component = fixture.componentInstance;
    debugElement = fixture.debugElement;
    fixture.detectChanges();
  });

  it('should create component', () => {
    expect(component).toBeDefined();
  });

  it('should trim on blur', () => {
    const input = debugElement.query(By.css('#myInput'));
    const inputElement = input.nativeElement;
    inputElement.dispatchEvent(new Event('blur'));
    fixture.detectChanges();
    expect(fixture.componentInstance.testControl.value).toBe('test value');
  });

  it('should trim on keyup', () => {
    const input = debugElement.query(By.css('#myInput'));
    const inputElement = input.nativeElement;

    const event = new KeyboardEvent('keyup', {key: 'Enter'});
    inputElement.dispatchEvent(event);
    fixture.detectChanges();
    expect(fixture.componentInstance.testControl.value).toBe('test value');
  });
});
