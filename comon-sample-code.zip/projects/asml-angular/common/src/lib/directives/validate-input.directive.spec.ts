import {AALValidateInputDirective} from './validate-input.directive';
import {Component, DebugElement, OnInit} from '@angular/core';
import {ComponentFixture, TestBed} from '@angular/core/testing';
import {FormBuilder, FormControl, FormsModule, ReactiveFormsModule} from '@angular/forms';

@Component({
  template: ` <input id="myInput" type="text" [formControl]="testControl" aalValidateInput/>`
})
class TestComponent implements OnInit {
  testControl: FormControl;

  constructor(private formBuilder: FormBuilder) {
  }

  ngOnInit() {
    this.testControl = this.formBuilder.control(' test value ');
  }
}

describe('AALValidateInputDirective', () => {
  let component: TestComponent;
  let fixture: ComponentFixture<TestComponent>;
  let debugElement: DebugElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [
        TestComponent,
        AALValidateInputDirective
      ],
      imports: [
        FormsModule,
        ReactiveFormsModule
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TestComponent);
    component = fixture.componentInstance;
    debugElement = fixture.debugElement;
    fixture.detectChanges();
  });

  it('should create component', () => {
    expect(component).toBeDefined();
  });

});
