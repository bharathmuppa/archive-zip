import {Directive, ElementRef, Input, OnChanges, SimpleChanges} from '@angular/core';
import {FontTypes, LabelFontSizes, SubLabelFontSizes, ValueFontSizes} from '../models/enumeration.model';

@Directive({
  selector: '[aalChangeFontSize]'
})
export class AALChangeFontSizeDirective implements OnChanges {
  private size: string;
  @Input()
  isLabel: boolean;
  @Input()
  isSubLabel: boolean;
  constructor(public element: ElementRef) {
  }

  get fontSize(): string {
    return this.size;
  }

  @Input()
  set fontSize(fontSize: string) {
    this.size = fontSize;
  }

  static getLabelFontValue(fonttype): string {
    switch (fonttype) {
      case FontTypes.Small:
        return LabelFontSizes.Small;
      case FontTypes.Regular:
        return LabelFontSizes.Regular;
      case FontTypes.Large:
        return LabelFontSizes.Large;
      default:
        return LabelFontSizes.Small;
    }
  }

  static getSubLabelFontValue(fonttype): string {
    switch (fonttype) {
      case FontTypes.Small:
        return SubLabelFontSizes.Small;
      case FontTypes.Regular:
        return SubLabelFontSizes.Regular;
      case FontTypes.Large:
        return SubLabelFontSizes.Large;
      default:
        return SubLabelFontSizes.Small;
    }
  }

  static getTextFontValue(fonttype): string {
    switch (fonttype) {
      case FontTypes.Small:
        return ValueFontSizes.Small;
      case FontTypes.Regular:
        return ValueFontSizes.Regular;
      case FontTypes.Large:
        return ValueFontSizes.Large;
      default:
        return ValueFontSizes.Small;
    }
  }

  getFontValue(fontCategory?: string): string {
    if (this.isLabel) {
      return AALChangeFontSizeDirective.getLabelFontValue(fontCategory);
    } else if (this.isSubLabel) {
      return AALChangeFontSizeDirective.getSubLabelFontValue(fontCategory);
    } else {
      return AALChangeFontSizeDirective.getTextFontValue(fontCategory);
    }
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes && changes.fontSize && changes.fontSize.currentValue) {
      this.element.nativeElement.style.fontSize = this.getFontValue(changes.fontSize.currentValue);
      this.element.nativeElement.style.lineHeight = (changes.fontSize.currentValue === FontTypes.Large) ? '28px' : '20px';
    }
  }
}
