import {AALChangeFontSizeDirective} from './change-font-size.directive';
import {AALDisableControlDirective} from './disable-control.directive';
import {AALDragDropFileDirective} from './drag-drop-file.directive';
import {AALEnforceDecimalInputDirective} from './enforce-decimal-input.directive';
import {AALLoadBlankPortraitDirective} from './load-blank-potrait.directive';
import {AALStyleInnerHTMLDirective} from './style-inner-html.directive';
import {AALToggleFullScreenDirective} from './toggle-full-screen.directive';
import {AALTrimInputDirective} from './trim-input.directive';
import {AALValidateInputDirective} from './validate-input.directive';

export {
  AALChangeFontSizeDirective,
  AALDisableControlDirective,
  AALDragDropFileDirective,
  AALEnforceDecimalInputDirective,
  AALLoadBlankPortraitDirective,
  AALStyleInnerHTMLDirective,
  AALToggleFullScreenDirective,
  AALTrimInputDirective,
  AALValidateInputDirective
};


export const COMMON_DIRECTIVES = [
  AALChangeFontSizeDirective,
  AALDisableControlDirective,
  AALDragDropFileDirective,
  AALEnforceDecimalInputDirective,
  AALLoadBlankPortraitDirective,
  AALStyleInnerHTMLDirective,
  AALToggleFullScreenDirective,
  AALTrimInputDirective,
  AALValidateInputDirective
];
