import {Directive, Input, OnChanges, SimpleChanges} from '@angular/core';
import {NgControl} from '@angular/forms';

@Directive({
  selector: '[aalDisableControl]'
})
export class AALDisableControlDirective implements OnChanges {
  @Input()
  emitDisableEvent: boolean;
  constructor(private readonly ngControl: NgControl) {
  }

  @Input()
  set disableControl(condition: boolean) {
    const action = condition ? 'disable' : 'enable';
    if (this.ngControl.control) {
      this.ngControl.control[action]({emitEvent: (this.emitDisableEvent === undefined ? true : this.emitDisableEvent)});
    }

  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes) {
      const action = changes.disableControl.currentValue ? 'disable' : 'enable';
      if (this.ngControl.control) {
        this.ngControl.control[action]({emitEvent: (this.emitDisableEvent === undefined ? true : this.emitDisableEvent)});
      }
    }
  }

}
