/*
 * Public API Surface of material
 */
export {HistoryService} from './history.service';
