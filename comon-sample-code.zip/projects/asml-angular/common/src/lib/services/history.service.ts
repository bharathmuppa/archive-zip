import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class HistoryService {

  constructor() {
  }

  addItem(key: string, value: any) {
    if (!key || !value) {
      return;
    }
    let currentValue = JSON.parse(localStorage.getItem(key)) || [];
    const currentNumberOfItems = currentValue.length;
    const historyLimit = 4;
    const isValueAnArray = value instanceof Array;
    const resultArray = isValueAnArray ? value.concat(currentValue.filter((item) => value.indexOf(item) < 0)) : [];
    let isValueAlreadyPresent = false;
    // if its an auto complete multiple control
    if (Array.isArray(value)) {
      currentValue.forEach((item) => {
        value.forEach((valueItem) => {
          if (JSON.stringify(valueItem) === JSON.stringify(item)) {isValueAlreadyPresent = true; }
        });
      });
    // if its normal control
    } else {
      isValueAlreadyPresent = currentValue.filter((item) => JSON.stringify(item) === JSON.stringify(value)).length > 0;
    }
    if (currentNumberOfItems === 0) {
      localStorage.setItem(key, JSON.stringify(isValueAnArray ? value : [value]));
    } else if (!isValueAlreadyPresent && currentNumberOfItems < historyLimit) {
      if (isValueAnArray) {
        currentValue = (resultArray.length > historyLimit) ? resultArray.slice(0, historyLimit) : resultArray;
      } else {
        currentValue.unshift(value);
      }
      localStorage.setItem(key, JSON.stringify(currentValue));
    } else if (!isValueAlreadyPresent && currentNumberOfItems === historyLimit) {
      if (isValueAnArray) {
        currentValue = (resultArray.length > historyLimit) ? resultArray.slice(0, historyLimit) : resultArray;
      } else {
        currentValue.splice(historyLimit - 1, 1);
        currentValue.unshift(value);
      }
      localStorage.setItem(key, JSON.stringify(currentValue));
    } else {
      // do nothing
    }
  }

  getItems(key: string): string[] {
    if (!key) {
      return [];
    }
    const currentValue = JSON.parse(localStorage.getItem(key));
    if (currentValue && currentValue.length > 0) {
      return currentValue;
    } else {
      return [];
    }
  }
}
