import {Component, ElementRef, Input, OnInit, ViewChild} from '@angular/core';
import {AALCommonFormControlComponent} from './common-form-control.component';
import {HistoryService} from '../services/history.service';
import {map, startWith} from 'rxjs/operators';
import {Observable} from 'rxjs';
import {Statuses} from '../models/enumeration.model';
import {UntypedFormControl} from '@angular/forms';

@Component({
  template: ``
})
export class AALInputFormControlComponent extends AALCommonFormControlComponent implements OnInit {
  filteredOptions: Observable<string[]>;
  @ViewChild('inputField') inputField: ElementRef;
  @Input()
  align?: string;
  @Input()
  showLengthHint: boolean;
  @Input()
  maxLength: number;
  @Input()
  hint: string;

  @Input()
  set control(val: UntypedFormControl) {
    this.frmControl = val;
    if (val && val.value !== undefined) {
      this.oldValue = (typeof val.value === 'object' ? JSON.parse(JSON.stringify(val.value)) : val.value);
    }
  }

  get control(): UntypedFormControl {
    return this.frmControl;
  }

  constructor(historyService: HistoryService) {
    super(historyService);
  }

  ngOnInit() {
    super.setDefaultValue();
    if (this.control) {
      this.filteredOptions = this.control.valueChanges
        .pipe(
          startWith(''),
          map(value => this.filterHistory(value))
        );
    }
  }

  filterHistory(value: any): string[] {
    let filterValue = value;
    if (typeof value === 'string') {
      filterValue = value.toLowerCase();
    }
    const history = this.getHistory();
    if (history && history.length > 0) {
      if (typeof value === 'number') {
        return this.getHistory().filter(option => option && option.toString().includes(filterValue));
      }
      return this.getHistory().filter((option) => {
        let optionReturnValue;
        if (option && typeof option === 'string') {
          optionReturnValue = option.toLowerCase().includes(filterValue);
        } else if (option && typeof option === 'number') {
          optionReturnValue = option.toString().includes(filterValue);
        }
        return optionReturnValue;
      });
    }
    return [];
  }

  onClick(): void {
    super.setModeToEdit();
    setTimeout(() => {
      if (this.inputField && this.inputField.nativeElement) {
        this.inputField.nativeElement.focus();
      }
    });
  }

  onBlur($event?: Event) {
    this.triggerAcceptChangesWhenStatusIsDraft();
  }

  onOptionSelected() {
    this.triggerAcceptChangesWhenStatusIsDraft();
  }

  triggerAcceptChangesWhenStatusIsDraft() {
    if (this.status === Statuses.DRAFT) {
      this.triggerAcceptChanges();
    }
  }

  onFocus() {
    this.showConfirmationToolbar = true;
    this.status = Statuses.DRAFT;
  }

  onKeyUp(event: KeyboardEvent) {
    if (event.key === 'Enter') {
      this.triggerAcceptChanges();
    } else if (event.key === 'Escape') {
      this.triggerRejectChanges();
    }
  }
}
