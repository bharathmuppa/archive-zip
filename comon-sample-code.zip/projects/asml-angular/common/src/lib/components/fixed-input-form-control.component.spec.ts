import {waitForAsync, ComponentFixture, TestBed} from '@angular/core/testing';
import {FormControl, Validators} from '@angular/forms';

import {AALFixedInputFormControlComponent} from './fixed-input-form-control.component';
import {HistoryService} from '../services/history.service';
import {AALCommonFormControlComponent} from './common-form-control.component';

class HistoryServiceMock {
  historyContainer = {ID: ['Item A', 'Item B', 'Item AA']};

  addItem(key: string, value: string): void {
    this.historyContainer[key] = this.historyContainer[key] || [];
    this.historyContainer[key].push(value);
  }

  getItems(key: string): string[] {
    return this.historyContainer[key];
  }
}

describe('AALFixedInputFormControlComponent', () => {
  let component: AALFixedInputFormControlComponent;
  let fixture: ComponentFixture<AALFixedInputFormControlComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [AALFixedInputFormControlComponent],
      providers: [{provide: HistoryService, useClass: HistoryServiceMock}]
    }).compileComponents().then(() => {
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALFixedInputFormControlComponent);
    component = fixture.componentInstance;
    component.control = new FormControl('actual val', Validators.compose([
      Validators.required
    ]));
    component.getHistory = () => {
      return [{name: 'abc', abbr: 'ab', id: 1}];
    };
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should return true for same objects (compareByValue)', () => {
    const f1 = {label: 'label', value: 'value'};
    const output = component.compareByValue(f1, f1);
    expect(output).toBeTruthy();
  });

  it('should return history (getHistory$)', () => {
    component.ID = 'ID';
    expect(component.getHistory$()).toBeTruthy();
  });

  it('should return history (getHistory$) when no history', () => {
    component.getHistory = () => {
      return [];
    };
    fixture.detectChanges();
    component.ID = 'ID';
    expect(component.getHistory$()).toBeTruthy();
  });

  it('should return true for same string values (compareByValue)', () => {
    const output = component.compareByValue('option1', 'option1');
    expect(output).toBeTruthy();
  });

  it('should return true for different objects with same values and optionValueField as value(compareByValue)', () => {
    const f1 = {label: 'label', value: 'value'};
    const f2 = {label: 'label different', value: 'value'};
    component.primaryKeyInValue = 'value';
    const output = component.compareByValue(f1, f2);
    expect(output).toBeTruthy();
  });

  it('should return false for different objects (compareByValue)', () => {
    const f1 = {label: 'label', value: 'value'};
    const output = component.compareByValue(f1, {});
    expect(output).toBeFalsy();
  });

  it('should return false for different string values (compareByValue)', () => {
    const output = component.compareByValue('option1', 'option2');
    expect(output).toBeFalsy();
  });

  it('should return false for objects with different values and optionValueField as value(compareByValue)', () => {
    const f1 = {label: 'label', value: 'value'};
    const f2 = {label: 'label', value: 'value1'};
    component.optionValueField = 'value';
    const output = component.compareByValue(f1, f2);
    expect(output).toBeFalsy();
  });

  it('should return empty string as  display text no option selected yet (getDisplayText)', () => {
    component.control.setValue('');
    const output = component.getDisplayText();
    expect(output).toEqual('');
  });

  it('should return option as display text as option is plain string (getDisplayText)', () => {
    component.control.setValue('option');
    const output = component.getDisplayText();
    expect(output).toEqual('option');
  });

  it('should return option object label as display text as option is an object (getDisplayText)', () => {
    component.control.setValue({label: 'controlLabel', value: 'controlValue'});
    component.optionLabelField = 'label';
    fixture.detectChanges();
    const outputWithObject = component.getDisplayText();
    expect(outputWithObject).toEqual('controlLabel');
  });

  it('should return concatenated options as display text as selected options are multiple strings (getDisplayText)', () => {
    const options = ['option1', 'option2'];
    component.control.setValue(options);
    fixture.detectChanges();
    const outputWithArray = component.getDisplayText();
    expect(outputWithArray).toEqual('option1, option2');
  });

  it('should return concatenated options labels as display text as selected options are multiple objects (getDisplayText)', () => {
    const options = [{label: 'controlLabel1', value: 'controlValue1'}, {
      label: 'controlLabel2',
      value: 'controlValue2'
    }];
    component.control.setValue(options);
    component.optionLabelField = 'label';
    fixture.detectChanges();
    const outputWithArray = component.getDisplayText();
    expect(outputWithArray).toEqual('controlLabel1, controlLabel2');
  });

  it('should option text be sliced as its length is more than ellipsisAfter  (getLabelByOption)', () => {
    component.ellipsisAfter = 4;
    const actualOptionText = 'option text';
    const optionText = component.getLabelByOption(actualOptionText);
    expect(optionText).toBe('opti ...');
  });

  it('should option text not be sliced as its length is less than ellipsisAfter  (getLabelByOption)', () => {
    component.ellipsisAfter = 20;
    const actualOptionText = 'option text';
    const optionText = component.getLabelByOption(actualOptionText);
    expect(optionText).toBe('option text');
  });

  it('should call super method when (onClick) is triggered', () => {
    const superOnClickSpy = spyOn(AALCommonFormControlComponent.prototype, 'setModeToEdit').and.callThrough();
    component.onClick();
    expect(superOnClickSpy).toHaveBeenCalled();
  });

  it('should return option label when option type is object and option label property is supplied(getLabelByValue)', () => {
    component.options = [
      {label: 'controlLabel1', name: 'controlName1'},
      {label: 'controlLabel2', name: 'controlName2'}
    ];
    component.optionLabelField = 'label';
    component.optionValueField = 'name';
    component.optionType = 'object';
    fixture.detectChanges();
    const output = component.getLabelByValue('controlName2');
    expect(output).toEqual('controlLabel2');
  });

  it('should return option label when option type is string (getLabelByValue)', () => {
    component.options = ['controlLabel1', 'controlLabel2'];
    component.optionType = 'string';
    fixture.detectChanges();
    const output = component.getLabelByValue('controlLabel2');
    expect(output).toEqual('controlLabel2');
  });


  it('should return empty string as  display text no option selected yet (getDisplayText)', () => {
    component.control.setValue('');
    const output = component.getDisplayText();
    expect(output).toEqual('');
  });

  it('should return option as display text as option is plain string (getDisplayText)', () => {
    component.control.setValue('option');
    const output = component.getDisplayText();
    expect(output).toEqual('option');
  });

  it('should return option object label as display text as option is an object (getDisplayText)', () => {
    component.control.setValue({label: 'controlLabel', value: 'controlValue'});
    component.optionLabelField = 'label';
    fixture.detectChanges();
    const outputWithObject = component.getDisplayText();
    expect(outputWithObject).toEqual('controlLabel');
  });

  it('should set default value as false when control value and valuesWhereOtherOptionsDisabled is same on initialization', () => {
    component.valuesWhereOtherOptionsDisabled = ['test', '1'];
    component.control.setValue('1');
    component.ngOnInit();
    expect(component.disableOtherOptions).toBe(true);
  });

  it('should set default value as false when control value and valuesWhereOtherOptionsDisabled is not same on initialization', () => {
    component.valuesWhereOtherOptionsDisabled = ['test', 'test1'];
    component.control.setValue('1');
    component.ngOnInit();
    expect(component.disableOtherOptions).toBe(false);
  });

  it('should call triggerAcceptChanges on control value change', () => {
    component.control.setValue({label: 'controlLabel', value: 'controlValue'});
    component.optionLabelField = 'label';
    fixture.detectChanges();
    spyOn(component, 'triggerAcceptChanges');
    const $event = new Event('change');
    component.onChange($event);
    expect(component.triggerAcceptChanges).toHaveBeenCalled();
  });

  it('should return nothing when tooltip by Value is triggered', () => {
    component.optionValueField = 'option1';
    component.optionLabelField = 'option1';
    component.optionType = 'object';
    component.ellipsisAfter = 5;
    component.options = [{option1: 'test', option2: 'test2'}];
    const returnValue = component.getTooltipByValue('test');
    expect(returnValue).toBe('');
  });

  it('should return false for isOptionDisabled when option is not disabled', () => {
    component.disabledOptionsList = [{name: 'option1', label: 'option2'}];
    const option = ['option1', 'option2', 'option3'];
    component.optionValueField = 'option1';
    const returnVal = component.isOptionDisabled(option);
    expect(returnVal).toBe(false);
  });

  it('should return true for isOptionDisabled method when option is disabled', () => {
    component.disabledOptionsList = [{name: 'option1', label: 'description1'}];
    component.optionValueField = 'name';
    const option = {
      name: 'option1', label: 'description1'
    };
    expect(component.isOptionDisabled(option)).toBeTruthy();
  });

  it('should return false when disabledOptionsList is not set', () => {
    component.disableOtherOptions = false;
    const option = ['option1', 'option2', 'option3'];
    component.optionValueField = 'option1';
    fixture.detectChanges();
    const returnVal = component.isOptionDisabled(option);
    expect(returnVal).toBe(false);
  });

  it('should return true when disableOtherOptions is true', () => {
    component.disableOtherOptions = true;
    component.control.setValue('option1');
    const option = ['option1', 'option2', 'option3'];
    component.optionValueField = 'option1';
    component.valuesWhereOtherOptionsDisabled = ['no-Option'];
    fixture.detectChanges();
    const returnVal = component.isOptionDisabled(option);
    expect(returnVal).toBe(true);
  });

  it('should return ---None --- string when set options are trigger to clear selected option', () => {
    component.options = [{name: 'option1', description: 'description1'},
      {name: 'option2', description: 'description2'},
      {name: 'option3', description: 'description3'}];
    component.isNullable = true;
    component.optionValueField = 'name';
    component.optionLabelField = 'description';
    fixture.detectChanges();
    component.setEmptyOption();
    expect(component.options[0].description).toBe('-- None --');
    component.options = ['option1', 'option2', 'option3'];
    expect(component.options[0]).toBe('-- None --');
  });

  it('should reset the control value to null (resetControl)', () => {
    component.control = new FormControl('test');
    component.resetControl();
    expect(component.control.value).toBe(null);
  });

  it('Should return Value when option is passed (getValueByOptions)', () => {
    const options = [{label: 'controlLabel1', value: 'controlValue1'}, {
      label: 'controlLabel2',
      value: 'controlValue2'
    }];
    component.control.setValue(options);
    component.optionValueField = 'value';
    const returnValue = component.getValueByOption(options[0]);
    expect(returnValue).toBe('controlValue1');
  });


});
