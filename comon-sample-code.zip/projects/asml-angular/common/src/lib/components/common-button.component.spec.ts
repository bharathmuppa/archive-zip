import {waitForAsync, ComponentFixture, TestBed} from '@angular/core/testing';

import {AALCommonButtonComponent} from './common-button.component';

describe('AALCommonButtonComponent', () => {
  let component: AALCommonButtonComponent;
  let fixture: ComponentFixture<AALCommonButtonComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ AALCommonButtonComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALCommonButtonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set actualBadgeData when badge data and referenceData is provided', () => {
    component.badgeType = 'double';
    component.referenceBadgeData = 4567;
    component.setActualBadgeData(1234);
    expect(component.actualBadgeData).toBe('1234/4567');
  });

  it('should set the actual badge data same as the badge data supplied when badge type is single', () => {
    component.badgeType = 'single';
    component.badgeData = 1234;
    expect(component.actualBadgeData).toBe('1234');
  });

  it('should emit the onClick event when button is pressed', () => {
    spyOn(component.onClick, 'emit');
    const $event = new Event('click');
    component.click($event);
    expect(component.onClick.emit).toHaveBeenCalled();
  });

  it('should return the class(for styling) for badge based on the number of characters in badge string/ number', () => {
    component.actualBadgeData = 'do';
    const returnVal1 = component.getBadgeClass();
    expect(returnVal1).toBe('raiseBadge--small');

    component.actualBadgeData = 'test';
    const returnVal2 = component.getBadgeClass();
    expect(returnVal2).toBe('raiseBadge--medium');

    component.actualBadgeData = 'test1s';
    const returnVal3 = component.getBadgeClass();
    expect(returnVal3).toBe('raiseBadge--large');
  });

  it('should  return class name when iconSize is set as medium', () => {
    component.iconSize = 'medium';
    const returnVal = component.getClassByIconSize();
    expect(returnVal).toBe('icon--medium');
  });

  it('should set id to the element and . should be replaced by - if supplied id has any dots(.)', () => {
    component.ID = 'test.value';
    const returnVal1 = component.getHyphenatedID();
    expect(returnVal1).toBe('test_value');

    component.ID = '';
    const returnVal2 = component.getHyphenatedID();
    expect(returnVal2).toBe('');
  });
});
