import {Component, EventEmitter, Input, Output} from '@angular/core';
import {AbstractControl, UntypedFormControl} from '@angular/forms';
import {ReplaySubject, Subject} from 'rxjs';

import {Mode, Modes, Statuses} from '../models/enumeration.model';
import {AcceptedChange, RejectedChange} from '../models/event.model';
import {Info, ValidatorMessage} from '../models/presentation.model';
import {HistoryService} from '../services/history.service';

@Component({
  template: ``
})
export class AALCommonFormControlComponent {
  /**
   * Information to show in Help card or just a plain string to show as help
   */
  @Input()
  help: Info | string;
  /**
   * Flag to show alert display
   */
  @Input()
  useDefaultAlertDisplay: boolean;
  /**
   * Flag to show help display
   */
  @Input()
  useDefaultHelpDisplay: boolean;
  /**
   * Flag to show validation display
   */
  @Input()
  useDefaultValidationDisplay: boolean;
  /**
   * TODO: Define this
   */
  @Input()
  showValueChip: boolean;
  @Input()
  hideLabel: boolean;

  /**
   * Sets the Mode to below Modes
   * Modes.EDIT - Changes control to be editable (Will show form control)
   * Modes.READ - Form control will be hidden and HTML element with value is show
   * Modes.PROTECTED - Form field should be disabled.
   * Modes.PRIVATE - TODO: Define this
   * @param value
   */
  @Input()
  set mode(value: Mode) {
    this.modeValue = value;
    this.showConfirmationToolbar = this.modeValue === Modes.EDIT;
  }

  get mode(): Mode {
    return this.modeValue;
  }

  @Input()
  placeholder: string;
  @Input()
  mandatoryToolTip: string;
  @Input()
  isHistoryEnabled: boolean;
  @Input()
  isBusy: boolean;
  @Input()
  fontSize: string;
  /**
   * Lock mode is to Lock the Model.
   */
  @Input()
  lockMode: Mode;
  @Input()
  hideHelp: boolean;
  @Input()
  confirmToolBarNotApplicable: boolean;
  @Input()
  alignConfirmToolbarHorizontally: boolean;
  @Output()
  acceptChanges: EventEmitter<any> = new EventEmitter();
  @Output()
  rejectChanges: EventEmitter<any> = new EventEmitter();
  @Input()
  disableControl: boolean;
  @Input()
  emitDisableEvent: boolean;
  @Input()
  showHyphenForValues: any[];
  error: Info;
  showConfirmationToolbar: boolean;
  oldValue: any;
  newValue: any;
  status: string;
  fieldLabel: string;
  fieldID: any;
  hyphenatedID: string;
  modes = Modes;
  modeValue: Mode;
  mode$: Subject<Mode> = new ReplaySubject<Mode>(1);
  frmControl: UntypedFormControl;
  ignoreValidations: boolean;
  private valueToRevert: any;

  constructor(private readonly historyService: HistoryService) {
  }

  get control() {
    return this.frmControl;
  }

  @Input()
  set control(val: UntypedFormControl) {
    this.frmControl = val;
    if (val && val.value !== undefined) {
      this.oldValue = (typeof val.value === 'object' ? JSON.parse(JSON.stringify(val.value)) : val.value);
      this.valueToRevert = this.oldValue;
    }
  }

  @Input()
  set alert(error: Info) {
    this.error = error;
    if (error) {
      this.revertChanges();
    }
  }

  // this input added to show warning manually
  @Input()
  set displayWarning(warn: Info) {
    this.error = warn;
  }

  @Input()
  set label(val: string) {
    this.fieldLabel = val;
  }

  get label() {
    return this.fieldLabel;
  }

  @Input()
  set ID(id: string) {
    this.fieldID = id;
    this.hyphenatedID = id ? id.replace(/\./g, '_') : '';
  }

  get ID() {
    return this.fieldID;
  }

  setDefaultValue() {
    this.isBusy = false;
    this.showConfirmationToolbar = false;
    this.useDefaultHelpDisplay = this.useDefaultHelpDisplay === null || this.useDefaultHelpDisplay === undefined ?
      true : this.useDefaultHelpDisplay;
    this.useDefaultAlertDisplay = this.useDefaultAlertDisplay === null || this.useDefaultAlertDisplay === undefined ?
      true : this.useDefaultAlertDisplay;
    this.useDefaultValidationDisplay = this.useDefaultValidationDisplay === null ||
    this.useDefaultValidationDisplay === undefined ? true : this.useDefaultValidationDisplay;
    this.status = this.status === null || this.status === undefined ? Statuses.DRAFT : this.status;
    this.isHistoryEnabled = this.isHistoryEnabled === null || this.isHistoryEnabled === undefined || this.isHistoryEnabled === false ?
      false : this.isHistoryEnabled;
    this.mode === null || this.mode === undefined ? this.setMode(Modes.READ) : this.setMode(this.mode);

    if (this.help && typeof this.help === 'string') {
      this.help = new Info(this.help);
    }
  }

  getHistory(): any [] {
    return (this.historyService && this.isHistoryEnabled) ? this.historyService.getItems(this.ID) : [];
  }

  getValidatorMessages(): string[] {
    return this.frmControl.errors == null ? [] : Object.keys(this.frmControl.errors)
      .map(error => this.getValidatorMessage(error));
  }

  getValidatorMessage(validatorKey: any): string {
    const message: string = this.frmControl.errors[validatorKey] ?
      (this.frmControl.errors[validatorKey] as ValidatorMessage).message : '';
    if (validatorKey && typeof validatorKey === 'string') {
      switch (validatorKey.toUpperCase()) {
        case 'MAXLENGTH':
          const requiredLengthMax = (this.control.errors[validatorKey] as { requiredLength, actualLength }).requiredLength;
          const actualLengthMax = (this.control.errors[validatorKey] as { requiredLength, actualLength }).actualLength;
          return `${this.placeholder} should be less than or equal to ${requiredLengthMax} characters, actual length ` +
            `is ${actualLengthMax} characters.`;
        case 'MINLENGTH':
          const requiredLengthMin = (this.control.errors[validatorKey] as { requiredLength, actualLength }).requiredLength;
          const actualLengthMin = (this.control.errors[validatorKey] as { requiredLength, actualLength }).actualLength;
          return `${this.placeholder} should be more than or equal to ${requiredLengthMin} characters, actual length ` +
            `is ${actualLengthMin} characters.`;
        default :
          return `Failed validation: ${validatorKey}`;
      }
    } else if (message && message.length > 0) {
      return message;
    }
    return `Failed validation: ${validatorKey}`;
  }

  triggerAcceptChanges(skipAcceptChangeEvent?: boolean) {
    const temp = this.newValue || this.control.value;
    const acceptedValue = typeof temp === 'object' ? JSON.parse(JSON.stringify(temp)) : temp;
    const sameAsOldValueByValue = (typeof acceptedValue === 'object' ?
      acceptedValue && this.oldValue && JSON.stringify(acceptedValue) === JSON.stringify(this.oldValue) :
      acceptedValue === this.oldValue);
    this.showConfirmationToolbar = false;
    if (this.control.valid || this.ignoreValidations) {
      if ((!this.oldValue && acceptedValue) || (this.oldValue && !sameAsOldValueByValue) ||
        (!this.oldValue && typeof acceptedValue === 'number' && !isNaN(acceptedValue))) {
        if (!skipAcceptChangeEvent) {
          this.acceptChanges.emit(new AcceptedChange(this.ID, acceptedValue, this.oldValue));
        }
        this.status = Statuses.ACCEPTED;
        this.valueToRevert = typeof this.oldValue === 'object' ? JSON.parse(JSON.stringify(this.oldValue)) : this.oldValue;
        if (!skipAcceptChangeEvent) {
          this.oldValue = typeof acceptedValue === 'object' ? JSON.parse(JSON.stringify(acceptedValue)) : acceptedValue;
        }
      }
      this.lockMode ? this.setMode(this.lockMode) : this.setMode(Modes.READ);
      if (this.isHistoryEnabled) {
        this.historyService.addItem(this.ID, this.control.value);
      }
    } else {
      this.triggerRejectChanges();
    }
  }

  triggerRejectChanges() {
    const rejectedValue = this.newValue || (this.frmControl) ? this.frmControl.value : undefined;
    this.showConfirmationToolbar = false;
    if ((!this.oldValue && rejectedValue) || (this.oldValue && this.oldValue !== rejectedValue)) {
      this.rejectChanges.emit(new RejectedChange(this.ID, this.oldValue, rejectedValue));
      this.status = Statuses.REJECTED;
      this.frmControl.setValue(this.oldValue || '');
    }
    this.lockMode ? this.setMode(this.lockMode) : this.setMode(Modes.READ);
  }

  revertChanges() {
    if (this.valueToRevert !== undefined) {
      this.showConfirmationToolbar = false;
      this.frmControl.setValue(this.valueToRevert);
      this.oldValue = typeof this.valueToRevert === 'object' ? JSON.parse(JSON.stringify(this.valueToRevert)) : this.valueToRevert;
      if (this.mode === Modes.EDIT) {
        this.lockMode ? this.setMode(this.lockMode) : this.setMode(Modes.READ);
      }
    }
  }

  setModeToEdit() {
    const selection = window.getSelection();
    if (this.mode !== Modes.PROTECTED && this.mode !== Modes.PRIVATE && !this.isBusy && selection.toString().length === 0) {
      this.setMode(Modes.EDIT);
      this.showConfirmationToolbar = true;
    }
  }

  hasRequiredValidator(): boolean {
    if (this.control && this.control.validator && this.control.validator({} as AbstractControl)) {
      return this.control.validator({} as AbstractControl).hasOwnProperty('required');
    } else {
      return false;
    }
  }

  setMode(mode: Mode) {
    this.mode = mode;
    this.mode$.next(mode);
  }

  isModeEdit(): boolean {
    return this.mode === Modes.EDIT;
  }

  isModeRead(): boolean {
    return this.mode === Modes.READ;
  }

  isModeProtected(): boolean {
    return this.mode === Modes.PROTECTED;
  }

  isModePrivate(): boolean {
    return this.mode === Modes.PRIVATE;
  }

  getHyphenatedID() {
    return this.ID ? this.ID.replace(/\./g, '_') : '';
  }

  // TODO: need to use either Label or Placeholder, Not both
  getPlaceholder(): string {
    return this.placeholder || '';
  }

  getFieldLabel(): string {
    return this.label;
  }
}
