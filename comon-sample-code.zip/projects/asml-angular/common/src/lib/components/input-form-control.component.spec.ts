import {waitForAsync, ComponentFixture, TestBed} from '@angular/core/testing';
import {FormControl} from '@angular/forms';

import {HistoryService} from '../services/history.service';
import {Modes, Statuses} from '../models/enumeration.model';
import {AALInputFormControlComponent} from './input-form-control.component';

import createSpyObj = jasmine.createSpyObj;

class HistoryServiceMock {
  historyContainer = {ID: ['Item A', 'Item B', 'Item AA']};

  getItems(key: string): string[] {
    return this.historyContainer[key];
  }
}

describe('AALInputFormControlComponent', () => {
  let component: AALInputFormControlComponent;
  let fixture: ComponentFixture<AALInputFormControlComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [AALInputFormControlComponent],
      providers: [{provide: HistoryService, useClass: HistoryServiceMock}]
    })
      .compileComponents().then(() => {
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALInputFormControlComponent);
    component = fixture.componentInstance;
    jasmine.clock().uninstall();
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should triggerAcceptChanges be called (onBlur)', () => {
    component.status = Statuses.DRAFT;
    component.control = new FormControl('test value');
    const triggerAcceptChangesSpy = spyOn(component, 'triggerAcceptChanges').and.returnValue(null);
    component.onBlur();
    fixture.detectChanges();
    expect(triggerAcceptChangesSpy).toHaveBeenCalled();
    expect(component.mode).toEqual('READ');
  });

  it('should triggerAcceptChanges be called (onOptionSelected)', () => {
    component.status = Statuses.DRAFT;
    component.control = new FormControl('test value');
    const triggerAcceptChangesSpy = spyOn(component, 'triggerAcceptChanges').and.returnValue(null);
    component.onOptionSelected();
    fixture.detectChanges();
    expect(triggerAcceptChangesSpy).toHaveBeenCalled();
    expect(component.mode).toEqual('READ');
  });

  it('should status be DRAFT (onFocus)', () => {
    component.onFocus();
    expect(component.status).toEqual('DRAFT');
  });
  it('should mode be EDIT (onClick)', () => {
    component.mode = Modes.READ;
    setTimeout(() => {
        component.onClick();
        expect(component.mode).toEqual('EDIT');
      }, 1000
    );

  });
  it('should call triggerAcceptChanges on Enter key press, and triggerRejectChanges be called on Escape key press', () => {
    const triggerAcceptChangesSpy = spyOn(component, 'triggerAcceptChanges').and.returnValue(null);
    component.onKeyUp({key: 'Enter'} as KeyboardEvent);
    expect(triggerAcceptChangesSpy).toHaveBeenCalled();
    const triggerRejectChangesSpy = spyOn(component, 'triggerRejectChanges').and.returnValue(null);
    const event = new KeyboardEvent('keydown', {
      key: 'Escape'
    });
    document.dispatchEvent(event);
    component.onKeyUp(event);
    expect(triggerRejectChangesSpy).toHaveBeenCalled();
  });

  it('should set initial values for showConfirmationtoolbar and isBusy on onInit', () => {
    component.ID = 'ID';
    component.control = new FormControl('current value');
    component.control.setValue('New Value');
    component.ngOnInit();
    expect(component.showConfirmationToolbar).toBeFalsy();
    expect(component.isBusy).toBeFalsy();
  });

  it('should return history when string value is passed as option', () => {
    component.ID = 'ID';
    component.isHistoryEnabled = true;
    component.control = new FormControl('current value');
    expect(component.filterHistory('Item A').length).toBeGreaterThan(0);
  });

  it('should return empty history the component(ngOnInit) when isHistoryEnabled is true and ID is set', () => {
    component.ID = 'ID';
    component.isHistoryEnabled = true;
    component.control = new FormControl('current value');
    component.getHistory = () => {
      return [];
    };
    fixture.detectChanges();
    expect(component.filterHistory('Item A').length).toEqual(0);
  });

  it('should return number history the component(ngOnInit)', () => {
    component.ID = 'ID';
    component.isHistoryEnabled = true;
    component.control = new FormControl('current value');
    component.getHistory = () => {
      return ['1', '2'];
    };
    fixture.detectChanges();
    expect(component.filterHistory(2).length).toEqual(1);
  });

  it('should return all history options, when filterHistory is triggered, value is empty and history options are of type number', () => {
    component.ID = 'ID';
    component.isHistoryEnabled = true;
    component.control = new FormControl('current value');
    component.getHistory = () => {
      return [1, 2];
    };
    fixture.detectChanges();
    expect(component.filterHistory('').length).toEqual(2);
  });

  it('should trigger accept changes on blur', () => {
    component.status = Statuses.DRAFT;
    component.control = new FormControl('test value');
    const triggerAcceptChangesSpy = spyOn(component, 'triggerAcceptChanges').and.returnValue(null);
    component.onBlur();
    fixture.detectChanges();
    expect(triggerAcceptChangesSpy).toHaveBeenCalled();
    expect(component.mode).toEqual('READ');
  });

  it('should set the mode to EDIT and input element has to be focused,  on click', () => {
    component.inputField = createSpyObj('inputField', ['nativeElement']);
    component.inputField.nativeElement = { focus: () => { }};
    spyOn(component.inputField.nativeElement, 'focus');
    jasmine.clock().install();
    component.onClick();
    jasmine.clock().tick(1000);
    expect(component.mode).toBe(Modes.EDIT);
    expect(component.inputField.nativeElement.focus).toHaveBeenCalled();
    jasmine.clock().uninstall();
  });
});
