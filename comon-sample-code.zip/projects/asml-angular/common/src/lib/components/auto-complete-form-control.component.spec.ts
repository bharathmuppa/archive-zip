import {waitForAsync, ComponentFixture, TestBed} from '@angular/core/testing';
import {FormControl, Validators} from '@angular/forms';

import {AALAutoCompleteFormControlComponent} from './auto-complete-form-control.component';
import {HistoryService} from '../services/history.service';
import {Modes} from '../models/enumeration.model';
import createSpyObj = jasmine.createSpyObj;


class HistoryServiceMock {
  historyContainer = {ID: ['Item A', 'Item B', 'Item AA']};

  // noinspection JSUnusedGlobalSymbols
  addItem(key: string, value: string): void {
    this.historyContainer[key] = this.historyContainer[key] || [];
    this.historyContainer[key].push(value);
  }

  // noinspection JSUnusedGlobalSymbols
  getItems(key: string): string[] {
    return this.historyContainer[key];
  }
}

describe('AALAutoCompleteFormControlComponent', () => {
  let component: AALAutoCompleteFormControlComponent;
  let fixture: ComponentFixture<AALAutoCompleteFormControlComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [AALAutoCompleteFormControlComponent],
      providers: [{provide: HistoryService, useClass: HistoryServiceMock}]
    }).compileComponents().then(() => {
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALAutoCompleteFormControlComponent);
    component = fixture.componentInstance;
    component.control = new FormControl('actual val', Validators.compose([
      Validators.required
    ]));
    component.getHistory = () => {
      return [{name: 'abc', abbr: 'ab', id: 1}];
    };
    component.displayFields = ['abc', 'test'];
    fixture.detectChanges();
    jasmine.clock().uninstall();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should return filter data when removeControlValues is trigger', () => {
    component.control.setValue(['2001']);
    const data = ['2001', '2002', '2003'];
    const returnValue = component.removeControlValues(data);
    expect(returnValue.length).toBe(2);
  });

  it('should return filter data when removeControlValues is trigger and control value is empty', () => {
    component.control.setValue([]);
    const data = ['2001', '2002', '2003'];
    const returnValue = component.removeControlValues(data);
    expect(returnValue.length).toBe(3);
  });
  it('should set the text based on displayFields value', () => {
    component.itemDisplayField = ['name', 'abbr'];
    component.filteredList$ = [{name: 'abc', abbr: 'ab', id: 12}];
    expect(component.getDisplayText(component.filteredList$[0], component.displayFields)).toBe('abc - ab');
    component.itemDisplayField = 'name';
    expect(component.getDisplayText(component.filteredList$[0], component.displayFields)).toBe('abc');
  });

  it('should set the text based on displayFields value and custom separator', () => {
    component.itemDisplayField = ['name', 'abbr'];
    component.separator = '*';
    component.filteredList$ = [{name: 'abc', abbr: 'ab', id: 12}];
    expect(component.getDisplayText(component.filteredList$[0], component.displayFields)).toBe('abc * ab');
  });

  it('should return the same string, when getDisplayText is triggered and item is a string', () => {
    component.itemDisplayField = ['name', 'abbr'];
    expect(component.getDisplayText('label', component.displayFields)).toBe('label');
  });

  it('should set the text based on displayFields value if it is a string', () => {
    component.filteredList$ = [{name: 'abc', abbr: 'ab', id: 12}];
    component.itemDisplayField = 'name';
    expect(component.getDisplayText(component.filteredList$[0], component.displayFields)).toBe('abc');
  });

  it('should set the mode to Edit on click of readable text', () => {
    component.onClick();
    component.inputField = createSpyObj('inputField', ['nativeElement']);
    component.inputField.nativeElement = {
      focus: () => {
      }
    };
    expect(component.mode).toBe(Modes.EDIT);
  });

  it('should emit triggerRejectChanges when escape is pressed', () => {
    spyOn(component, 'triggerRejectChanges');
    const event = new KeyboardEvent('keydown', {
      key: 'Escape'
    });
    document.dispatchEvent(event);
    component.onKeyUp(event);
    expect(component.triggerRejectChanges).toHaveBeenCalled();
  });

  it('should return string separated by parenthesis,  when getDisplayText is triggered and separator is supplied as Parenthesis', () => {
    const item = {test: 'test val'};
    const displayFields = ['test'];
    component.separator = 'Parenthesis';
    const returnVal = component.getDisplayText(item, displayFields);
    expect(returnVal).toBe('(test val)');
  });

  it('should return string with space on set for separator when getDisplayText is triggered', () => {
    const item = {test: 'test val'};
    const displayFields = ['test'];
    component.separator = '';
    const returnVal = component.getDisplayText(item, displayFields);
    expect(returnVal).toBe('test val');
  });

  it('should return value separated by "-" when no separator is supplied', () => {
    const item = {name: 'test val', abbr: 'TV'};
    const displayFields = ['name', 'abbr'];
    const returnVal = component.getDisplayText(item, displayFields);
    expect(returnVal).toBe('test val - TV');
  });

  it('Should return empty array when there is no History', () => {
    component.getHistory = () => {
      return [];
    };
    const returnVal = component.getHistory$();
    expect(returnVal).toEqual([]);
  });

  it('should disable auto complete control when supplied control is disabled', () => {
    component.control = new FormControl({value: 'actual val', disabled: true}, Validators.compose([
      Validators.required
    ]));
    component.ngAfterViewInit();
    expect(component.control.disabled).toBe(true);
  });

  it('should set the value of input control when control value is set', () => {
    jasmine.clock().install();
    component.displayFields = ['abc', 'test'];
    component.inputControl.setValue('test');
    component.ngOnInit();
    component.control.setValue('test1');
    jasmine.clock().tick(1600);
    expect(component.inputControl.value).toBe('test');
    jasmine.clock().uninstall();
  });

  it('should call method ngOnInit when null', () => {
    jasmine.clock().install();
    component.displayFields = ['abc', 'test'];
    component.inputControl.setValue('');
    component.ngOnInit();
    component.control.setValue('test2');
    jasmine.clock().tick(1600);
    expect(component.inputControl.value).toBe('');
    jasmine.clock().uninstall();
  });

  it('should remove control value from history, if control values exist in History when primaryKeyInValue is set', () => {
    component.getHistory = () => {
      return [{
        abbreviation: 'VJJV',
        departmentName: 'IT BAS CC Corporate BPI & Automation',
        email: 'vasu.janapareddy@asml.com',
        employeeNumber: '00660188',
        firstName: 'Vasu',
        fullName: 'Vasu Janapareddy',
        lastName: 'Janapareddy',
        userID: 'vjanapar'
      }, {
        abbreviation: 'HKBI',
        departmentName: 'IT BAS CC Corporate BPI & Automation',
        email: 'harshit.kapoor@asml.com',
        employeeNumber: '00660188',
        firstName: 'Harshit',
        fullName: 'Harshit Kapoor',
        lastName: 'Kapoor',
        userID: 'hkapoor'
      }];
    };
    component.prefix = 'test';
    component.secondLineItemDisplayFields = 'second test';
    component.secondLineItemDisplayFields = 123;
    component.control = new FormControl({
      abbreviation: 'HKBI',
      departmentName: 'IT BAS CC Corporate BPI & Automation',
      email: 'harshit.kapoor@asml.com',
      employeeNumber: '00660188',
      firstName: 'Harshit',
      fullName: 'Harshit Kapoor2',
      lastName: 'Kapoor',
      userID: 'hkapoor'
    });
    component.primaryKeyInValue = 'fullName';
    component.onClick();
    expect(component.history.length).toEqual(1);
  });

  it('Initially when triggered filterHistory then history length should be zero', () => {
    component.displayFields = ['name', 'placeholder'];
    component.filterHistory('name');
    expect(component.history.length).toBe(0);
  });

  it('should call getDisplayText to format the text, when  getFieldText is triggered', () => {
    const value = {name: 'abc', abbr: 'ab', id: 1};
    const displayTextFnSpy = spyOn(component, 'getDisplayText');
    component.getFieldText()('sample');
    expect(displayTextFnSpy).toHaveBeenCalled();
  });

  it('should call method ngOnInit when null and mincharacter is set', () => {
    jasmine.clock().install();
    component.displayFields = ['abc', 'test'];
    component.inputControl.setValue('test');
    component.minCharacters = 3;
    component.ngOnInit();
    component.control.setValue('test2');
    jasmine.clock().tick(1600);
    expect(component.inputControl.value).toBe('test');
    jasmine.clock().uninstall();
  });

  it('should return options list, when onInit is triggered, showOptionsOnFocus is true and minCharacters is not set', () => {
    jasmine.clock().install();
    component.showOptionsOnFocus = true;
    component.displayFields = ['abc', 'test'];
    component.inputControl.setValue([]);
    component.ngOnInit();
    component.control.setValue('test2');
    jasmine.clock().tick(1600);
    expect(component.inputControl.value).toEqual([]);
    jasmine.clock().uninstall();
  });

  it('should return options list, when onInit is triggered, showOptionsOnFocus is true and minCharacters is set', () => {
    jasmine.clock().install();
    component.showOptionsOnFocus = true;
    component.minCharacters = 1;
    component.displayFields = ['abc', 'test'];
    component.inputControl.setValue('');
    component.ngOnInit();
    component.control.setValue('test2');
    jasmine.clock().tick(1600);
    expect(component.inputControl.value).toEqual('');
    jasmine.clock().uninstall();
  });
});
