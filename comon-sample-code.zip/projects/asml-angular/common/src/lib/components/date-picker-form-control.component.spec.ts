import {waitForAsync, ComponentFixture, TestBed} from '@angular/core/testing';

import {AALDatePickerFormControlComponent} from './date-picker-form-control.component';
import {FormControl, Validators} from '@angular/forms';
import {HistoryService} from '../services/history.service';
import {Mode} from '../models/enumeration.model';
import {AALFixedInputFormControlComponent} from './fixed-input-form-control.component';

class HistoryServiceMock {
  historyContainer = {ID: ['Item A', 'Item B', 'Item AA']};

  addItem(key: string, value: string): void {
    this.historyContainer[key] = this.historyContainer[key] || [];
    this.historyContainer[key].push(value);
  }

  getItems(key: string): string[] {
    return this.historyContainer[key];
  }
}

describe('AALDatePickerFormControlComponent', () => {
  let component: AALDatePickerFormControlComponent;
  let fixture: ComponentFixture<AALDatePickerFormControlComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [AALDatePickerFormControlComponent],
      providers: [{provide: HistoryService, useClass: HistoryServiceMock}]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALDatePickerFormControlComponent);
    component = fixture.componentInstance;
    component.control = new FormControl(new Date(), Validators.compose([
      Validators.required
    ]));
    component.isPastDateRange = true;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should initialize endDateForm value on ngOnInit', () => {
    const today = new Date();
    component.ngOnInit();
    expect(component.endDateForm.length).toBeGreaterThan(0);
  });

  it('should initialize endDateForm with current dates on ngOnInit', () => {
    const today = new Date();
    component.isPastDateRange = false;
    component.ngOnInit();
    expect(component.endDateForm.length).toBeGreaterThan(0);
  });

  it('should set the mode to EDIT on Click', () => {
    component.mode = 'READ' as Mode;
    component.dateSelectInput = {
      open() {
        return;
      }
    };
    component.onClick();
    expect(component.mode).toEqual('EDIT');
  });

  it('should call super method on change', () => {
    spyOn(AALFixedInputFormControlComponent.prototype, 'onChange');
    component.onChange();
    expect(AALFixedInputFormControlComponent.prototype.onChange).toHaveBeenCalled();
  });
});
