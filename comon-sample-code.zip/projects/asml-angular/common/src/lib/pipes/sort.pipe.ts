import {Pipe, PipeTransform} from '@angular/core';

/**
 * This pipe is  a utility function used to sort any ngFor abased on some field
 * usage : in any template which included this shared module
 *         <div *ngFor="somearray|sort :'someField'"></div>
 */
@Pipe({
  name: 'aalSort'
})
export class AALSortPipe implements PipeTransform {

  transform(array: any[], field: string): any[] {
    array.sort((a: any, b: any) => {
      if (a[field] < b[field]) {
        return -1;
      } else if (a[field] > b[field]) {
        return 1;
      } else {
        return 0;
      }
    });
    return array;
  }

}
