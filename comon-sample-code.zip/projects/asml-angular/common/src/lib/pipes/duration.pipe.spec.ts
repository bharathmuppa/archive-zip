import {AALDurationPipe} from './duration.pipe';

describe('AALDurationPipe', () => {
  it('create an instance', () => {
    const pipe = new AALDurationPipe();
    expect(pipe).toBeTruthy();
  });

  it('should match the regular expresion for PT format', () => {
    const pipe = new AALDurationPipe();
    expect(pipe.transform('P1Y0M5DT5M5S').toString()).toBe('8760h5m5s');
  });

  it('should not match the regular expression', () => {
    const pipe = new AALDurationPipe();
    expect(pipe.transform('1234')).toBe('');
  });

  it('should return if value is not valid', () => {
    const pipe = new AALDurationPipe();
    expect(pipe.transform(null)).toBe(null);
  });

  it('should return default value when the value is zero', () => {
    const pipe = new AALDurationPipe();
    expect(pipe.transform('PT0M', '0h').toString()).toBe('0h');
  });
});
