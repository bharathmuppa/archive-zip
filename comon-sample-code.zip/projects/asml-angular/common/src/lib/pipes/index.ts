import {AALHighlightPipe} from './highlight.pipe';
import {AALBooleanPipe} from './boolean.pipe';
import {AALDatePipe} from './date.pipe';
import {AALDurationPipe} from './duration.pipe';
import {AALNumberPipe} from './number.pipe';
import {AALSortPipe} from './sort.pipe';
import {AALReplacePipe} from './replace.pipe';
import {AALGroupByPipe} from './group-by.pipe';
import {AALSafePipe} from './safe.pipe';

export {
  AALBooleanPipe,
  AALDatePipe,
  AALDurationPipe,
  AALHighlightPipe,
  AALNumberPipe,
  AALSortPipe,
  AALReplacePipe,
  AALGroupByPipe,
  AALSafePipe
};


export const COMMON_PIPES = [
  AALBooleanPipe,
  AALDatePipe,
  AALDurationPipe,
  AALHighlightPipe,
  AALNumberPipe,
  AALSortPipe,
  AALReplacePipe,
  AALGroupByPipe,
  AALSafePipe
];
