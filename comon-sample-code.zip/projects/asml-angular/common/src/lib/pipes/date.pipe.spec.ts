import {AALDatePipe} from './date.pipe';

describe('AALDatePipe', () => {
  let pipe: AALDatePipe;

  beforeEach(() => {
    pipe = new AALDatePipe('en-US');
  });

  it('create an instance', () => {
    expect(pipe).toBeTruthy();
  });

  it('should return week number', () => {
    const dt = new Date('22 Aug 2019');
    expect(pipe.transform(dt)).toContain('22 Aug 2019 (34.4)');
  });

  it('should return 1d ago', () => {
    const today = new Date();
    const yesterday = today.setDate(today.getDate() - 1);
    expect(pipe.transform(yesterday, 'dueDate')).toMatch(/ 1d ago$/);
  });

  it('should return in 1d', () => {
    const today = new Date();
    const tomorrow = today.setDate(today.getDate() + 1);
    expect(pipe.transform(tomorrow, 'dueDate')).toMatch(/ in 1d$/);
  });

  it('should return null when null value is set', () => {
    expect(pipe.transform(null)).toBe('');
  });
  it('should return date in dueDays when argument "dueDays" is set', () => {
    expect(pipe.transform(new Date(new Date(new Date(new Date().setMonth(1)).setFullYear(2020)).setDate(1)), 'dueDays')).toContain('d ago');
  });
  it('should return week number and day when argument "week-day" is set', () => {
    // setting the date as feb 1st ,2020
    expect(pipe.transform(new Date(812463300000), 'week-day')).toBe('wk39.6');
  });
  it('should return time as well if time argument is sent', () => {
    const today = '2011-08-12T20:17:46.384Z';
    expect(new Date(pipe.transform(today, 'time')).getDay()).toBe(new Date('2011-08-12T20:17:46.384Z').getDay());
  });
});
