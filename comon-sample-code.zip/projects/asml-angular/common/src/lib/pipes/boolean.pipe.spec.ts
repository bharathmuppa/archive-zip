import {AALBooleanPipe} from './boolean.pipe';

describe('AALBooleanPipe', () => {
  let pipe: AALBooleanPipe;

  beforeEach(() => {
    pipe = new AALBooleanPipe();
  });

  it('create an instance', () => {
    expect(pipe).toBeTruthy();
  });
  it('should return Yes', () => {
    expect(pipe.transform(true)).toBe('Yes');
  });
  it('should return No', () => {
    expect(pipe.transform(false)).toBe('No');
  });
  it('should return No', () => {
    expect(pipe.transform(null)).toBe('No');
  });
  it('should return No', () => {
    expect(pipe.transform(undefined)).toBe('No');
  });
});
