import {AALHighlightPipe} from './highlight.pipe';

describe('AALHighlightPipe', () => {
  let pipe: AALHighlightPipe;

  beforeEach(() => {
    pipe = new AALHighlightPipe();
  });

  it('create an instance', () => {
    expect(pipe).toBeTruthy();
  });

  it('should return bold', () => {
    expect(pipe.transform('text to *boldify*', '*')).toBe('text to <b>*</b>boldify<b>*</b>');
  });

  it('should not return bold', () => {
    expect(pipe.transform('text to boldify', '*')).toBe('text to boldify');
  });

  it('should not return bold', () => {
    expect(pipe.transform('text to *boldify*', '#')).toBe('text to *boldify*');
  });

  it('if search is not a string, then it should return text', () => {
    expect(pipe.transform('test', {})).toBe('test');
  });
});
