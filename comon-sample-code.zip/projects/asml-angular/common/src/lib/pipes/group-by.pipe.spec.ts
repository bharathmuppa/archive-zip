import { AALGroupByPipe } from './group-by.pipe';

describe('AALGroupByPipe', () => {
  it('create an instance', () => {
    const pipe = new AALGroupByPipe();
    expect(pipe).toBeTruthy();
  });

  it('should return null when empty array is passed', () => {
    const pipe = new AALGroupByPipe();
    expect(pipe.transform([], 'test')).toEqual(null);
  });

  it('create return group by object when array is passed', () => {
    const Object = [{ name: 'Apple', color: 'Green'},
      {name: 'Banana', color: 'Yellow'},
      { name: 'Grape', color: 'Green' },
      { name: 'Melon', color: 'Yellow' },
      { name: 'Orange', color: 'Orange' }
    ];
    const pipe = new AALGroupByPipe();
    expect(pipe.transform(Object, 'color')).toEqual([
      { key: 'Green', value: [
        { name: 'Apple', color: 'Green' },
        { name: 'Grape', color: 'Green' }]
      },
      { key: 'Yellow',
        value: [{ name: 'Banana', color: 'Yellow' },
          { name: 'Melon', color: 'Yellow' }]
      },
      { key: 'Orange',
        value: [{ name: 'Orange', color: 'Orange' }]
      }
    ]);
  });

});
