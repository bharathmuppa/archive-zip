import {Pipe, PipeTransform} from '@angular/core';

@Pipe({
  name: 'aalReplace'
})
export class AALReplacePipe implements PipeTransform {

  transform(value: any, regexValue: string, replaceValue: string): any {
    let isNumber = false;
    if (typeof value === 'number') {
      isNumber = true;
      value = value + '';
    }
    if (value && value.length > 0) {
      const regex = new RegExp(regexValue, 'g');
      return isNumber ? +value.replace(regex, replaceValue) : value.replace(regex, replaceValue);
    }
    return null;
  }

}
