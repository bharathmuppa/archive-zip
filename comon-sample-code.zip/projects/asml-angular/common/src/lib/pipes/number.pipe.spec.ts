import {AALNumberPipe} from './number.pipe';

describe('AALNumberPipe', () => {
  let pipe: AALNumberPipe;

  beforeEach(() => {
    pipe = new AALNumberPipe();
  });

  it('create an instance', () => {
    expect(pipe).toBeTruthy();
  });

  it('should not transform', () => {
    expect(pipe.transform(1)).toBe(1);
  });

  it('should transform to First', () => {
    expect(pipe.transform(1, 'to-word')).toBe('First');
  });

  it('should transform to Second', () => {
    expect(pipe.transform(2, 'to-word')).toBe('Second');
  });

  it('should transform to Third', () => {
    expect(pipe.transform(3, 'to-word')).toBe('Third');
  });

  it('should transform to Fourth', () => {
    expect(pipe.transform(4, 'to-word')).toBe('Fourth');
  });

  it('should transform to Fifth', () => {
    expect(pipe.transform(5, 'to-word')).toBe('Fifth');
  });

  it('should transform to Sixth', () => {
    expect(pipe.transform(6, 'to-word')).toBe('Sixth');
  });

  it('should transform to Seventh', () => {
    expect(pipe.transform(7, 'to-word')).toBe('Seventh');
  });

  it('should transform to Eighth', () => {
    expect(pipe.transform(8, 'to-word')).toBe('Eighth');
  });

  it('should transform to Ninth', () => {
    expect(pipe.transform(9, 'to-word')).toBe('Ninth');
  });

  it('should transform to Tenth', () => {
    expect(pipe.transform(10, 'to-word')).toBe('Tenth');
  });

  it('should transform to Eleventh', () => {
    expect(pipe.transform(11, 'to-word')).toBe('Eleventh');
  });

  it('should transform to Twelfth', () => {
    expect(pipe.transform(12, 'to-word')).toBe('Twelfth');
  });

  it('should transform to Thirteenth', () => {
    expect(pipe.transform(13, 'to-word')).toBe('Thirteenth');
  });

  it('should transform to Fourteenth', () => {
    expect(pipe.transform(14, 'to-word')).toBe('Fourteenth');
  });

  it('should transform to Fifteenth', () => {
    expect(pipe.transform(15, 'to-word')).toBe('Fifteenth');
  });

  it('should transform to Sixteenth', () => {
    expect(pipe.transform(16, 'to-word')).toBe('Sixteenth');
  });

  it('should transform to Seventeenth', () => {
    expect(pipe.transform(17, 'to-word')).toBe('Seventeenth');
  });

  it('should transform to Eighteenth', () => {
    expect(pipe.transform(18, 'to-word')).toBe('Eighteenth');
  });

  it('should transform to Nineteenth', () => {
    expect(pipe.transform(19, 'to-word')).toBe('Nineteenth');
  });

  it('should transform to Nineteenth', () => {
    expect(pipe.transform(20, 'to-word')).toBe('Twentieth');
  });

  it('should transform to TwentyFirst', () => {
    expect(pipe.transform(21, 'to-word')).toBe('Twenty-First');
  });

  it('should transform to TwentySecond', () => {
    expect(pipe.transform(22, 'to-word')).toBe('Twenty-Second');
  });

  it('should transform to Thirtieth', () => {
    expect(pipe.transform(23, 'to-word')).toBe('Twenty-Third');
  });
});
