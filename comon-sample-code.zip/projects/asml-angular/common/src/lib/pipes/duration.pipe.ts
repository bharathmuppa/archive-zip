import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'aalDuration'
})
export class AALDurationPipe implements PipeTransform {
  transform(duration: string, defaultValue?: string): string {
    if (!duration) {
      return duration;
    }
    const matches: string[] = duration.match(/^P([0-9]+Y|)?([0-9]+M|)?([0-9]+D|)?T?([0-9]+H|)?([0-9]+M|)?([0-9]+S|)?$/);
    const result: any = {};
    if (matches) {
      result.year = parseInt(matches[1], 10);
      result.month = parseInt(matches[2], 10);
      result.day = parseInt(matches[3], 10);
      result.hour = parseInt(matches[4], 10);
      result.minute = parseInt(matches[5], 10);
      result.second = parseInt(matches[6], 10);

      result.toString = function() {
        let formattedValue = '';

        if (this.year) {
          this.month = (this.month) ? this.month + this.year * 12 : this.year * 12;
        }
        if (this.month) {
          this.day = (this.day) ? this.day + this.month * 30 : this.month * 30;
        }
        if (this.day) {
          this.hour = (this.hour) ? this.hour + this.day * 24 : this.day * 24;
        }
        if (this.hour) {
          formattedValue += `${this.hour}h`;
        }
        if (this.minute) {
          formattedValue += `${this.minute}m`;
        }
        if (this.second) {
          formattedValue += `${this.second}s`;
        }
        if (!formattedValue && defaultValue) {
          return defaultValue;
        }
        return formattedValue || '0h';
      };
      return result;
    } else {
      return '';
    }
  }
}
