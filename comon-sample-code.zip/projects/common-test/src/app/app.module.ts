import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';

import {AppComponent} from './app.component';
import {CommonFormControlDerivedComponent} from './common-form-control-derived/common-form-control-derived.component';

@NgModule({
  declarations: [
    AppComponent,
    CommonFormControlDerivedComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {
}
