import {Component} from '@angular/core';
import {AALCommonFormControlComponent} from '../../../../asml-angular/common/src/lib/components/common-form-control.component';
import {HistoryService} from '../../../../asml-angular/common/src/lib/services/history.service';

@Component({
  selector: 'app-common-form-control-derived',
  templateUrl: './common-form-control-derived.component.html',
  styleUrls: ['./common-form-control-derived.component.scss']
})
export class CommonFormControlDerivedComponent extends AALCommonFormControlComponent {

  constructor(historyService: HistoryService) {
    super(historyService);
  }
}
