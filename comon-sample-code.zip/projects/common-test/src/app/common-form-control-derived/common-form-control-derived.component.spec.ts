import {waitForAsync, ComponentFixture, TestBed} from '@angular/core/testing';

import {CommonFormControlDerivedComponent} from './common-form-control-derived.component';

describe('CommonFormControlDerivedComponent', () => {
  let component: CommonFormControlDerivedComponent;
  let fixture: ComponentFixture<CommonFormControlDerivedComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [CommonFormControlDerivedComponent]
    })
      .compileComponents().then(() => {
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CommonFormControlDerivedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
